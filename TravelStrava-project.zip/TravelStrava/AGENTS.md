<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep private profile, visit, reaction, and verification records owner-scoped; public social displays use fixed-field database projections so contacts and personal GPS never leak.
- Sign shared photos only by a published record ID after verifying attachment ownership; direct storage access remains owner-only to protect unshared uploads.
- Remove private query caches and reset caller-specific public cards on sign-out so shared browser sessions cannot retain another account's private data.
- Run security integration tests with disposable accounts and remove their uploads and records afterward so existing user data remains untouched.
