-- Saved check-ins
CREATE TABLE public.visit_saves (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  visit_id uuid NOT NULL REFERENCES public.visits(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (visit_id, user_id)
);

GRANT SELECT, INSERT, DELETE ON public.visit_saves TO authenticated;
GRANT ALL ON public.visit_saves TO service_role;
ALTER TABLE public.visit_saves ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own saves" ON public.visit_saves
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Users save visits" ON public.visit_saves
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users unsave visits" ON public.visit_saves
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Group trips
ALTER TABLE public.trips ADD COLUMN IF NOT EXISTS invite_code text;

CREATE OR REPLACE FUNCTION public.generate_invite_code()
RETURNS text
LANGUAGE sql
VOLATILE
AS $$
  SELECT upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 6));
$$;

UPDATE public.trips SET invite_code = public.generate_invite_code() WHERE invite_code IS NULL;
ALTER TABLE public.trips ALTER COLUMN invite_code SET DEFAULT public.generate_invite_code();
CREATE UNIQUE INDEX IF NOT EXISTS trips_invite_code_key ON public.trips (invite_code);

CREATE TABLE public.trip_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (trip_id, user_id)
);

GRANT SELECT, INSERT, DELETE ON public.trip_members TO authenticated;
GRANT ALL ON public.trip_members TO service_role;
ALTER TABLE public.trip_members ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_trip_member(_trip_id uuid, _user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.trip_members
    WHERE trip_id = _trip_id AND user_id = _user_id
  ) OR EXISTS (
    SELECT 1 FROM public.trips
    WHERE id = _trip_id AND user_id = _user_id
  );
$$;

CREATE POLICY "Members read trip roster" ON public.trip_members
  FOR SELECT TO authenticated USING (public.is_trip_member(trip_id, auth.uid()));
CREATE POLICY "Users join trips" ON public.trip_members
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users leave trips" ON public.trip_members
  FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "Members read shared trips" ON public.trips
  FOR SELECT TO authenticated USING (public.is_trip_member(id, auth.uid()));
CREATE POLICY "Members read shared expenses" ON public.trip_expenses
  FOR SELECT TO authenticated USING (public.is_trip_member(trip_id, auth.uid()));

-- Check-in location, responsible pledge and trip link
ALTER TABLE public.visits ADD COLUMN IF NOT EXISTS latitude double precision;
ALTER TABLE public.visits ADD COLUMN IF NOT EXISTS longitude double precision;
ALTER TABLE public.visits ADD COLUMN IF NOT EXISTS responsible_pledge boolean NOT NULL DEFAULT false;
ALTER TABLE public.visits ADD COLUMN IF NOT EXISTS trip_id uuid REFERENCES public.trips(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS visits_trip_id_idx ON public.visits (trip_id);