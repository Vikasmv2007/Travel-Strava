-- 1. Profiles tied to real auth users
CREATE TABLE public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text NOT NULL DEFAULT 'Traveller',
  avatar_initials text NOT NULL DEFAULT 'TS',
  home_region text,
  xp integer NOT NULL DEFAULT 0,
  current_streak integer NOT NULL DEFAULT 0,
  longest_streak integer NOT NULL DEFAULT 0,
  last_check_in_date date,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO anon;
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Profiles are public" ON public.profiles FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  base_name text;
BEGIN
  base_name := coalesce(
    nullif(new.raw_user_meta_data ->> 'display_name', ''),
    nullif(new.raw_user_meta_data ->> 'full_name', ''),
    nullif(new.raw_user_meta_data ->> 'name', ''),
    split_part(coalesce(new.email, 'traveller'), '@', 1)
  );
  INSERT INTO public.profiles (id, display_name, avatar_initials)
  VALUES (
    new.id,
    base_name,
    upper(substr(regexp_replace(base_name, '[^a-zA-Z]', '', 'g') || 'TS', 1, 2))
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN new;
END;
$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 2. Richer heritage site context (additive, nullable)
ALTER TABLE public.heritage_sites
  ADD COLUMN crowd_level text,
  ADD COLUMN best_time text,
  ADD COLUMN women_safety_rating numeric(2,1),
  ADD COLUMN accessibility_notes text,
  ADD COLUMN etiquette text,
  ADD COLUMN local_legend text,
  ADD COLUMN photo_spot text,
  ADD COLUMN emergency_contact text,
  ADD COLUMN entry_fee_inr integer,
  ADD COLUMN guide_fee_inr integer,
  ADD COLUMN visitors_per_year integer;

-- 3. Visits (check-ins by real accounts)
CREATE TABLE public.visits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  site_id uuid NOT NULL REFERENCES public.heritage_sites(id) ON DELETE CASCADE,
  photo_url text,
  caption text,
  activity_type text NOT NULL DEFAULT 'heritage_visit',
  xp_awarded integer NOT NULL DEFAULT 10,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX visits_created_at_idx ON public.visits (created_at DESC);
CREATE INDEX visits_user_idx ON public.visits (user_id);
GRANT SELECT ON public.visits TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.visits TO authenticated;
GRANT ALL ON public.visits TO service_role;
ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Visits are public" ON public.visits FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Insert own visit" ON public.visits FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Update own visit" ON public.visits FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Delete own visit" ON public.visits FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- XP, streaks and first-discovery bonus
CREATE OR REPLACE FUNCTION public.apply_visit_rewards()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  is_first_for_user boolean;
  award integer;
  prev_date date;
  new_streak integer;
BEGIN
  SELECT NOT EXISTS (
    SELECT 1 FROM public.visits v
    WHERE v.user_id = new.user_id AND v.site_id = new.site_id AND v.id <> new.id
  ) INTO is_first_for_user;

  award := CASE WHEN is_first_for_user THEN 25 ELSE 10 END;
  UPDATE public.visits SET xp_awarded = award WHERE id = new.id;

  SELECT last_check_in_date INTO prev_date FROM public.profiles WHERE id = new.user_id;
  IF prev_date = current_date THEN
    SELECT current_streak INTO new_streak FROM public.profiles WHERE id = new.user_id;
  ELSIF prev_date = current_date - 1 THEN
    SELECT current_streak + 1 INTO new_streak FROM public.profiles WHERE id = new.user_id;
  ELSE
    new_streak := 1;
  END IF;

  UPDATE public.profiles
  SET xp = xp + award,
      current_streak = new_streak,
      longest_streak = greatest(longest_streak, new_streak),
      last_check_in_date = current_date
  WHERE id = new.user_id;

  RETURN new;
END;
$$;

CREATE TRIGGER visits_apply_rewards
AFTER INSERT ON public.visits
FOR EACH ROW EXECUTE FUNCTION public.apply_visit_rewards();

-- 4. Social engagement
CREATE TABLE public.visit_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  visit_id uuid NOT NULL REFERENCES public.visits(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (visit_id, user_id)
);
GRANT SELECT ON public.visit_likes TO anon;
GRANT SELECT, INSERT, DELETE ON public.visit_likes TO authenticated;
GRANT ALL ON public.visit_likes TO service_role;
ALTER TABLE public.visit_likes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Likes are public" ON public.visit_likes FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Insert own like" ON public.visit_likes FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Delete own like" ON public.visit_likes FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.visit_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  visit_id uuid NOT NULL REFERENCES public.visits(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  body text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX visit_comments_visit_idx ON public.visit_comments (visit_id);
GRANT SELECT ON public.visit_comments TO anon;
GRANT SELECT, INSERT, DELETE ON public.visit_comments TO authenticated;
GRANT ALL ON public.visit_comments TO service_role;
ALTER TABLE public.visit_comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Comments are public" ON public.visit_comments FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Insert own comment" ON public.visit_comments FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Delete own comment" ON public.visit_comments FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- 5. Budget tracker
CREATE TABLE public.trips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  budget_inr integer NOT NULL DEFAULT 0,
  start_date date,
  end_date date,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.trips TO authenticated;
GRANT ALL ON public.trips TO service_role;
ALTER TABLE public.trips ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own trips" ON public.trips FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Insert own trip" ON public.trips FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Update own trip" ON public.trips FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Delete own trip" ON public.trips FOR DELETE TO authenticated USING (auth.uid() = user_id);

CREATE TABLE public.trip_expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_id uuid NOT NULL REFERENCES public.trips(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  category text NOT NULL DEFAULT 'other',
  label text NOT NULL,
  amount_inr integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX trip_expenses_trip_idx ON public.trip_expenses (trip_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.trip_expenses TO authenticated;
GRANT ALL ON public.trip_expenses TO service_role;
ALTER TABLE public.trip_expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Own expenses" ON public.trip_expenses FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Insert own expense" ON public.trip_expenses FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Update own expense" ON public.trip_expenses FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Delete own expense" ON public.trip_expenses FOR DELETE TO authenticated USING (auth.uid() = user_id);