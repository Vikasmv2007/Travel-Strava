CREATE TABLE public.heritage_sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  region text NOT NULL,
  history_blurb text NOT NULL,
  safety_notes text NOT NULL,
  stamp_code text NOT NULL,
  stamp_color text NOT NULL,
  xp_reward integer NOT NULL DEFAULT 10,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.heritage_sites TO anon, authenticated;
GRANT ALL ON public.heritage_sites TO service_role;
ALTER TABLE public.heritage_sites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Sites are public" ON public.heritage_sites FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  avatar_initials text NOT NULL,
  xp integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.app_users TO anon, authenticated;
GRANT ALL ON public.app_users TO service_role;
ALTER TABLE public.app_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Demo users are public" ON public.app_users FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Demo users xp updatable" ON public.app_users FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.check_ins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.app_users(id) ON DELETE CASCADE,
  site_id uuid NOT NULL REFERENCES public.heritage_sites(id) ON DELETE CASCADE,
  photo_url text,
  caption text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX check_ins_user_idx ON public.check_ins(user_id);
CREATE INDEX check_ins_site_idx ON public.check_ins(site_id);
GRANT SELECT, INSERT ON public.check_ins TO anon, authenticated;
GRANT ALL ON public.check_ins TO service_role;
ALTER TABLE public.check_ins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Check-ins are public" ON public.check_ins FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can check in (demo)" ON public.check_ins FOR INSERT TO anon, authenticated WITH CHECK (true);

INSERT INTO public.app_users (id, name, avatar_initials, xp) VALUES
  ('11111111-1111-1111-1111-111111111111', 'Aarav R.', 'AR', 90),
  ('22222222-2222-2222-2222-222222222222', 'Meera N.', 'MN', 40),
  ('33333333-3333-3333-3333-333333333333', 'You', 'YU', 0);

INSERT INTO public.heritage_sites (name, region, history_blurb, safety_notes, stamp_code, stamp_color, xp_reward, latitude, longitude) VALUES
  ('Taj Mahal', 'Agra, Uttar Pradesh', 'Commissioned by Shah Jahan in 1632 as a mausoleum for Mumtaz Mahal. Twenty thousand artisans worked white marble inlaid with semi-precious stone. It took over two decades to finish.', 'Fridays are closed to tourists; carry water in summer, surfaces get scorching.', 'TM', 'brand', 10, 27.1751, 78.0421),
  ('Ajanta Caves', 'Aurangabad, Maharashtra', 'Thirty rock-cut Buddhist caves carved between the 2nd century BCE and 480 CE. Their murals are among the finest surviving ancient Indian painting. Rediscovered by a hunting party in 1819.', 'Cave floors are uneven and dim — wear grip shoes and skip flash photography.', 'AJ', 'plum', 10, 20.5519, 75.7033),
  ('Virupaksha Temple', 'Hampi, Karnataka', 'A working Shiva temple since the 7th century, expanded under the Vijayanagara kings. Its gopuram towers over the Tungabhadra river. The bazaar street outside once traded diamonds.', 'Granite boulders get very hot; avoid midday climbs and watch for monkeys.', 'VT', 'mint', 10, 15.3350, 76.4600),
  ('Shore Temple', 'Mahabalipuram, Tamil Nadu', 'Built around 700 CE under the Pallava king Narasimhavarman II. One of the earliest free-standing stone temples in South India. Sea spray has softened its carvings over thirteen centuries.', 'Rocks near the shoreline are slippery at high tide — keep back from the surf.', 'ST', 'accent', 10, 12.6169, 80.1995),
  ('Varanasi Ghats', 'Varanasi, Uttar Pradesh', 'Eighty-odd riverfront steps along the Ganges, many built by Maratha patrons in the 18th century. Pilgrims have bathed here for at least three thousand years. Evening aarti draws crowds daily.', 'Steps are slick and crowds dense at aarti; keep valuables close and avoid the water.', 'VG', 'brand', 10, 25.3109, 83.0107),
  ('Sanchi Stupa', 'Raisen, Madhya Pradesh', 'Begun by Ashoka in the 3rd century BCE over relics of the Buddha. Later dynasties added the carved toranas depicting Jataka tales. It is the oldest stone structure in India.', 'Open grounds with little shade — go early and carry a hat.', 'SS', 'mint', 10, 23.4795, 77.7396),
  ('Jaipur City Palace', 'Jaipur, Rajasthan', 'Built from 1729 by Sawai Jai Singh II as he moved his capital from Amber. Blends Rajput, Mughal and European design. Part of it is still a royal residence.', 'Peak-hour queues are long; buy tickets ahead and stay hydrated.', 'JP', 'plum', 10, 26.9255, 75.8236),
  ('Konark Sun Temple', 'Puri, Odisha', 'A 13th-century temple built as the sun god Surya''s chariot, with twenty-four carved stone wheels. Raised by King Narasimhadeva I. Sailors once called it the Black Pagoda.', 'Sand is hot underfoot and shade is scarce — footwear and water are essential.', 'KS', 'accent', 10, 19.8876, 86.0945),
  ('Hawa Mahal', 'Jaipur, Rajasthan', 'A five-storey screen of 953 jharokhas built in 1799 for royal women to watch the street unseen. Designed by Lal Chand Ustad in pink sandstone. It is barely a room deep.', 'Upper ramps are steep and narrow; hold the rail and mind your head.', 'HM', 'brand', 10, 26.9239, 75.8267),
  ('Qutub Minar', 'Delhi', 'A 73-metre victory tower begun by Qutb ud-Din Aibak in 1199 and finished by his successors. Bands of Quranic calligraphy wrap the red sandstone. The nearby iron pillar has resisted rust for 1,600 years.', 'The tower interior is closed to climbing; stay on marked paths in the complex.', 'QM', 'mint', 10, 28.5245, 77.1855);
