CREATE POLICY "Demo can upload checkin photos" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'checkin-photos');
CREATE POLICY "Demo can read checkin photos" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'checkin-photos');
