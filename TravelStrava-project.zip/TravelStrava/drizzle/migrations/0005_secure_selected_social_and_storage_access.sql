DROP POLICY IF EXISTS "Demo users are public" ON public.app_users;
DROP POLICY IF EXISTS "Demo users xp updatable" ON public.app_users;
REVOKE ALL ON public.app_users FROM anon, authenticated;
COMMENT ON TABLE public.app_users IS 'DEPRECATED: legacy demo users; authenticated profiles replace this table. Client access disabled.';
DROP POLICY IF EXISTS "Anyone can check in (demo)" ON public.check_ins;
DROP POLICY IF EXISTS "Check-ins are public" ON public.check_ins;
REVOKE ALL ON public.check_ins FROM anon, authenticated;
COMMENT ON TABLE public.check_ins IS 'DEPRECATED: legacy demo check-ins; authenticated visits replace this table. Client access disabled.';

DROP POLICY IF EXISTS "Profiles are public" ON public.profiles;
CREATE POLICY "Read own private profile" ON public.profiles FOR SELECT TO authenticated USING ((SELECT auth.uid()) = id);
REVOKE SELECT ON public.profiles FROM anon;
DROP POLICY IF EXISTS "Visits are public" ON public.visits;
CREATE POLICY "Read own visit details" ON public.visits FOR SELECT TO authenticated USING ((SELECT auth.uid()) = user_id);
REVOKE SELECT ON public.visits FROM anon;
DROP POLICY IF EXISTS "Comments are public" ON public.visit_comments;
CREATE POLICY "Read own comment records" ON public.visit_comments FOR SELECT TO authenticated USING ((SELECT auth.uid()) = user_id);
REVOKE SELECT ON public.visit_comments FROM anon;
DROP POLICY IF EXISTS "Likes are public" ON public.visit_likes;
CREATE POLICY "Read own like records" ON public.visit_likes FOR SELECT TO authenticated USING ((SELECT auth.uid()) = user_id);
REVOKE SELECT ON public.visit_likes FROM anon;
DROP POLICY IF EXISTS "Verifications are public" ON public.place_verifications;
CREATE POLICY "Read own verification details" ON public.place_verifications FOR SELECT TO authenticated USING ((SELECT auth.uid()) = user_id);
REVOKE SELECT ON public.place_verifications FROM anon;

CREATE FUNCTION public.get_public_leaderboard()
RETURNS TABLE (id uuid, display_name text, avatar_initials text, home_region text, xp integer, current_streak integer, longest_streak integer, last_check_in_date date)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  SELECT p.id, p.display_name, p.avatar_initials, p.home_region, p.xp, p.current_streak, p.longest_streak, NULL::date
  FROM public.profiles p ORDER BY p.xp DESC, p.id LIMIT 50;
$$;
REVOKE ALL ON FUNCTION public.get_public_leaderboard() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_leaderboard() TO anon, authenticated, service_role;
COMMENT ON FUNCTION public.get_public_leaderboard() IS 'Intentional public ranking projection: fixed fields only; excludes contacts, consents, preferences and check-in dates.';

CREATE FUNCTION public.get_visit_cards(_scope text DEFAULT 'feed', _trip_id uuid DEFAULT NULL)
RETURNS SETOF jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = '' AS $$
DECLARE caller uuid := auth.uid();
BEGIN
  IF _scope IS NULL OR _scope NOT IN ('feed', 'own', 'trip') THEN
    RAISE EXCEPTION 'Invalid visit scope' USING ERRCODE = '22023';
  END IF;
  IF _scope = 'own' AND caller IS NULL THEN
    RAISE EXCEPTION 'Sign in required' USING ERRCODE = '42501';
  END IF;
  IF _scope = 'trip' THEN
    IF caller IS NULL OR _trip_id IS NULL OR NOT public.is_trip_member(_trip_id, caller) THEN
      RAISE EXCEPTION 'Trip access denied' USING ERRCODE = '42501';
    END IF;
  END IF;
  RETURN QUERY
  SELECT jsonb_build_object(
    'id', v.id, 'caption', v.caption, 'created_at', v.created_at,
    'photo_url', NULL, 'has_photo', v.photo_url IS NOT NULL,
    'xp_awarded', v.xp_awarded, 'activity_type', v.activity_type,
    'responsible_pledge', v.responsible_pledge,
    'latitude', CASE WHEN v.user_id = caller THEN v.latitude ELSE NULL END,
    'longitude', CASE WHEN v.user_id = caller THEN v.longitude ELSE NULL END,
    'heritage_sites', to_jsonb(s),
    'profiles', jsonb_build_object('id', p.id, 'display_name', p.display_name, 'avatar_initials', p.avatar_initials),
    'like_count', (SELECT count(*) FROM public.visit_likes l WHERE l.visit_id = v.id),
    'visit_likes', COALESCE((SELECT jsonb_agg(jsonb_build_object('user_id', l.user_id)) FROM public.visit_likes l WHERE l.visit_id = v.id AND l.user_id = caller), '[]'::jsonb),
    'visit_comments', COALESCE((SELECT jsonb_agg(jsonb_build_object(
      'id', c.id, 'body', c.body, 'created_at', c.created_at, 'user_id', c.user_id,
      'profiles', jsonb_build_object('display_name', cp.display_name, 'avatar_initials', cp.avatar_initials)
    ) ORDER BY c.created_at) FROM public.visit_comments c JOIN public.profiles cp ON cp.id = c.user_id WHERE c.visit_id = v.id), '[]'::jsonb)
  )
  FROM public.visits v
  JOIN public.heritage_sites s ON s.id = v.site_id
  JOIN public.profiles p ON p.id = v.user_id
  WHERE _scope = 'feed' OR (_scope = 'own' AND v.user_id = caller) OR (_scope = 'trip' AND v.trip_id = _trip_id)
  ORDER BY v.created_at DESC, v.id
  LIMIT CASE WHEN _scope = 'feed' THEN 40 ELSE NULL END;
END;
$$;
REVOKE ALL ON FUNCTION public.get_visit_cards(text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_visit_cards(text, uuid) TO anon, authenticated, service_role;
COMMENT ON FUNCTION public.get_visit_cards(text, uuid) IS 'Curated public social cards; raw photo paths and private GPS excluded for other users. Own scope uses caller identity; trip scope verifies membership.';

CREATE FUNCTION public.get_public_ranking_visits()
RETURNS SETOF jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  SELECT jsonb_build_object('user_id', v.user_id, 'xp_awarded', v.xp_awarded, 'activity_type', v.activity_type,
    'heritage_sites', jsonb_build_object('region', s.region),
    'profiles', jsonb_build_object('display_name', p.display_name, 'avatar_initials', p.avatar_initials))
  FROM public.visits v JOIN public.heritage_sites s ON s.id = v.site_id JOIN public.profiles p ON p.id = v.user_id
  ORDER BY v.created_at DESC, v.id LIMIT 1000;
$$;
REVOKE ALL ON FUNCTION public.get_public_ranking_visits() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_ranking_visits() TO anon, authenticated, service_role;

CREATE FUNCTION public.get_public_place_cards()
RETURNS SETOF jsonb LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  SELECT jsonb_build_object(
    'id', d.id, 'created_by', d.created_by, 'name', d.name, 'region', d.region,
    'category', d.category, 'story', d.story, 'access_notes', d.access_notes, 'best_time', d.best_time,
    'latitude', d.latitude, 'longitude', d.longitude, 'photo_url', NULL, 'has_photo', d.photo_url IS NOT NULL,
    'verification_count', d.verification_count, 'status', d.status, 'created_at', d.created_at,
    'profiles', jsonb_build_object('display_name', p.display_name, 'avatar_initials', p.avatar_initials),
    'place_verifications', COALESCE((SELECT jsonb_agg(jsonb_build_object('user_id', pv.user_id))
      FROM public.place_verifications pv WHERE pv.place_id = d.id AND pv.user_id = auth.uid()), '[]'::jsonb)
  )
  FROM public.discovered_places d JOIN public.profiles p ON p.id = d.created_by ORDER BY d.created_at DESC, d.id;
$$;
REVOKE ALL ON FUNCTION public.get_public_place_cards() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_place_cards() TO anon, authenticated, service_role;
COMMENT ON FUNCTION public.get_public_place_cards() IS 'Public place information and aggregate trust count; only the caller verification identity is returned, never verifier GPS or notes.';

DROP POLICY IF EXISTS "Demo can read checkin photos" ON storage.objects;
DROP POLICY IF EXISTS "Demo can upload checkin photos" ON storage.objects;
CREATE POLICY "Owners read checkin photos" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'checkin-photos' AND owner_id = (SELECT auth.uid()::text)
  AND ((storage.foldername(name))[1] = (SELECT auth.uid()::text)
    OR ((storage.foldername(name))[1] = 'places' AND (storage.foldername(name))[2] = (SELECT auth.uid()::text))));
CREATE POLICY "Owners upload checkin photos" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'checkin-photos' AND owner_id = (SELECT auth.uid()::text)
  AND ((storage.foldername(name))[1] = (SELECT auth.uid()::text)
    OR ((storage.foldername(name))[1] = 'places' AND (storage.foldername(name))[2] = (SELECT auth.uid()::text))));

CREATE FUNCTION public.get_public_photo_reference(_kind text, _record_id uuid)
RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  WITH published AS (
    SELECT v.photo_url AS path, v.user_id AS publisher FROM public.visits v WHERE _kind = 'visit' AND v.id = _record_id
    UNION ALL
    SELECT d.photo_url AS path, d.created_by AS publisher FROM public.discovered_places d WHERE _kind = 'place' AND d.id = _record_id
  )
  SELECT published.path FROM published JOIN storage.objects o ON o.bucket_id = 'checkin-photos' AND o.name = published.path
  WHERE o.owner_id = published.publisher::text
    AND ((storage.foldername(o.name))[1] = published.publisher::text
      OR ((storage.foldername(o.name))[1] = 'places' AND (storage.foldername(o.name))[2] = published.publisher::text))
  LIMIT 1;
$$;
REVOKE ALL ON FUNCTION public.get_public_photo_reference(text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_public_photo_reference(text, uuid) TO anon, authenticated, service_role;
COMMENT ON FUNCTION public.get_public_photo_reference(text, uuid) IS 'Authorizes signing only a photo attached to a public visit or place, with object ownership matching its author. Never authorizes unreferenced objects.';