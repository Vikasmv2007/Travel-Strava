-- Traveller preferences / consent
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS traveler_class text NOT NULL DEFAULT 'explorer',
  ADD COLUMN IF NOT EXISTS location_consent boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS safety_alert_consent boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS emergency_contact_phone text,
  ADD COLUMN IF NOT EXISTS places_added integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS places_verified integer NOT NULL DEFAULT 0;

-- Community-discovered places (the unused resource layer)
CREATE TABLE IF NOT EXISTS public.discovered_places (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_by uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  region text NOT NULL,
  category text NOT NULL DEFAULT 'hidden_heritage',
  story text NOT NULL,
  access_notes text,
  best_time text,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  photo_url text,
  verification_count integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'unverified',
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.discovered_places TO anon;
GRANT SELECT, INSERT, UPDATE ON public.discovered_places TO authenticated;
GRANT ALL ON public.discovered_places TO service_role;
ALTER TABLE public.discovered_places ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Places are public" ON public.discovered_places
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Add own place" ON public.discovered_places
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Update own place" ON public.discovered_places
  FOR UPDATE TO authenticated USING (auth.uid() = created_by) WITH CHECK (auth.uid() = created_by);

-- GPS-verified independent confirmations
CREATE TABLE IF NOT EXISTS public.place_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  place_id uuid NOT NULL REFERENCES public.discovered_places(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  distance_m integer NOT NULL DEFAULT 0,
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (place_id, user_id)
);

GRANT SELECT ON public.place_verifications TO anon;
GRANT SELECT, INSERT ON public.place_verifications TO authenticated;
GRANT ALL ON public.place_verifications TO service_role;
ALTER TABLE public.place_verifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Verifications are public" ON public.place_verifications
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Verify as self" ON public.place_verifications
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.apply_place_verification()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  total integer;
BEGIN
  SELECT count(*) INTO total FROM public.place_verifications WHERE place_id = new.place_id;
  UPDATE public.discovered_places
  SET verification_count = total,
      status = CASE WHEN total >= 3 THEN 'verified' WHEN total >= 1 THEN 'confirming' ELSE 'unverified' END
  WHERE id = new.place_id;

  UPDATE public.profiles
  SET xp = xp + 15,
      places_verified = places_verified + 1
  WHERE id = new.user_id;
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS place_verifications_apply ON public.place_verifications;
CREATE TRIGGER place_verifications_apply
AFTER INSERT ON public.place_verifications
FOR EACH ROW EXECUTE FUNCTION public.apply_place_verification();

CREATE OR REPLACE FUNCTION public.apply_place_discovery()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET xp = xp + 40,
      places_added = places_added + 1
  WHERE id = new.created_by;
  RETURN new;
END;
$$;

DROP TRIGGER IF EXISTS discovered_places_apply ON public.discovered_places;
CREATE TRIGGER discovered_places_apply
AFTER INSERT ON public.discovered_places
FOR EACH ROW EXECUTE FUNCTION public.apply_place_discovery();

-- Local economic layer
CREATE TABLE IF NOT EXISTS public.local_vendors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  added_by uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  place_id uuid REFERENCES public.discovered_places(id) ON DELETE CASCADE,
  site_id uuid REFERENCES public.heritage_sites(id) ON DELETE CASCADE,
  name text NOT NULL,
  vendor_type text NOT NULL DEFAULT 'guide',
  description text,
  contact text,
  price_from_inr integer,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.local_vendors TO anon;
GRANT SELECT, INSERT ON public.local_vendors TO authenticated;
GRANT ALL ON public.local_vendors TO service_role;
ALTER TABLE public.local_vendors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Vendors are public" ON public.local_vendors
  FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Add vendor" ON public.local_vendors
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = added_by);

-- SOS events (consent based)
CREATE TABLE IF NOT EXISTS public.sos_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  latitude double precision,
  longitude double precision,
  note text,
  resolved boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE ON public.sos_events TO authenticated;
GRANT ALL ON public.sos_events TO service_role;
ALTER TABLE public.sos_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Own sos events" ON public.sos_events
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Raise own sos" ON public.sos_events
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Resolve own sos" ON public.sos_events
  FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
