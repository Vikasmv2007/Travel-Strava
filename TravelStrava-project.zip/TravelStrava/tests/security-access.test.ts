import { afterAll, beforeAll, expect, setDefaultTimeout, test } from "bun:test";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "../src/integrations/supabase/types";

setDefaultTimeout(30000);

// Opt-in live integration tests. Credentials stay in the environment; all
// records belong to disposable accounts and are removed in afterAll.
function required(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing test environment variable: ${name}`);
  return value;
}

const url = required("SUPABASE_URL");
const publicKey = required("SUPABASE_PUBLISHABLE_KEY");
function client(key: string) {
  return createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) {
          headers.delete("Authorization");
        }
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      },
    },
  });
}

const admin = client(required("SUPABASE_SERVICE_ROLE_KEY"));
const anon = client(publicKey);
let owner: SupabaseClient<Database>;
let other: SupabaseClient<Database>;
let ownerId = "";
let otherId = "";
let visitId = "";
let placeId = "";
let tripId = "";
let privatePath = "";
let visitPath = "";
let placePath = "";
const accounts: string[] = [];
const paths: string[] = [];

async function account(label: string) {
  const email = `security-${label}-${crypto.randomUUID()}@example.test`;
  const password = crypto.randomUUID();
  const created = await admin.auth.admin.createUser({
    email, password, email_confirm: true,
    user_metadata: { display_name: `Security fixture ${label}` },
  });
  if (created.error || !created.data.user) throw new Error("Could not create disposable test account");
  accounts.push(created.data.user.id);
  const signed = client(publicKey);
  const login = await signed.auth.signInWithPassword({ email, password });
  if (login.error) throw new Error("Could not sign in disposable test account");
  return { client: signed, id: created.data.user.id };
}

beforeAll(async () => {
  const a = await account("owner");
  owner = a.client; ownerId = a.id;
  const b = await account("other");
  other = b.client; otherId = b.id;
  const profile = await owner.from("profiles").update({ emergency_contact_phone: "+910000000001" }).eq("id", ownerId);
  expect(profile.error).toBeNull();

  // Real image uploads cover both layouts used by visit and discovery flows.
  const image = Uint8Array.from(atob("iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAIAAAAlC+aJAAAA70lEQVR4nO2asQ3CMBBFCaJmH1iGloZpaGgZgg1QBmICCjcUJjrb33o66b8ysZT/fI7jk7Kc3q9dZvZ0gFEsQGMBGgvQWIDGAjSHyKD1+Zid4x/ny3V7QPoKWIDGAjQWoLEATehL3MPtU7l4P8qfM0GgGv33llRDvYQ20jeNCSMViCfTOegEWjOJHEQCfWkUDum3UYXAyEQOF8EVoLEAjQVoFAIjh7Phg50rUOibSMW5WleB1jSirkC6hOKZdD2N+h2IJJN2ZBNaypIvcU9cmJC1irdRGgvQWIDGAjTpBRb/9AdjARoL0FiAxgI06QW+WP8jjjPBUUMAAAAASUVORK5CYII="), c => c.charCodeAt(0));
  privatePath = `${ownerId}/security-private.png`;
  visitPath = `${ownerId}/security-visit.png`;
  placePath = `places/${ownerId}/security-place.png`;
  for (const path of [privatePath, visitPath, placePath]) {
    paths.push(path);
    const upload = await owner.storage.from("checkin-photos").upload(path, image, { contentType: "image/png" });
    expect(upload.error).toBeNull();
  }

  const site = await anon.from("heritage_sites").select("id").eq("name", "Qutub Minar").single();
  expect(site.error).toBeNull();
  if (!site.data) throw new Error("Site fixture unavailable");
  const trip = await owner.from("trips").insert({ user_id: ownerId, title: "Security disposable trip", budget_inr: 5000 }).select("id").single();
  expect(trip.error).toBeNull();
  if (!trip.data) throw new Error("Trip fixture unavailable");
  tripId = trip.data.id;
  const member = await admin.from("trip_members").insert({ user_id: otherId, trip_id: tripId });
  expect(member.error).toBeNull();
  const visit = await owner.from("visits").insert({
    user_id: ownerId, site_id: site.data.id, photo_url: visitPath, caption: "Security disposable visit",
    latitude: 28.5245, longitude: 77.1855, trip_id: tripId,
  }).select("id").single();
  expect(visit.error).toBeNull();
  if (!visit.data) throw new Error("Visit fixture unavailable");
  visitId = visit.data.id;
  const place = await owner.from("discovered_places").insert({
    created_by: ownerId, name: "Security disposable place", region: "Delhi", story: "Disposable access-control test",
    latitude: 28.5245, longitude: 77.1855, photo_url: placePath,
  }).select("id").single();
  expect(place.error).toBeNull();
  if (!place.data) throw new Error("Place fixture unavailable");
  placeId = place.data.id;
  const verification = await other.from("place_verifications").insert({ place_id: placeId, user_id: otherId, latitude: 28.5245, longitude: 77.1855, note: "Private test verifier note" });
  expect(verification.error).toBeNull();
  const comment = await other.from("visit_comments").insert({ visit_id: visitId, user_id: otherId, body: "Public test comment" });
  expect(comment.error).toBeNull();
  const like = await other.from("visit_likes").insert({ visit_id: visitId, user_id: otherId });
  expect(like.error).toBeNull();
}, 60000);

afterAll(async () => {
  if (paths.length) expect((await admin.storage.from("checkin-photos").remove(paths)).error).toBeNull();
  if (placeId) {
    expect((await admin.from("place_verifications").delete().eq("place_id", placeId)).error).toBeNull();
    expect((await admin.from("discovered_places").delete().eq("id", placeId)).error).toBeNull();
  }
  if (visitId) expect((await admin.from("visits").delete().eq("id", visitId)).error).toBeNull();
  if (tripId) expect((await admin.from("trips").delete().eq("id", tripId)).error).toBeNull();
  for (const id of accounts) expect((await admin.auth.admin.deleteUser(id)).error).toBeNull();
}, 60000);

test("verification coordinates and notes are readable only by their author", async () => {
  const own = await other.from("place_verifications").select("*").eq("place_id", placeId);
  expect(own.data?.[0]?.note).toBe("Private test verifier note");
  expect((await owner.from("place_verifications").select("*").eq("place_id", placeId)).data).toEqual([]);
  expect((await anon.from("place_verifications").select("*")).error).not.toBeNull();
});

test("legacy check-ins reject anonymous and authenticated reads and inserts", async () => {
  for (const caller of [anon, owner]) {
    expect((await caller.from("check_ins").select("*")).error).not.toBeNull();
    expect((await caller.from("check_ins").insert({ user_id: ownerId, site_id: crypto.randomUUID() })).error?.code).toBe("42501");
  }
});

test("legacy demo scores cannot be read or changed by clients", async () => {
  for (const caller of [anon, owner]) {
    expect((await caller.from("app_users").select("*")).error).not.toBeNull();
    expect((await caller.from("app_users").update({ xp: 999999 }).eq("id", "11111111-1111-1111-1111-111111111111")).error?.code).toBe("42501");
  }
});

test("emergency contacts are owner-only while rankings exclude private fields", async () => {
  const own = await owner.from("profiles").select("emergency_contact_phone").eq("id", ownerId).single();
  expect(own.data?.emergency_contact_phone).toBe("+910000000001");
  expect((await other.from("profiles").select("*").eq("id", ownerId)).data).toEqual([]);
  expect((await anon.from("profiles").select("*")).error).not.toBeNull();
  const ranking = await anon.rpc("get_public_leaderboard");
  expect(ranking.error).toBeNull();
  const card = ranking.data?.find(row => row.id === ownerId);
  expect(card).toBeDefined();
  expect(card).not.toHaveProperty("emergency_contact_phone");
  expect(card).not.toHaveProperty("location_consent");
  expect(card?.last_check_in_date).toBeNull();
});

test("raw comments are owner-only but published comment text remains visible", async () => {
  expect((await other.from("visit_comments").select("body").eq("visit_id", visitId)).data?.[0]?.body).toBe("Public test comment");
  expect((await owner.from("visit_comments").select("*").eq("visit_id", visitId)).data).toEqual([]);
  expect((await anon.from("visit_comments").select("*")).error).not.toBeNull();
  const cards = await anon.rpc("get_visit_cards");
  const card = (cards.data ?? []).find(row => typeof row === "object" && row !== null && !Array.isArray(row) && row["id"] === visitId);
  expect(card).toHaveProperty("visit_comments.0.body", "Public test comment");
});

test("raw likes are owner-only while public cards expose counts, not other identities", async () => {
  expect((await other.from("visit_likes").select("user_id").eq("visit_id", visitId)).data?.[0]?.user_id).toBe(otherId);
  expect((await owner.from("visit_likes").select("*").eq("visit_id", visitId)).data).toEqual([]);
  expect((await anon.from("visit_likes").select("*")).error).not.toBeNull();
  const cards = await anon.rpc("get_visit_cards");
  const card = (cards.data ?? []).find(row => typeof row === "object" && row !== null && !Array.isArray(row) && row["id"] === visitId);
  expect(card).toHaveProperty("like_count", 1);
  expect(card).toHaveProperty("visit_likes", []);
});

test("private visit locations remain owner-only, including shared trip summaries", async () => {
  expect((await owner.from("visits").select("latitude").eq("id", visitId)).data?.[0]?.latitude).toBe(28.5245);
  expect((await other.from("visits").select("*").eq("id", visitId)).data).toEqual([]);
  expect((await anon.from("visits").select("*")).error).not.toBeNull();
  for (const caller of [anon, other]) {
    const cards = await caller.rpc("get_visit_cards");
    const card = (cards.data ?? []).find(row => typeof row === "object" && row !== null && !Array.isArray(row) && row["id"] === visitId);
    expect(card).toHaveProperty("latitude", null);
    expect(card).toHaveProperty("longitude", null);
    expect(card).toHaveProperty("photo_url", null);
    expect(card).not.toHaveProperty("trip_id");
  }
  const tripCards = await other.rpc("get_visit_cards", { _scope: "trip", _trip_id: tripId });
  expect(tripCards.error).toBeNull();
  expect(tripCards.data?.[0]).toHaveProperty("latitude", null);
  expect((await anon.rpc("get_visit_cards", { _scope: "trip", _trip_id: tripId })).error?.code).toBe("42501");
  expect((await other.rpc("get_visit_cards", { _scope: "trip", _trip_id: crypto.randomUUID() })).error?.code).toBe("42501");
  expect((await anon.rpc("get_visit_cards", { _scope: "own" })).error?.code).toBe("42501");
});

test("unshared photo downloads are owner-only and public signing requires a matching published attachment", async () => {
  expect((await owner.storage.from("checkin-photos").createSignedUrl(privatePath, 60)).error).toBeNull();
  for (const caller of [anon, other]) {
    expect((await caller.storage.from("checkin-photos").createSignedUrl(privatePath, 60)).error).not.toBeNull();
  }
  expect((await anon.rpc("get_public_photo_reference", { _kind: "visit", _record_id: visitId })).data).toBe(visitPath);
  expect((await anon.rpc("get_public_photo_reference", { _kind: "place", _record_id: placeId })).data).toBe(placePath);
  expect((await anon.rpc("get_public_photo_reference", { _kind: "visit", _record_id: crypto.randomUUID() })).data).toBeNull();
  // A post cannot publish somebody else's private upload by copying its path.
  const forged = await other.from("visits").insert({ user_id: otherId, site_id: (await anon.from("heritage_sites").select("id").limit(1).single()).data?.id ?? "", photo_url: privatePath }).select("id").single();
  expect(forged.error).toBeNull();
  if (!forged.data) throw new Error("Forged attachment fixture unavailable");
  try {
    expect((await anon.rpc("get_public_photo_reference", { _kind: "visit", _record_id: forged.data.id })).data).toBeNull();
  } finally {
    expect((await other.from("visits").delete().eq("id", forged.data.id)).error).toBeNull();
  }
});

test("uploads require sign-in, matching ownership, and either supported owner folder", async () => {
  for (const caller of [anon, other]) {
    for (const prefix of [ownerId, `places/${ownerId}`]) {
      const path = `${prefix}/security-denied-${crypto.randomUUID()}.png`;
      paths.push(path);
      expect((await caller.storage.from("checkin-photos").upload(path, new Uint8Array([1]), { contentType: "image/png" })).error).not.toBeNull();
    }
  }
  for (const path of [visitPath, placePath]) {
    expect((await owner.storage.from("checkin-photos").createSignedUrl(path, 60)).error).toBeNull();
  }
});

test("public place summaries keep trust counts without verifier coordinates or notes", async () => {
  const publicCards = await anon.rpc("get_public_place_cards");
  const card = (publicCards.data ?? []).find(row => typeof row === "object" && row !== null && !Array.isArray(row) && row["id"] === placeId);
  expect(card).toHaveProperty("verification_count", 1);
  expect(card).toHaveProperty("place_verifications", []);
  expect(JSON.stringify(card)).not.toContain("Private test verifier note");
  const ownCards = await other.rpc("get_public_place_cards");
  const ownCard = (ownCards.data ?? []).find(row => typeof row === "object" && row !== null && !Array.isArray(row) && row["id"] === placeId);
  expect(ownCard).toHaveProperty("place_verifications.0.user_id", otherId);
  expect(ownCard).not.toHaveProperty("place_verifications.0.latitude");
});

// Allows the agent's browser check to run against these same live fixtures
// before cleanup, without passing any private credentials to the browser.
if (process.env["SECURITY_BROWSER_SCRIPT"]) {
  test("live website preserves shared photos, comments, likes, and signed-in passport", async () => {
    const script = required("SECURITY_BROWSER_SCRIPT");
    const processHandle = Bun.spawn(["python3", script], {
      env: { ...process.env, SECURITY_FIXTURE_VISIT: visitId, SECURITY_FIXTURE_PLACE: placeId },
      stdout: "inherit", stderr: "inherit",
    });
    expect(await processHandle.exited).toBe(0);
  }, 120000);
}