# Selected security fixes

- [x] Restrict the seven selected legacy and private-data access rules.
- [x] Restrict the two selected photo rules to authenticated owners.
- [x] Preserve public social summaries and explicitly shared photos.
- [x] Test owner access, denied access, social flows, and photo sharing.
- [x] Mark only the nine selected findings as fixed.

## Rule and surface audit

Private contacts, personal visit/verification locations, and unshared uploads stay owner-only; intentionally shared social content stays public.

- Home recommendations and photo quests: read own profile/visits; public place and ranking projections. Photo quest count preserved.
- Feed and saved posts: safe visit/comment summaries, aggregate likes, caller-only location and liked state; shared photos authorized by record.
- Passport/preferences and SOS: own profile reads still include the owner's emergency contact and preferences. SOS permissions unchanged.
- Global/state/activity rankings: fixed-field projections, no contacts, preferences, or personal locations.
- Discovery/verification: public place cards keep aggregate trust; verification locations/notes remain author-only. Existing submission permissions unchanged.
- Site check-ins and photo uploads: own visit insert/read permissions unchanged; both owner folder layouts remain supported.
- Trip visit contributions: membership-checked summaries; another member's private locations remain hidden. Other trip/expense permissions unchanged.
- Sign-in/sign-out and offline reads: private query caches cleared on sign-out; caller-specific public cards reset. Offline places contain public summaries, not verifier locations or notes.
- Database reward/signup triggers and AI planner/copilot: code reviewed; remain unchanged because they do not expose the selected private records.
- Home loading warning observed during browser verification: outside the selected security scope and left unchanged.