# TravelStrava project source

This archive contains the application source, site photos and other local assets, public files, configuration, dependency lockfile, database schema and migrations, and security tests.

## Run locally

1. Install Bun.
2. Copy `.env.example` to `.env` and supply the public browser configuration for your environment.
3. Run `bun install`.
4. Run `bun run dev` and open the local address displayed by the development server.

## Connected services

The source archive does not export hosted database records, user accounts, uploaded user photos, or private service credentials. These remain in Lovable Cloud. AI, Maps, authentication, and shared photo signing depend on their configured services and hosting secrets; they are not an offline, self-contained copy of those services.

Database schema and migrations are included under `drizzle/`; migrating data to different hosting is a separate task.

## Archive exclusions

Git history, platform-only metadata, `.env`, installed dependencies, build output, caches, and private keys are intentionally excluded. `.env.example` contains variable names only.

The opt-in security integration tests require their dedicated test environment and disposable accounts; do not run them against existing user data.
