export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.17"
  }
  public: {
    Tables: {
      app_users: {
        Row: {
          avatar_initials: string
          created_at: string
          id: string
          name: string
          xp: number
        }
        Insert: {
          avatar_initials: string
          created_at?: string
          id?: string
          name: string
          xp?: number
        }
        Update: {
          avatar_initials?: string
          created_at?: string
          id?: string
          name?: string
          xp?: number
        }
        Relationships: []
      }
      check_ins: {
        Row: {
          caption: string | null
          created_at: string
          id: string
          photo_url: string | null
          site_id: string
          user_id: string
        }
        Insert: {
          caption?: string | null
          created_at?: string
          id?: string
          photo_url?: string | null
          site_id: string
          user_id: string
        }
        Update: {
          caption?: string | null
          created_at?: string
          id?: string
          photo_url?: string | null
          site_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "check_ins_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "heritage_sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "check_ins_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "app_users"
            referencedColumns: ["id"]
          },
        ]
      }
      discovered_places: {
        Row: {
          access_notes: string | null
          best_time: string | null
          category: string
          created_at: string
          created_by: string
          id: string
          latitude: number
          longitude: number
          name: string
          photo_url: string | null
          region: string
          status: string
          story: string
          verification_count: number
        }
        Insert: {
          access_notes?: string | null
          best_time?: string | null
          category?: string
          created_at?: string
          created_by: string
          id?: string
          latitude: number
          longitude: number
          name: string
          photo_url?: string | null
          region: string
          status?: string
          story: string
          verification_count?: number
        }
        Update: {
          access_notes?: string | null
          best_time?: string | null
          category?: string
          created_at?: string
          created_by?: string
          id?: string
          latitude?: number
          longitude?: number
          name?: string
          photo_url?: string | null
          region?: string
          status?: string
          story?: string
          verification_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "discovered_places_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      heritage_sites: {
        Row: {
          accessibility_notes: string | null
          best_time: string | null
          created_at: string
          crowd_level: string | null
          emergency_contact: string | null
          entry_fee_inr: number | null
          etiquette: string | null
          guide_fee_inr: number | null
          history_blurb: string
          id: string
          latitude: number
          local_legend: string | null
          longitude: number
          name: string
          photo_spot: string | null
          region: string
          safety_notes: string
          stamp_code: string
          stamp_color: string
          visitors_per_year: number | null
          women_safety_rating: number | null
          xp_reward: number
        }
        Insert: {
          accessibility_notes?: string | null
          best_time?: string | null
          created_at?: string
          crowd_level?: string | null
          emergency_contact?: string | null
          entry_fee_inr?: number | null
          etiquette?: string | null
          guide_fee_inr?: number | null
          history_blurb: string
          id?: string
          latitude: number
          local_legend?: string | null
          longitude: number
          name: string
          photo_spot?: string | null
          region: string
          safety_notes: string
          stamp_code: string
          stamp_color: string
          visitors_per_year?: number | null
          women_safety_rating?: number | null
          xp_reward?: number
        }
        Update: {
          accessibility_notes?: string | null
          best_time?: string | null
          created_at?: string
          crowd_level?: string | null
          emergency_contact?: string | null
          entry_fee_inr?: number | null
          etiquette?: string | null
          guide_fee_inr?: number | null
          history_blurb?: string
          id?: string
          latitude?: number
          local_legend?: string | null
          longitude?: number
          name?: string
          photo_spot?: string | null
          region?: string
          safety_notes?: string
          stamp_code?: string
          stamp_color?: string
          visitors_per_year?: number | null
          women_safety_rating?: number | null
          xp_reward?: number
        }
        Relationships: []
      }
      local_vendors: {
        Row: {
          added_by: string | null
          contact: string | null
          created_at: string
          description: string | null
          id: string
          name: string
          place_id: string | null
          price_from_inr: number | null
          site_id: string | null
          vendor_type: string
        }
        Insert: {
          added_by?: string | null
          contact?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name: string
          place_id?: string | null
          price_from_inr?: number | null
          site_id?: string | null
          vendor_type?: string
        }
        Update: {
          added_by?: string | null
          contact?: string | null
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          place_id?: string | null
          price_from_inr?: number | null
          site_id?: string | null
          vendor_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "local_vendors_added_by_fkey"
            columns: ["added_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "local_vendors_place_id_fkey"
            columns: ["place_id"]
            isOneToOne: false
            referencedRelation: "discovered_places"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "local_vendors_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "heritage_sites"
            referencedColumns: ["id"]
          },
        ]
      }
      place_verifications: {
        Row: {
          created_at: string
          distance_m: number
          id: string
          latitude: number
          longitude: number
          note: string | null
          place_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          distance_m?: number
          id?: string
          latitude: number
          longitude: number
          note?: string | null
          place_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          distance_m?: number
          id?: string
          latitude?: number
          longitude?: number
          note?: string | null
          place_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "place_verifications_place_id_fkey"
            columns: ["place_id"]
            isOneToOne: false
            referencedRelation: "discovered_places"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "place_verifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_initials: string
          created_at: string
          current_streak: number
          display_name: string
          emergency_contact_phone: string | null
          home_region: string | null
          id: string
          last_check_in_date: string | null
          location_consent: boolean
          longest_streak: number
          places_added: number
          places_verified: number
          safety_alert_consent: boolean
          traveler_class: string
          xp: number
        }
        Insert: {
          avatar_initials?: string
          created_at?: string
          current_streak?: number
          display_name?: string
          emergency_contact_phone?: string | null
          home_region?: string | null
          id: string
          last_check_in_date?: string | null
          location_consent?: boolean
          longest_streak?: number
          places_added?: number
          places_verified?: number
          safety_alert_consent?: boolean
          traveler_class?: string
          xp?: number
        }
        Update: {
          avatar_initials?: string
          created_at?: string
          current_streak?: number
          display_name?: string
          emergency_contact_phone?: string | null
          home_region?: string | null
          id?: string
          last_check_in_date?: string | null
          location_consent?: boolean
          longest_streak?: number
          places_added?: number
          places_verified?: number
          safety_alert_consent?: boolean
          traveler_class?: string
          xp?: number
        }
        Relationships: []
      }
      sos_events: {
        Row: {
          created_at: string
          id: string
          latitude: number | null
          longitude: number | null
          note: string | null
          resolved: boolean
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          note?: string | null
          resolved?: boolean
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          note?: string | null
          resolved?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sos_events_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      trip_expenses: {
        Row: {
          amount_inr: number
          category: string
          created_at: string
          id: string
          label: string
          trip_id: string
          user_id: string
        }
        Insert: {
          amount_inr?: number
          category?: string
          created_at?: string
          id?: string
          label: string
          trip_id: string
          user_id: string
        }
        Update: {
          amount_inr?: number
          category?: string
          created_at?: string
          id?: string
          label?: string
          trip_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trip_expenses_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "trip_expenses_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      trip_members: {
        Row: {
          id: string
          joined_at: string
          trip_id: string
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string
          trip_id: string
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string
          trip_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trip_members_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
        ]
      }
      trips: {
        Row: {
          budget_inr: number
          created_at: string
          end_date: string | null
          id: string
          invite_code: string | null
          start_date: string | null
          title: string
          user_id: string
        }
        Insert: {
          budget_inr?: number
          created_at?: string
          end_date?: string | null
          id?: string
          invite_code?: string | null
          start_date?: string | null
          title: string
          user_id: string
        }
        Update: {
          budget_inr?: number
          created_at?: string
          end_date?: string | null
          id?: string
          invite_code?: string | null
          start_date?: string | null
          title?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "trips_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      visit_comments: {
        Row: {
          body: string
          created_at: string
          id: string
          user_id: string
          visit_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          user_id: string
          visit_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          user_id?: string
          visit_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "visit_comments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "visit_comments_visit_id_fkey"
            columns: ["visit_id"]
            isOneToOne: false
            referencedRelation: "visits"
            referencedColumns: ["id"]
          },
        ]
      }
      visit_likes: {
        Row: {
          created_at: string
          id: string
          user_id: string
          visit_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          user_id: string
          visit_id: string
        }
        Update: {
          created_at?: string
          id?: string
          user_id?: string
          visit_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "visit_likes_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "visit_likes_visit_id_fkey"
            columns: ["visit_id"]
            isOneToOne: false
            referencedRelation: "visits"
            referencedColumns: ["id"]
          },
        ]
      }
      visit_saves: {
        Row: {
          created_at: string
          id: string
          user_id: string
          visit_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          user_id: string
          visit_id: string
        }
        Update: {
          created_at?: string
          id?: string
          user_id?: string
          visit_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "visit_saves_visit_id_fkey"
            columns: ["visit_id"]
            isOneToOne: false
            referencedRelation: "visits"
            referencedColumns: ["id"]
          },
        ]
      }
      visits: {
        Row: {
          activity_type: string
          caption: string | null
          created_at: string
          id: string
          latitude: number | null
          longitude: number | null
          photo_url: string | null
          responsible_pledge: boolean
          site_id: string
          trip_id: string | null
          user_id: string
          xp_awarded: number
        }
        Insert: {
          activity_type?: string
          caption?: string | null
          created_at?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          photo_url?: string | null
          responsible_pledge?: boolean
          site_id: string
          trip_id?: string | null
          user_id: string
          xp_awarded?: number
        }
        Update: {
          activity_type?: string
          caption?: string | null
          created_at?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          photo_url?: string | null
          responsible_pledge?: boolean
          site_id?: string
          trip_id?: string | null
          user_id?: string
          xp_awarded?: number
        }
        Relationships: [
          {
            foreignKeyName: "visits_site_id_fkey"
            columns: ["site_id"]
            isOneToOne: false
            referencedRelation: "heritage_sites"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "visits_trip_id_fkey"
            columns: ["trip_id"]
            isOneToOne: false
            referencedRelation: "trips"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "visits_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_invite_code: { Args: never; Returns: string }
      get_public_leaderboard: {
        Args: never
        Returns: {
          avatar_initials: string
          current_streak: number
          display_name: string
          home_region: string
          id: string
          last_check_in_date: string
          longest_streak: number
          xp: number
        }[]
      }
      get_public_photo_reference: {
        Args: { _kind: string; _record_id: string }
        Returns: string
      }
      get_public_place_cards: { Args: never; Returns: Json[] }
      get_public_ranking_visits: { Args: never; Returns: Json[] }
      get_visit_cards: {
        Args: { _scope?: string; _trip_id?: string }
        Returns: Json[]
      }
      is_trip_member: {
        Args: { _trip_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
