import { useEffect, useState } from "react";

export function useOnline() {
  const [online, setOnline] = useState(true);

  useEffect(() => {
    setOnline(navigator.onLine);
    const goOnline = () => setOnline(true);
    const goOffline = () => setOnline(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  return online;
}

/**
 * Keeps the last successful payload in local storage so the page still shows
 * something useful when the traveller loses signal at a site.
 */
export function useOfflineCache<T>(key: string, data: T | undefined): T | undefined {
  const [cached, setCached] = useState<T | undefined>(undefined);

  useEffect(() => {
    if (data !== undefined) {
      try {
        localStorage.setItem(`ts-cache:${key}`, JSON.stringify(data));
      } catch {
        /* storage full or blocked — cache is best effort */
      }
      return;
    }
    try {
      const raw = localStorage.getItem(`ts-cache:${key}`);
      if (raw) setCached(JSON.parse(raw) as T);
    } catch {
      /* ignore unreadable cache */
    }
  }, [key, data]);

  return data ?? cached;
}
