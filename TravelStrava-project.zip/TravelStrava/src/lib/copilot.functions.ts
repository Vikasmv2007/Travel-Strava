import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";

const schema = z.object({ question: z.string().min(2).max(500) });

export const askCopilot = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => schema.parse(data))
  .handler(async ({ data }) => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) {
      return { answer: "The copilot is not configured yet. Try again shortly." };
    }

    const supabase = createClient(
      process.env["SUPABASE_URL"] ?? process.env["VITE_SUPABASE_URL"]!,
      process.env["SUPABASE_PUBLISHABLE_KEY"] ??
        process.env["VITE_SUPABASE_PUBLISHABLE_KEY"]!,
      { auth: { persistSession: false } },
    );

    const { data: sites } = await supabase
      .from("heritage_sites")
      .select("name, region, history_blurb, safety_notes");

    const context = (sites ?? [])
      .map(
        (s) =>
          `${s.name} (${s.region}). History: ${s.history_blurb} Safety: ${s.safety_notes}`,
      )
      .join("\n");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3.8-flash",
        messages: [
          {
            role: "system",
            content: `You are a friendly heritage travel guide for India. Answer in 3 short sentences or fewer, warm and practical. Here is what you know about the sites in this app:\n${context}`,
          },
          { role: "user", content: data.question },
        ],
      }),
    });

    if (!res.ok) {
      if (res.status === 429) {
        return { answer: "Too many questions at once — give it a moment and ask again." };
      }
      return { answer: "The copilot could not answer that right now. Try again." };
    }

    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    return {
      answer:
        json.choices?.[0]?.message?.content?.trim() ??
        "I do not have an answer for that one.",
    };
  });

const budgetSchema = z.object({
  title: z.string().min(1).max(120),
  budget: z.number().int().nonnegative(),
  spent: z.number().int().nonnegative(),
  breakdown: z.array(z.object({ category: z.string(), amount: z.number() })).max(20),
});

export const suggestBudgetSavings = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => budgetSchema.parse(data))
  .handler(async ({ data }) => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) {
      return { tips: "Budget coaching is not configured yet." };
    }

    const lines = data.breakdown
      .map((row) => `${row.category}: ₹${row.amount}`)
      .join(", ");

    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3.8-flash",
        messages: [
          {
            role: "system",
            content:
              "You coach Indian heritage travellers on budgets. Reply with 3 short bullet lines, each a concrete saving or plan tweak with an approximate rupee impact. No preamble.",
          },
          {
            role: "user",
            content: `Trip: ${data.title}. Budget ₹${data.budget}. Spent so far ₹${data.spent}. Breakdown: ${lines || "nothing logged yet"}.`,
          },
        ],
      }),
    });

    if (!res.ok) {
      if (res.status === 429) {
        return { tips: "Too many requests right now — try again in a moment." };
      }
      return { tips: "Could not fetch savings ideas right now." };
    }

    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    return { tips: json.choices?.[0]?.message?.content?.trim() ?? "No ideas right now." };
  });
