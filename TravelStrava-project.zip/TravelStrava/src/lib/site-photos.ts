import ajanta from "@/assets/sites/ajanta-caves.jpg";
import hawaMahal from "@/assets/sites/hawa-mahal.jpg";
import cityPalace from "@/assets/sites/jaipur-city-palace.jpg";
import konark from "@/assets/sites/konark-sun-temple.jpg";
import qutub from "@/assets/sites/qutub-minar.jpg";
import sanchi from "@/assets/sites/sanchi-stupa.jpg";
import shore from "@/assets/sites/shore-temple.jpg";
import taj from "@/assets/sites/taj-mahal.jpg";
import varanasi from "@/assets/sites/varanasi-ghats.jpg";
import virupaksha from "@/assets/sites/virupaksha-temple.jpg";

const photos: Record<string, string> = {
  "ajanta caves": ajanta,
  "hawa mahal": hawaMahal,
  "jaipur city palace": cityPalace,
  "konark sun temple": konark,
  "qutub minar": qutub,
  "sanchi stupa": sanchi,
  "shore temple": shore,
  "taj mahal": taj,
  "varanasi ghats": varanasi,
  "virupaksha temple": virupaksha,
};

/** Photo of a listed heritage site, sourced from Google Maps place photos. */
export function sitePhoto(name: string): string | null {
  return photos[name.trim().toLowerCase()] ?? null;
}
