import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useRouter } from "@tanstack/react-router";
import type { User } from "@supabase/supabase-js";

import { supabase } from "@/integrations/supabase/client";

type SessionValue = { user: User | null; loading: boolean };

const SessionContext = createContext<SessionValue>({ user: null, loading: true });

export function SessionProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<SessionValue>({ user: null, loading: true });
  const queryClient = useQueryClient();
  const router = useRouter();

  useEffect(() => {
    let active = true;

    supabase.auth.getSession().then(({ data }) => {
      if (active) setState({ user: data.session?.user ?? null, loading: false });
    });

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (!active) return;
      setState({ user: session?.user ?? null, loading: false });
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") {
        return;
      }
      if (event === "SIGNED_OUT") {
        const privateKeys = new Set([
          "profile", "visits", "saves", "trip", "trips", "trip-visits",
          "trip-members", "expenses",
        ]);
        queryClient.removeQueries({
          predicate: (query) => privateKeys.has(String(query.queryKey[0])),
        });
        // Public cards include caller-only GPS/liked/verified state. Discard
        // their previous authenticated results instead of retaining them.
        void queryClient.resetQueries({
          predicate: (query) => query.queryKey[0] === "feed" || query.queryKey[0] === "places",
        });
      } else {
        void queryClient.invalidateQueries();
      }
      router.invalidate();
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [queryClient, router]);

  return <SessionContext.Provider value={state}>{children}</SessionContext.Provider>;
}

export function useSession() {
  return useContext(SessionContext);
}
