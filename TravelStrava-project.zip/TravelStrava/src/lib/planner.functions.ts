import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createClient } from "@supabase/supabase-js";

const planSchema = z.object({
  city: z.string().min(2).max(60),
  days: z.number().int().min(1).max(14),
  budgetInr: z.number().int().min(500).max(500000),
  style: z.enum(["shoestring", "value", "comfort"]),
});

export type PlanStop = {
  name: string;
  why: string;
  entry_inr: number;
  hours: string;
  xp: number;
};

export type PlanDay = {
  day: number;
  theme: string;
  base: string;
  stops: PlanStop[];
  food: string;
  transport: string;
  day_cost_inr: number;
};

export type QuestPlan = {
  city: string;
  days: number;
  stay: Array<{ area: string; why: string; per_night_inr: number; type: string }>;
  itinerary: PlanDay[];
  total_cost_inr: number;
  money_tips: string[];
};

const fallback = (city: string, days: number, reason = ""): QuestPlan => {
  if (reason) console.error(`Planner fallback: ${reason}`);
  return {
    city,
    days,
    stay: [],
    itinerary: [],
    total_cost_inr: 0,
    money_tips: ["The planner could not answer right now. Try again in a moment."],
  };
};


export const planQuest = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => planSchema.parse(data))
  .handler(async ({ data }): Promise<QuestPlan> => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return fallback(data.city, data.days, "no key");

    const supabase = createClient(
      process.env["SUPABASE_URL"] ?? process.env["VITE_SUPABASE_URL"]!,
      process.env["SUPABASE_PUBLISHABLE_KEY"] ??
        process.env["VITE_SUPABASE_PUBLISHABLE_KEY"]!,
      { auth: { persistSession: false } },
    );

    const [{ data: sites }, { data: places }] = await Promise.all([
      supabase
        .from("heritage_sites")
        .select("name, region, entry_fee_inr, best_time, crowd_level"),
      supabase.from("discovered_places").select("name, region, category, status"),
    ]);

    const known = [
      ...(sites ?? []).map(
        (s) =>
          `${s.name} (${s.region}) entry ₹${s.entry_fee_inr ?? 0}, best ${s.best_time ?? "morning"}, crowds ${s.crowd_level ?? "moderate"}`,
      ),
      ...(places ?? []).map(
        (p) => `${p.name} (${p.region}) community-found ${p.category} [${p.status}]`,
      ),
    ].join("\n");

    const styleLine = {
      shoestring: "Ultra low budget: dorms/hostels, metro and buses, street food only.",
      value: "Low budget but comfortable: budget guesthouses, metro, local eateries.",
      comfort: "Mid budget: 3-star or good homestays, some cabs, sit-down meals.",
    }[data.style];

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 55000);
    let res: Response;
    try {
      res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        signal: controller.signal,
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3.8-flash",
          max_tokens: 8000,
          response_format: { type: "json_object" },

        messages: [
          {
            role: "system",
            content: `You plan heritage trips in India and answer ONLY with JSON matching this shape:
{"city":string,"days":number,"stay":[{"area":string,"why":string,"per_night_inr":number,"type":string}],"itinerary":[{"day":number,"theme":string,"base":string,"stops":[{"name":string,"why":string,"entry_inr":number,"hours":string,"xp":number}],"food":string,"transport":string,"day_cost_inr":number}],"total_cost_inr":number,"money_tips":[string]}
Rules: pack 3-5 real stops per day, cluster them geographically so travel is short, keep the whole trip inside the stated budget, give 2-3 stay areas chosen for being WALKABLE to that day's clusters, xp is 10 for a famous monument and 20 for an offbeat one, all costs in rupees, money_tips has 3 short lines. Keep every "why", "food" and "transport" value under 18 words. Prefer sites from this app's list when they are in or near the city:\n${known}`,
          },
          {
            role: "user",
            content: `City: ${data.city}. Days: ${data.days}. Total budget including stay, food, travel, tickets: ₹${data.budgetInr}. ${styleLine}`,
          },
          ],
        }),
      });
    } catch (err) {
      clearTimeout(timer);
      return fallback(data.city, data.days, `abort ${String(err).slice(0,80)}`);
    }
    clearTimeout(timer);

    if (!res.ok) {
      return fallback(data.city, data.days, `http ${res.status} ${(await res.text()).slice(0,120)}`);
    }


    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const raw = json.choices?.[0]?.message?.content?.trim() ?? "";
    const body = raw.replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
    try {
      const parsed = JSON.parse(body) as QuestPlan;
      return {
        city: parsed.city ?? data.city,
        days: parsed.days ?? data.days,
        stay: Array.isArray(parsed.stay) ? parsed.stay : [],
        itinerary: Array.isArray(parsed.itinerary) ? parsed.itinerary : [],
        total_cost_inr: Number(parsed.total_cost_inr) || 0,
        money_tips: Array.isArray(parsed.money_tips) ? parsed.money_tips : [],
      };
    } catch {
      return fallback(data.city, data.days, `parse len=${body.length} tail=${body.slice(-80)}`);
    }
  });
