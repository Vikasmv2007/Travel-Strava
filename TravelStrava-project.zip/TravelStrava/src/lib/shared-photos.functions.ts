import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";

const photoRequest = z.object({
  kind: z.enum(["visit", "place"]),
  recordId: z.string().uuid(),
});

// Public by design: only explicitly published, author-owned attachments qualify.
// The caller cannot supply a bucket, object path, owner, or expiry.
export const getSharedPhoto = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => photoRequest.parse(input))
  .handler(async ({ data }): Promise<string | null> => {
    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) return null;

    const publicClient = createClient<Database>(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => {
          const headers = new Headers(init?.headers);
          if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) {
            headers.delete("Authorization");
          }
          headers.set("apikey", key);
          return fetch(input, { ...init, headers });
        },
      },
    });

    const { data: path, error } = await publicClient.rpc("get_public_photo_reference", {
      _kind: data.kind,
      _record_id: data.recordId,
    });
    if (error || !path) return null;

    // Privileged signing is allowed only after the database verified that the
    // attachment is published and its storage owner matches the post author.
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: signed, error: signError } = await supabaseAdmin.storage
      .from("checkin-photos")
      .createSignedUrl(path, 60 * 60);
    return signError ? null : signed?.signedUrl ?? null;
  });