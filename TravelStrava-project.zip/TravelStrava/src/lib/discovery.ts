import { supabase } from "@/integrations/supabase/client";
import type { HeritageSite, Profile } from "@/lib/travelstrava";
import { getSharedPhoto } from "@/lib/shared-photos.functions";

export type DiscoveredPlace = {
  id: string;
  created_by: string;
  name: string;
  region: string;
  category: string;
  story: string;
  access_notes: string | null;
  best_time: string | null;
  latitude: number;
  longitude: number;
  photo_url: string | null;
  signedPhoto: string | null;
  verification_count: number;
  status: string;
  created_at: string;
  profiles: { display_name: string; avatar_initials: string } | null;
  place_verifications: Array<{ user_id: string }>;
};

export type LocalVendor = {
  id: string;
  name: string;
  vendor_type: string;
  description: string | null;
  contact: string | null;
  price_from_inr: number | null;
  place_id: string | null;
  site_id: string | null;
};

export const PLACE_CATEGORIES = [
  { value: "hidden_heritage", label: "Hidden heritage" },
  { value: "stepwell", label: "Stepwell / water body" },
  { value: "temple", label: "Lesser-known temple" },
  { value: "craft_village", label: "Craft village" },
  { value: "viewpoint", label: "Viewpoint / trail" },
  { value: "food_trail", label: "Food trail" },
] as const;

export const VENDOR_TYPES = [
  { value: "homestay", label: "Homestay", emoji: "🏠" },
  { value: "guide", label: "Local guide", emoji: "🧭" },
  { value: "food_stall", label: "Food stall", emoji: "🍲" },
  { value: "transport", label: "Local transport", emoji: "🛺" },
  { value: "craft", label: "Craft seller", emoji: "🧵" },
] as const;

export const TRAVELER_CLASSES = [
  { value: "explorer", label: "Explorer — offbeat and on foot" },
  { value: "culture", label: "Culture seeker — history and craft" },
  { value: "family", label: "Family traveller — easy access, safety first" },
  { value: "budget", label: "Budget backpacker — cheapest route wins" },
  { value: "photo", label: "Photographer — light, angles, quiet hours" },
] as const;

export const PLACE_PHOTO_BUCKET = "checkin-photos";

export const placesQuery = {
  queryKey: ["places"],
  queryFn: async (): Promise<DiscoveredPlace[]> => {
    const { data, error } = await supabase
      .rpc("get_public_place_cards");
    if (error) throw error;
    const rows = (data ?? []) as unknown as Array<DiscoveredPlace & { has_photo: boolean }>;
    return Promise.all(
      rows.map(async (row) => ({
        ...row,
        signedPhoto: row.has_photo
          ? await getSharedPhoto({ data: { kind: "place", recordId: row.id } })
          : null,
      })),
    );
  },
};

export async function addPlace(input: {
  userId: string;
  name: string;
  region: string;
  category: string;
  story: string;
  accessNotes: string;
  bestTime: string;
  latitude: number;
  longitude: number;
  photo: File | null;
}) {
  let photoPath: string | null = null;
  if (input.photo) {
    const extension = input.photo.name.split(".").pop() ?? "jpg";
    photoPath = `places/${input.userId}/${crypto.randomUUID()}.${extension}`;
    const { error: uploadError } = await supabase.storage
      .from(PLACE_PHOTO_BUCKET)
      .upload(photoPath, input.photo, { upsert: false });
    if (uploadError) throw uploadError;
  }

  const { data, error } = await supabase
    .from("discovered_places")
    .insert({
      created_by: input.userId,
      name: input.name,
      region: input.region,
      category: input.category,
      story: input.story,
      access_notes: input.accessNotes || null,
      best_time: input.bestTime || null,
      latitude: input.latitude,
      longitude: input.longitude,
      photo_url: photoPath,
    })
    .select("id")
    .single();
  if (error) throw error;
  return data.id as string;
}

export function distanceMetres(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
) {
  const toRad = (value: number) => (value * Math.PI) / 180;
  const R = 6371000;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.sin(dLng / 2) ** 2 * Math.cos(lat1) * Math.cos(lat2);
  return Math.round(2 * R * Math.asin(Math.sqrt(h)));
}

export const VERIFY_RADIUS_M = 500;
export const VERIFICATIONS_NEEDED = 3;

export async function verifyPlace(input: {
  placeId: string;
  userId: string;
  latitude: number;
  longitude: number;
  placeLatitude: number;
  placeLongitude: number;
  note: string;
}) {
  const distance = distanceMetres(
    { lat: input.latitude, lng: input.longitude },
    { lat: input.placeLatitude, lng: input.placeLongitude },
  );
  if (distance > VERIFY_RADIUS_M) {
    throw new Error(
      `You're ${distance} m away. Verification only counts within ${VERIFY_RADIUS_M} m of the place.`,
    );
  }
  const { error } = await supabase.from("place_verifications").insert({
    place_id: input.placeId,
    user_id: input.userId,
    latitude: input.latitude,
    longitude: input.longitude,
    distance_m: distance,
    note: input.note || null,
  });
  if (error) throw error;
  return distance;
}

/* -------------------------------- vendors -------------------------------- */

export const vendorsQuery = {
  queryKey: ["vendors"],
  queryFn: async (): Promise<LocalVendor[]> => {
    const { data, error } = await supabase
      .from("local_vendors")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as unknown as LocalVendor[];
  },
};

export async function addVendor(input: {
  userId: string;
  placeId?: string | null;
  siteId?: string | null;
  name: string;
  vendorType: string;
  description: string;
  contact: string;
  priceFrom: number | null;
}) {
  const { error } = await supabase.from("local_vendors").insert({
    added_by: input.userId,
    place_id: input.placeId ?? null,
    site_id: input.siteId ?? null,
    name: input.name,
    vendor_type: input.vendorType,
    description: input.description || null,
    contact: input.contact || null,
    price_from_inr: input.priceFrom,
  });
  if (error) throw error;
}

/* ---------------------------------- SOS ---------------------------------- */

export async function raiseSos(input: {
  userId: string;
  latitude: number | null;
  longitude: number | null;
  note: string;
}) {
  const { error } = await supabase.from("sos_events").insert({
    user_id: input.userId,
    latitude: input.latitude,
    longitude: input.longitude,
    note: input.note || null,
  });
  if (error) throw error;
}

export async function updatePreferences(
  userId: string,
  values: {
    traveler_class?: string;
    location_consent?: boolean;
    safety_alert_consent?: boolean;
    emergency_contact_phone?: string | null;
  },
) {
  const { error } = await supabase.from("profiles").update(values).eq("id", userId);
  if (error) throw error;
}

/* --------------------------- recommendation rules -------------------------- */

export type Recommendation = {
  key: string;
  title: string;
  region: string;
  reason: string;
  kind: "site" | "place";
  siteId?: string;
  score: number;
};

type PrefProfile = Profile & {
  traveler_class?: string;
  home_region?: string | null;
};

export function recommend(input: {
  sites: HeritageSite[];
  places: DiscoveredPlace[];
  visitedSiteIds: Set<string>;
  visitedRegions: Set<string>;
  profile: PrefProfile | null;
}): Recommendation[] {
  const travelerClass = input.profile?.traveler_class ?? "explorer";
  const results: Recommendation[] = [];

  for (const site of input.sites) {
    if (input.visitedSiteIds.has(site.id)) continue;
    let score = 10;
    const reasons: string[] = [];

    if (input.visitedRegions.has(site.region)) {
      score += 12;
      reasons.push(`close to ${site.region}, where you've already checked in`);
    }
    if (travelerClass === "budget" && (site.entry_fee_inr ?? 0) <= 50) {
      score += 18;
      reasons.push("entry is nearly free");
    }
    if (travelerClass === "family" && (site.women_safety_rating ?? 0) >= 4) {
      score += 18;
      reasons.push("high safety rating and easier access");
    }
    if (travelerClass === "photo" && site.photo_spot) {
      score += 18;
      reasons.push(`known photo spot: ${site.photo_spot}`);
    }
    if (travelerClass === "culture" && site.local_legend) {
      score += 15;
      reasons.push("a strong local legend to hear on site");
    }
    if (travelerClass === "explorer" && (site.crowd_level ?? "") === "low") {
      score += 18;
      reasons.push("stays quiet even in season");
    }
    if ((site.crowd_level ?? "") === "low") score += 4;

    results.push({
      key: `site-${site.id}`,
      title: site.name,
      region: site.region,
      kind: "site",
      siteId: site.id,
      score,
      reason: reasons[0] ?? "a good next step from where you've been",
    });
  }

  for (const place of input.places) {
    let score = 14 + place.verification_count * 6;
    const reasons: string[] = [];
    if (input.visitedRegions.has(place.region)) {
      score += 10;
      reasons.push(`a community find in ${place.region}`);
    }
    if (place.status !== "verified") {
      score += travelerClass === "explorer" ? 14 : -6;
      reasons.push("needs explorers to verify it — extra XP");
    } else {
      reasons.push("verified by travellers on the ground");
    }
    results.push({
      key: `place-${place.id}`,
      title: place.name,
      region: place.region,
      kind: "place",
      score,
      reason: reasons[0] ?? "a hidden place added by a traveller",
    });
  }

  return results.sort((a, b) => b.score - a.score).slice(0, 6);
}
