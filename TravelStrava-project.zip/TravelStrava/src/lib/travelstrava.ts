import { supabase } from "@/integrations/supabase/client";
import { getSharedPhoto } from "@/lib/shared-photos.functions";

export type HeritageSite = {
  id: string;
  name: string;
  region: string;
  history_blurb: string;
  safety_notes: string;
  stamp_code: string;
  stamp_color: string;
  xp_reward: number;
  latitude: number;
  longitude: number;
  crowd_level: string | null;
  best_time: string | null;
  women_safety_rating: number | null;
  accessibility_notes: string | null;
  etiquette: string | null;
  local_legend: string | null;
  photo_spot: string | null;
  emergency_contact: string | null;
  entry_fee_inr: number | null;
  guide_fee_inr: number | null;
  visitors_per_year: number | null;
};

export type Profile = {
  id: string;
  display_name: string;
  avatar_initials: string;
  home_region: string | null;
  xp: number;
  current_streak: number;
  longest_streak: number;
  last_check_in_date: string | null;
};

export type VisitComment = {
  id: string;
  body: string;
  created_at: string;
  user_id: string;
  profiles: { display_name: string; avatar_initials: string } | null;
};

export type Visit = {
  id: string;
  caption: string | null;
  created_at: string;
  photo_url: string | null;
  xp_awarded: number;
  activity_type: string;
  responsible_pledge: boolean;
  latitude: number | null;
  longitude: number | null;
  signedPhoto: string | null;
  hasPhoto: boolean;
  site: HeritageSite;
  profile: Pick<Profile, "id" | "display_name" | "avatar_initials"> | null;
  likes: string[];
  likeCount: number;
  comments: VisitComment[];
};


export const ACTIVITY_TYPES = [
  { value: "heritage_visit", label: "Heritage visit" },
  { value: "temple_visit", label: "Temple visit" },
  { value: "fort_exploration", label: "Fort exploration" },
  { value: "museum_tour", label: "Museum tour" },
  { value: "festival", label: "Cultural festival" },
] as const;

export const EXPENSE_CATEGORIES = [
  { value: "entry", label: "Entry fees" },
  { value: "guide", label: "Local guide" },
  { value: "transport", label: "Transport" },
  { value: "stay", label: "Stay" },
  { value: "food", label: "Food" },
  { value: "other", label: "Other" },
] as const;

export const stampTint: Record<string, string> = {
  brand: "border-brand text-brand bg-brand/10",
  plum: "border-plum text-plum bg-plum/10",
  mint: "border-mint text-mint bg-mint/15",
  accent: "border-accent text-ink bg-accent/25",
};

/* ---------------------------------- sites --------------------------------- */

export const sitesQuery = {
  queryKey: ["sites"],
  queryFn: async (): Promise<HeritageSite[]> => {
    const { data, error } = await supabase
      .from("heritage_sites")
      .select("*")
      .order("name");
    if (error) throw error;
    return data as unknown as HeritageSite[];
  },
};

export const siteQuery = (id: string) => ({
  queryKey: ["site", id],
  queryFn: async (): Promise<HeritageSite> => {
    const { data, error } = await supabase
      .from("heritage_sites")
      .select("*")
      .eq("id", id)
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error("Site not found");
    return data as unknown as HeritageSite;
  },
});

/* --------------------------------- people --------------------------------- */

export const leaderboardQuery = {
  queryKey: ["leaderboard"],
  queryFn: async (): Promise<Profile[]> => {
    const { data, error } = await supabase
      .rpc("get_public_leaderboard");
    if (error) throw error;
    return data as unknown as Profile[];
  },
};

export const profileQuery = (userId: string) => ({
  queryKey: ["profile", userId],
  queryFn: async (): Promise<Profile | null> => {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .maybeSingle();
    if (error) throw error;
    return (data as unknown as Profile) ?? null;
  },
});

/* --------------------------------- visits --------------------------------- */

type RawVisit = {
  id: string;
  caption: string | null;
  created_at: string;
  photo_url: string | null;
  has_photo: boolean;
  xp_awarded: number;
  activity_type: string;
  responsible_pledge: boolean;
  latitude: number | null;
  longitude: number | null;
  heritage_sites: HeritageSite;
  profiles: Pick<Profile, "id" | "display_name" | "avatar_initials"> | null;
  visit_likes: Array<{ user_id: string }>;
  like_count: number;
  visit_comments: VisitComment[];
};

async function toVisits(rows: RawVisit[]): Promise<Visit[]> {
  return Promise.all(
    rows.map(async (row) => ({
      id: row.id,
      caption: row.caption,
      created_at: row.created_at,
      photo_url: row.photo_url,
      hasPhoto: row.has_photo,
      xp_awarded: row.xp_awarded,
      activity_type: row.activity_type,
      responsible_pledge: row.responsible_pledge,
      latitude: row.latitude,
      longitude: row.longitude,
      signedPhoto: row.has_photo
        ? await getSharedPhoto({ data: { kind: "visit", recordId: row.id } })
        : null,

      site: row.heritage_sites,
      profile: row.profiles,
      likes: (row.visit_likes ?? []).map((like) => like.user_id),
      likeCount: row.like_count,
      comments: [...(row.visit_comments ?? [])].sort((a, b) =>
        a.created_at.localeCompare(b.created_at),
      ),
    })),
  );
}

export const feedQuery = {
  queryKey: ["feed"],
  queryFn: async (): Promise<Visit[]> => {
    const { data, error } = await supabase
      .rpc("get_visit_cards", { _scope: "feed" });
    if (error) throw error;
    return toVisits((data ?? []) as unknown as RawVisit[]);
  },
};

export const myVisitsQuery = (userId: string) => ({
  queryKey: ["visits", userId],
  queryFn: async (): Promise<Visit[]> => {
    const { data, error } = await supabase
      .rpc("get_visit_cards", { _scope: "own" });
    if (error) throw error;
    return toVisits((data ?? []) as unknown as RawVisit[]);
  },
});

export async function createVisit(input: {
  userId: string;
  siteId: string;
  caption: string;
  activityType: string;
  photo: File | null;
  latitude?: number | null;
  longitude?: number | null;
  responsiblePledge?: boolean;
  tripId?: string | null;
}) {
  let photoPath: string | null = null;


  if (input.photo) {
    const ext = input.photo.name.split(".").pop() ?? "jpg";
    const path = `${input.userId}/${crypto.randomUUID()}.${ext}`;
    const { error: uploadError } = await supabase.storage
      .from("checkin-photos")
      .upload(path, input.photo, { upsert: false });
    if (uploadError) throw uploadError;
    photoPath = path;
  }

  const { data, error } = await supabase
    .from("visits")
    .insert({
      user_id: input.userId,
      site_id: input.siteId,
      caption: input.caption || null,
      activity_type: input.activityType,
      photo_url: photoPath,
      latitude: input.latitude ?? null,
      longitude: input.longitude ?? null,
      responsible_pledge: input.responsiblePledge ?? false,
      trip_id: input.tripId ?? null,
    })

    .select("id")
    .single();
  if (error) throw error;

  const { data: fresh } = await supabase
    .from("visits")
    .select("xp_awarded")
    .eq("id", data.id)
    .maybeSingle();

  return { xpAwarded: fresh?.xp_awarded ?? 10 };
}

export async function toggleLike(visitId: string, userId: string, liked: boolean) {
  if (liked) {
    const { error } = await supabase
      .from("visit_likes")
      .delete()
      .eq("visit_id", visitId)
      .eq("user_id", userId);
    if (error) throw error;
    return;
  }
  const { error } = await supabase
    .from("visit_likes")
    .insert({ visit_id: visitId, user_id: userId });
  if (error) throw error;
}

export async function addComment(visitId: string, userId: string, body: string) {
  const { error } = await supabase
    .from("visit_comments")
    .insert({ visit_id: visitId, user_id: userId, body });
  if (error) throw error;
}

/* --------------------------------- badges --------------------------------- */

export type Badge = {
  key: string;
  name: string;
  description: string;
  earned: boolean;
  progress: string;
};

export function computeBadges(visits: Visit[], profile: Profile | null): Badge[] {
  const distinctSites = new Set(visits.map((visit) => visit.site.id));
  const regions = new Set(visits.map((visit) => visit.site.region.split(", ").pop()!));
  const longReviews = visits.filter((visit) => (visit.caption ?? "").length >= 100);
  const underexplored = visits.filter(
    (visit) => (visit.site.visitors_per_year ?? 0) > 0 && visit.site.visitors_per_year! < 500000,
  );
  const streak = profile?.longest_streak ?? 0;

  return [
    {
      key: "explorer",
      name: "Heritage Explorer",
      description: "Check in at 10 heritage sites",
      earned: distinctSites.size >= 10,
      progress: `${distinctSites.size}/10 sites`,
    },
    {
      key: "ambassador",
      name: "Cultural Ambassador",
      description: "Write a 100-word-plus story about a site",
      earned: longReviews.length >= 1,
      progress: `${longReviews.length} detailed ${longReviews.length === 1 ? "story" : "stories"}`,
    },
    {
      key: "discoverer",
      name: "First Discoverer",
      description: "Visit sites that see under 5 lakh travellers a year",
      earned: underexplored.length >= 1,
      progress: `${underexplored.length} lesser-known ${underexplored.length === 1 ? "site" : "sites"}`,
    },
    {
      key: "collector",
      name: "Region Collector",
      description: "Stamp sites in 3 different states",
      earned: regions.size >= 3,
      progress: `${regions.size}/3 states`,
    },
    {
      key: "streak",
      name: "Streak Keeper",
      description: "Check in 3 days in a row",
      earned: streak >= 3,
      progress: `${streak}-day best streak`,
    },
    {
      key: "responsible",
      name: "Responsible Traveller",
      description: "Take the zero-litter, respectful-visit pledge 5 times",
      earned: visits.filter((visit) => visit.responsible_pledge).length >= 5,
      progress: `${visits.filter((visit) => visit.responsible_pledge).length}/5 pledged visits`,
    },
    {
      key: "trailblazer",
      name: "Trailblazer",
      description: "Check in solo at sites with tougher safety ratings",
      earned: visits.filter((visit) => (visit.site.women_safety_rating ?? 5) <= 3).length >= 1,
      progress: `${visits.filter((visit) => (visit.site.women_safety_rating ?? 5) <= 3).length} tougher sites`,
    },
  ];
}

/* ---------------------------------- saves --------------------------------- */

export const savedVisitsQuery = (userId: string) => ({
  queryKey: ["saves", userId],
  queryFn: async (): Promise<string[]> => {
    const { data, error } = await supabase
      .from("visit_saves")
      .select("visit_id")
      .eq("user_id", userId);
    if (error) throw error;
    return (data ?? []).map((row) => row.visit_id as string);
  },
});

export async function toggleSave(visitId: string, userId: string, saved: boolean) {
  if (saved) {
    const { error } = await supabase
      .from("visit_saves")
      .delete()
      .eq("visit_id", visitId)
      .eq("user_id", userId);
    if (error) throw error;
    return;
  }
  const { error } = await supabase
    .from("visit_saves")
    .insert({ visit_id: visitId, user_id: userId });
  if (error) throw error;
}

/* ------------------------------- rankings --------------------------------- */

export type RankRow = {
  id: string;
  display_name: string;
  avatar_initials: string;
  xp: number;
  checkIns: number;
};

type RankingVisit = {
  user_id: string;
  xp_awarded: number;
  activity_type: string;
  heritage_sites: { region: string } | null;
  profiles: { display_name: string; avatar_initials: string } | null;
};

export const rankingVisitsQuery = {
  queryKey: ["ranking-visits"],
  queryFn: async (): Promise<RankingVisit[]> => {
    const { data, error } = await supabase
      .rpc("get_public_ranking_visits");
    if (error) throw error;
    return (data ?? []) as unknown as RankingVisit[];
  },
};

export function stateOf(region: string) {
  return region.split(",").pop()!.trim();
}

export function rankBy(
  visits: RankingVisit[],
  filter: (visit: RankingVisit) => boolean,
): RankRow[] {
  const rows = new Map<string, RankRow>();
  for (const visit of visits) {
    if (!filter(visit)) continue;
    const existing = rows.get(visit.user_id) ?? {
      id: visit.user_id,
      display_name: visit.profiles?.display_name ?? "Traveller",
      avatar_initials: visit.profiles?.avatar_initials ?? "TS",
      xp: 0,
      checkIns: 0,
    };
    existing.xp += visit.xp_awarded;
    existing.checkIns += 1;
    rows.set(visit.user_id, existing);
  }
  return [...rows.values()].sort((a, b) => b.xp - a.xp);
}

/* ------------------------------ group trips ------------------------------- */

export const tripQuery = (tripId: string) => ({
  queryKey: ["trip", tripId],
  queryFn: async (): Promise<Trip | null> => {
    const { data, error } = await supabase
      .from("trips")
      .select("id, title, budget_inr, start_date, end_date, invite_code, user_id")
      .eq("id", tripId)
      .maybeSingle();
    if (error) throw error;
    return (data as unknown as Trip) ?? null;
  },
});

export const tripMembersQuery = (tripId: string) => ({
  queryKey: ["trip-members", tripId],
  queryFn: async (): Promise<Array<{ user_id: string }>> => {
    const { data, error } = await supabase
      .from("trip_members")
      .select("user_id")
      .eq("trip_id", tripId);
    if (error) throw error;
    return (data ?? []) as Array<{ user_id: string }>;
  },
});

export const tripVisitsQuery = (tripId: string) => ({
  queryKey: ["trip-visits", tripId],
  queryFn: async (): Promise<Visit[]> => {
    const { data, error } = await supabase
      .rpc("get_visit_cards", { _scope: "trip", _trip_id: tripId });
    if (error) throw error;
    return toVisits((data ?? []) as unknown as RawVisit[]);
  },
});

export async function joinTripByCode(code: string, userId: string) {
  const { data, error } = await supabase
    .from("trips")
    .select("id")
    .eq("invite_code", code.trim().toUpperCase())
    .maybeSingle();
  if (error) throw error;
  if (!data) throw new Error("No trip found with that invite code.");
  const { error: joinError } = await supabase
    .from("trip_members")
    .insert({ trip_id: data.id, user_id: userId });
  if (joinError && joinError.code !== "23505") throw joinError;
  return data.id as string;
}


/* --------------------------------- budget --------------------------------- */

export type Trip = {
  id: string;
  title: string;
  budget_inr: number;
  start_date: string | null;
  end_date: string | null;
  invite_code: string;
  user_id: string;
};


export type Expense = {
  id: string;
  trip_id: string;
  category: string;
  label: string;
  amount_inr: number;
  created_at: string;
};

export const tripsQuery = (userId: string) => ({
  queryKey: ["trips", userId],
  queryFn: async (): Promise<Trip[]> => {
    const { data, error } = await supabase
      .from("trips")
      .select("id, title, budget_inr, start_date, end_date, invite_code, user_id")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data as unknown as Trip[];
  },
});

export const expensesQuery = (tripId: string) => ({
  queryKey: ["expenses", tripId],
  queryFn: async (): Promise<Expense[]> => {
    const { data, error } = await supabase
      .from("trip_expenses")
      .select("id, trip_id, category, label, amount_inr, created_at")
      .eq("trip_id", tripId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data as unknown as Expense[];
  },
});

export async function createTrip(input: {
  userId: string;
  title: string;
  budget: number;
  startDate?: string | null;
  endDate?: string | null;
}) {
  const { data, error } = await supabase
    .from("trips")
    .insert({
      user_id: input.userId,
      title: input.title,
      budget_inr: input.budget,
      start_date: input.startDate || null,
      end_date: input.endDate || null,
    })
    .select("id")

    .single();
  if (error) throw error;
  return data.id as string;
}

export async function addExpense(input: {
  userId: string;
  tripId: string;
  category: string;
  label: string;
  amount: number;
}) {
  const { error } = await supabase.from("trip_expenses").insert({
    user_id: input.userId,
    trip_id: input.tripId,
    category: input.category,
    label: input.label,
    amount_inr: input.amount,
  });
  if (error) throw error;
}

export async function deleteExpense(id: string) {
  const { error } = await supabase.from("trip_expenses").delete().eq("id", id);
  if (error) throw error;
}

export function formatRupees(amount: number) {
  return `₹${amount.toLocaleString("en-IN")}`;
}
