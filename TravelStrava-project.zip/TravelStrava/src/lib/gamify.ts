export type Level = {
  index: number;
  name: string;
  emoji: string;
  minXp: number;
};

export const LEVELS: Level[] = [
  { index: 1, name: "Wanderer", emoji: "🥾", minXp: 0 },
  { index: 2, name: "Scout", emoji: "🧭", minXp: 60 },
  { index: 3, name: "Pathfinder", emoji: "🗺️", minXp: 150 },
  { index: 4, name: "Trailblazer", emoji: "🔥", minXp: 300 },
  { index: 5, name: "Cartographer", emoji: "📜", minXp: 550 },
  { index: 6, name: "Heritage Legend", emoji: "👑", minXp: 900 },
];

export type LevelProgress = {
  level: Level;
  next: Level | null;
  intoLevel: number;
  span: number;
  percent: number;
  xpToNext: number;
};

export function levelProgress(xp: number): LevelProgress {
  const safeXp = Math.max(0, xp || 0);
  let level: Level = LEVELS[0]!;

  for (const candidate of LEVELS) if (safeXp >= candidate.minXp) level = candidate;
  const next = LEVELS[level.index] ?? null;
  const span = next ? next.minXp - level.minXp : 1;
  const intoLevel = safeXp - level.minXp;
  return {
    level,
    next,
    intoLevel,
    span,
    percent: next ? Math.min(100, Math.round((intoLevel / span) * 100)) : 100,
    xpToNext: next ? Math.max(0, next.minXp - safeXp) : 0,
  };
}

export type Quest = {
  key: string;
  title: string;
  reward: string;
  done: number;
  target: number;
  href: "/discover" | "/feed" | "/budget" | "/copilot" | "/";
  cta: string;
};

export function buildQuests(input: {
  visits: number;
  visitsToday: number;
  placesAdded: number;
  placesVerified: number;
  photos: number;
  expenses: number;
  distinctRegions: number;
}): Quest[] {
  return [
    {
      key: "checkin",
      title: "Check in somewhere today",
      reward: "+10 XP · daily",
      done: Math.min(input.visitsToday, 1),
      target: 1,
      href: "/",
      cta: "Pick a site",
    },
    {
      key: "discover",
      title: "Put a hidden place on the map",
      reward: "+40 XP",
      done: Math.min(input.placesAdded, 1),
      target: 1,
      href: "/discover",
      cta: "Add a place",
    },
    {
      key: "verify",
      title: "Ground-truth 3 community finds",
      reward: "+15 XP each",
      done: Math.min(input.placesVerified, 3),
      target: 3,
      href: "/discover",
      cta: "Verify nearby",
    },
    {
      key: "photos",
      title: "Post 5 check-in photos",
      reward: "Shutterbug badge",
      done: Math.min(input.photos, 5),
      target: 5,
      href: "/feed",
      cta: "Open feed",
    },
    {
      key: "regions",
      title: "Collect stamps in 3 states",
      reward: "Trailblazer badge",
      done: Math.min(input.distinctRegions, 3),
      target: 3,
      href: "/",
      cta: "Browse sites",
    },
    {
      key: "budget",
      title: "Log 3 trip expenses",
      reward: "Budget Brain badge",
      done: Math.min(input.expenses, 3),
      target: 3,
      href: "/budget",
      cta: "Track spend",
    },
  ];
}

export function questPoints(quests: Quest[]): { done: number; total: number } {
  return {
    done: quests.filter((quest) => quest.done >= quest.target).length,
    total: quests.length,
  };
}

export type CoverageTier = {
  name: string;
  emoji: string;
  stops: number;
  reward: string;
};

export const COVERAGE_TIERS: CoverageTier[] = [
  { name: "Bronze Trail", emoji: "⭐", stops: 3, reward: "+30 XP bonus" },
  { name: "Silver Trail", emoji: "🌟", stops: 6, reward: "+80 XP bonus" },
  { name: "Gold Trail", emoji: "🔥", stops: 10, reward: "+150 XP + Gold stamp" },
  { name: "Heritage Conqueror", emoji: "🏆", stops: 15, reward: "+300 XP + city crown" },
];

export function coverageStatus(stops: number) {
  const earned = COVERAGE_TIERS.filter((tier) => stops >= tier.stops);
  const current = earned[earned.length - 1] ?? null;
  const next = COVERAGE_TIERS.find((tier) => stops < tier.stops) ?? null;
  return {
    current,
    next,
    earnedCount: earned.length,
    toNext: next ? next.stops - stops : 0,
    percent: next ? Math.min(100, Math.round((stops / next.stops) * 100)) : 100,
  };
}
