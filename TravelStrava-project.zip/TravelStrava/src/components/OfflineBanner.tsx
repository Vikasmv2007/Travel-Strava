import { useOnline } from "@/lib/offline";

export function OfflineBanner() {
  const online = useOnline();
  if (online) return null;

  return (
    <div className="sticky top-0 z-40 bg-ink px-5 py-2.5 text-center text-sm font-semibold text-cream">
      You're offline — showing the last saved sites and places. Check-ins will need
      signal.
    </div>
  );
}
