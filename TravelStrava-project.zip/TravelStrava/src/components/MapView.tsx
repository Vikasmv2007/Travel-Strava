import { useEffect, useRef, useState } from "react";

declare global {
  interface Window {
    google?: any;
    __travelstravaMapsReady?: boolean;
    __initTravelstravaMaps?: () => void;
  }
}

let loaderPromise: Promise<void> | null = null;

function loadMaps(): Promise<void> {
  if (typeof window === "undefined") return Promise.resolve();
  if (window.google?.maps) return Promise.resolve();
  if (loaderPromise) return loaderPromise;

  const key = import.meta.env["VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_BROWSER_KEY"];
  const channel = import.meta.env["VITE_LOVABLE_CONNECTOR_GOOGLE_MAPS_TRACKING_ID"];
  if (!key) return Promise.reject(new Error("Maps key missing"));

  loaderPromise = new Promise<void>((resolve, reject) => {
    window.__initTravelstravaMaps = () => resolve();
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${key}&loading=async&callback=__initTravelstravaMaps${
      channel ? `&channel=${channel}` : ""
    }`;
    script.async = true;
    script.onerror = () => reject(new Error("Maps failed to load"));
    document.head.appendChild(script);
  });

  return loaderPromise;
}

export type MapPin = {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  subtitle?: string;
  tone?: "brand" | "plum" | "mint";
};

const PIN_COLOR: Record<string, string> = {
  brand: "#f4623a",
  plum: "#7c3aed",
  mint: "#22b8a6",
};

export function MapView({
  pins,
  zoom = 5,
  className = "h-[420px]",
  onSelect,
}: {
  pins: MapPin[];
  zoom?: number;
  className?: string;
  onSelect?: (pin: MapPin) => void;
}) {
  const container = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    loadMaps()
      .then(() => {
        if (!cancelled) setReady(true);
      })
      .catch(() => {
        if (!cancelled) setError("The map could not be loaded right now.");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!ready || !container.current || !window.google?.maps) return;

    const maps = window.google.maps;
    if (!mapRef.current) {
      mapRef.current = new maps.Map(container.current, {
        center: { lat: pins[0]?.latitude ?? 22.9, lng: pins[0]?.longitude ?? 78.6 },
        zoom,
        clickableIcons: false,
        streetViewControl: false,
        mapTypeControl: false,
        styles: [{ featureType: "poi", stylers: [{ visibility: "off" }] }],
      });
    }

    markersRef.current.forEach((marker) => marker.setMap(null));
    markersRef.current = [];

    const bounds = new maps.LatLngBounds();
    const info = new maps.InfoWindow();

    pins.forEach((pin) => {
      const position = { lat: pin.latitude, lng: pin.longitude };
      const marker = new maps.Marker({
        map: mapRef.current,
        position,
        title: pin.name,
        icon: {
          path: maps.SymbolPath.CIRCLE,
          scale: 9,
          fillColor: PIN_COLOR[pin.tone ?? "brand"],
          fillOpacity: 1,
          strokeColor: "#ffffff",
          strokeWeight: 3,
        },
      });
      marker.addListener("click", () => {
        info.setContent(
          `<div style="font-family:Inter,sans-serif;padding:2px 4px"><strong>${pin.name}</strong>${
            pin.subtitle ? `<br/><span style="opacity:.7">${pin.subtitle}</span>` : ""
          }</div>`,
        );
        info.open({ anchor: marker, map: mapRef.current });
        onSelect?.(pin);
      });
      markersRef.current.push(marker);
      bounds.extend(position);
    });

    if (pins.length > 1) {
      mapRef.current.fitBounds(bounds, 60);
    } else if (pins.length === 1 && pins[0]) {
      mapRef.current.setCenter({ lat: pins[0].latitude, lng: pins[0].longitude });
      mapRef.current.setZoom(zoom);
    }
  }, [ready, pins, zoom, onSelect]);

  if (error) {
    return (
      <div
        className={`grid place-items-center rounded-[1.75rem] bg-surface p-6 text-center text-ink/60 ${className}`}
      >
        {error}
      </div>
    );
  }

  return (
    <div
      ref={container}
      className={`w-full overflow-hidden rounded-[1.75rem] bg-surface ${className}`}
    />
  );
}
