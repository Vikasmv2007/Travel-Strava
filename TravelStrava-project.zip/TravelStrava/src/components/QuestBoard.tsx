import { Link } from "@tanstack/react-router";

import { questPoints, type Quest } from "@/lib/gamify";

export function QuestBoard({ quests }: { quests: Quest[] }) {
  const score = questPoints(quests);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-3xl font-bold tracking-tight">Quest board</h2>
          <p className="mt-1 text-ink/60">
            Every quest feeds the same verified map — that is why the data stays fresh.
          </p>
        </div>
        <span className="rounded-full bg-ink px-4 py-2 font-display font-bold text-cream">
          {score.done}/{score.total} cleared
        </span>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {quests.map((quest) => {
          const complete = quest.done >= quest.target;
          const percent = Math.round((quest.done / quest.target) * 100);
          return (
            <Link
              key={quest.key}
              to={quest.href}
              className={`surface-3d rounded-[1.75rem] p-6 transition-transform hover:-translate-y-1 ${
                complete ? "bg-mint/50" : "bg-surface"
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-display text-lg font-bold">{quest.title}</h3>
                <span className="text-xl">{complete ? "✅" : "⚡"}</span>
              </div>
              <p className="mt-1 text-sm font-semibold text-brand">{quest.reward}</p>
              <div className="mt-4 h-3 w-full overflow-hidden rounded-full bg-cream">
                <div
                  className="h-full rounded-full bg-plum transition-[width] duration-700"
                  style={{ width: `${Math.max(percent, 3)}%` }}
                />
              </div>
              <p className="mt-2 text-sm text-ink/60">
                {quest.done}/{quest.target} ·{" "}
                <span className="font-semibold">{complete ? "Done" : quest.cta}</span>
              </p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
