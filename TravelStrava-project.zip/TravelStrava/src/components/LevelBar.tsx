import { levelProgress } from "@/lib/gamify";

export function LevelBar({
  xp,
  streak,
  compact = false,
}: {
  xp: number;
  streak?: number;
  compact?: boolean;
}) {
  const progress = levelProgress(xp);

  return (
    <div
      className={`surface-3d rounded-[1.75rem] bg-surface ${compact ? "p-5" : "p-6"}`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="grid size-12 place-items-center rounded-2xl bg-accent text-2xl">
            {progress.level.emoji}
          </span>
          <div>
            <p className="text-xs font-bold tracking-wide text-ink/50 uppercase">
              Level {progress.level.index}
            </p>
            <p className="font-display text-xl font-bold">{progress.level.name}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="font-display text-2xl font-bold text-brand">{xp} XP</p>
          {typeof streak === "number" && (
            <p className="text-sm font-semibold text-ink/60">🔥 {streak} day streak</p>
          )}
        </div>
      </div>

      <div className="mt-4 h-4 w-full overflow-hidden rounded-full bg-cream inset-shadow-sm">
        <div
          className="h-full rounded-full bg-gradient-to-r from-brand to-accent transition-[width] duration-700"
          style={{ width: `${Math.max(progress.percent, 4)}%` }}
        />
      </div>
      <p className="mt-2 text-sm text-ink/60">
        {progress.next
          ? `${progress.xpToNext} XP to ${progress.next.emoji} ${progress.next.name}`
          : "Top level reached — you are a Heritage Legend."}
      </p>
    </div>
  );
}
