import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { raiseSos } from "@/lib/discovery";
import { profileQuery } from "@/lib/travelstrava";
import { useSession } from "@/lib/session";

export function SosButton() {
  const { user } = useSession();
  const { data: profile } = useQuery({
    ...profileQuery(user?.id ?? ""),
    enabled: !!user,
  });
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);

  if (!user) return null;

  const phone = (profile as { emergency_contact_phone?: string } | null)
    ?.emergency_contact_phone;

  async function send() {
    if (!user) return;
    setState("sending");
    const position = await new Promise<GeolocationPosition | null>((resolve) => {
      if (!navigator.geolocation) return resolve(null);
      navigator.geolocation.getCurrentPosition(
        (value) => resolve(value),
        () => resolve(null),
        { enableHighAccuracy: true, timeout: 8000 },
      );
    });
    const lat = position?.coords.latitude ?? null;
    const lng = position?.coords.longitude ?? null;
    if (lat && lng) setCoords({ lat, lng });
    try {
      await raiseSos({ userId: user.id, latitude: lat, longitude: lng, note });
      setState("sent");
    } catch {
      setState("error");
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label="Emergency SOS"
        className="fixed right-5 bottom-5 z-50 grid size-16 place-items-center rounded-full bg-brand font-display text-sm font-bold text-brand-foreground shadow-[0_10px_0_rgba(0,0,0,0.15)] transition-transform hover:-translate-y-1"
      >
        SOS
      </button>

      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-ink/60 px-5">
          <div className="w-full max-w-md rounded-[2rem] bg-surface p-7">
            <h2 className="font-display text-2xl font-bold">Emergency SOS</h2>
            <p className="mt-2 text-ink/70">
              This logs your location to your account so it can be shared with help, and
              gives you one-tap dialling.
            </p>

            <textarea
              value={note}
              onChange={(event) => setNote(event.target.value)}
              rows={2}
              placeholder="What's happening? (optional)"
              className="mt-4 w-full rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
            />

            <div className="mt-4 flex flex-wrap gap-2">
              <a
                href="tel:112"
                className="rounded-full bg-brand px-5 py-3 font-semibold text-brand-foreground"
              >
                Call 112
              </a>
              {phone && (
                <a
                  href={`tel:${phone}`}
                  className="rounded-full bg-ink px-5 py-3 font-semibold text-cream"
                >
                  Call my contact
                </a>
              )}
              <button
                onClick={send}
                disabled={state === "sending"}
                className="rounded-full bg-accent px-5 py-3 font-semibold text-ink disabled:opacity-60"
              >
                {state === "sending" ? "Sending…" : "Send my location"}
              </button>
            </div>

            {state === "sent" && (
              <p className="mt-4 font-semibold text-plum">
                Location saved
                {coords ? ` (${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)})` : ""}.
                {phone ? " Call your contact now." : " Add an emergency contact in your passport settings."}
              </p>
            )}
            {state === "error" && (
              <p className="mt-4 font-semibold text-brand">
                Couldn't save that — call 112 directly.
              </p>
            )}

            <button
              onClick={() => setOpen(false)}
              className="mt-5 text-sm font-semibold text-ink/50 hover:text-brand"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}
