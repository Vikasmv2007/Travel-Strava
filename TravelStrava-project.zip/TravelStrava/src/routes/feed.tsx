import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import {
  addComment,
  feedQuery,
  savedVisitsQuery,
  stampTint,
  toggleLike,
  toggleSave,
  type Visit,
} from "@/lib/travelstrava";
import { useSession } from "@/lib/session";

export const Route = createFileRoute("/feed")({
  head: () => ({
    meta: [
      { title: "Heritage feed — TravelStrava" },
      {
        name: "description",
        content:
          "Real photo check-ins from travellers exploring India's heritage sites, with tips and cultural notes.",
      },
      { property: "og:title", content: "Heritage feed — TravelStrava" },
      {
        property: "og:description",
        content: "Photo check-ins and cultural notes from heritage travellers across India.",
      },
    ],
  }),
  component: Feed,
});

function Feed() {
  const { data: visits = [] } = useQuery(feedQuery);
  const { user } = useSession();
  const userId = user?.id ?? "";
  const { data: saved = [] } = useQuery({
    ...savedVisitsQuery(userId),
    enabled: !!userId,
  });
  const [tab, setTab] = useState<"all" | "saved">("all");

  const shown = tab === "saved" ? visits.filter((v) => saved.includes(v.id)) : visits;

  return (
    <main className="mx-auto max-w-2xl px-5 pb-20 sm:px-8">
      <h1 className="font-display text-[clamp(2rem,5vw,3.5rem)] leading-tight font-bold tracking-tight">
        What travellers are <span className="text-brand">exploring</span>.
      </h1>
      {!user && (
        <p className="mt-3 text-ink/65">
          <Link to="/auth" className="font-semibold text-brand underline">
            Sign in
          </Link>{" "}
          to like, save, comment and add your own check-ins.
        </p>
      )}

      {user && (
        <div className="mt-6 flex gap-2">
          {(["all", "saved"] as const).map((key) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`rounded-full px-5 py-2 text-sm font-semibold ${
                tab === key ? "bg-ink text-cream" : "bg-surface text-ink/60"
              }`}
            >
              {key === "all" ? "Everyone" : `Saved (${saved.length})`}
            </button>
          ))}
        </div>
      )}

      <div className="mt-8 space-y-6">
        {shown.length === 0 && (
          <p className="rounded-[2rem] bg-surface p-10 text-center text-ink/60 outline-1 -outline-offset-1 outline-ink/5">
            {tab === "saved"
              ? "Nothing saved yet — tap Save on a check-in to keep it here."
              : "No check-ins yet. Be the first to stamp a site."}
          </p>
        )}
        {shown.map((visit) => (
          <FeedCard
            key={visit.id}
            visit={visit}
            userId={user?.id ?? null}
            saved={saved.includes(visit.id)}
          />
        ))}
      </div>
    </main>
  );
}

function FeedCard({
  visit,
  userId,
  saved,
}: {
  visit: Visit;
  userId: string | null;
  saved: boolean;
}) {
  const queryClient = useQueryClient();
  const [comment, setComment] = useState("");
  const liked = userId ? visit.likes.includes(userId) : false;

  const likeMutation = useMutation({
    mutationFn: () => {
      if (!userId) throw new Error("Sign in required");
      return toggleLike(visit.id, userId, liked);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["feed"] }),
  });

  const saveMutation = useMutation({
    mutationFn: () => {
      if (!userId) throw new Error("Sign in required");
      return toggleSave(visit.id, userId, saved);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["saves", userId] }),
  });

  const commentMutation = useMutation({
    mutationFn: () => {
      if (!userId) throw new Error("Sign in required");
      return addComment(visit.id, userId, comment.trim());
    },
    onSuccess: () => {
      setComment("");
      queryClient.invalidateQueries({ queryKey: ["feed"] });
    },
  });

  const storyText = `${visit.profile?.display_name ?? "A traveller"} checked in at ${
    visit.site.name
  }, ${visit.site.region} on TravelStrava — +${visit.xp_awarded} XP.`;

  return (
    <article className="overflow-hidden rounded-[2rem] bg-surface outline-1 -outline-offset-1 outline-ink/5">
      <div className="flex items-center gap-3 p-6 pb-4">
        <span className="grid size-11 place-items-center rounded-full bg-plum font-display font-bold text-cream">
          {visit.profile?.avatar_initials ?? "TS"}
        </span>
        <div className="flex-1">
          <p className="font-semibold">{visit.profile?.display_name ?? "Traveller"}</p>
          <Link
            to="/sites/$siteId"
            params={{ siteId: visit.site.id }}
            className="text-sm text-ink/55 hover:text-brand"
          >
            {visit.site.name} · {visit.site.region}
          </Link>
        </div>
        <span
          className={`grid size-12 place-items-center rounded-full border-2 font-display text-sm font-bold ${
            stampTint[visit.site.stamp_color] ?? stampTint["brand"]
          }`}
        >
          {visit.site.stamp_code}
        </span>
      </div>

      {visit.signedPhoto && (
        <img
          src={visit.signedPhoto}
          alt={`Check-in at ${visit.site.name}`}
          loading="lazy"
          className="aspect-[4/3] w-full object-cover"
        />
      )}

      <div className="p-6">
        {visit.caption && <p className="leading-relaxed text-ink/80">{visit.caption}</p>}
        <div className="mt-3 flex flex-wrap gap-2 text-sm font-semibold">
          <span className="text-brand">+{visit.xp_awarded} XP</span>
          {visit.responsible_pledge && (
            <span className="rounded-full bg-mint/40 px-3 py-0.5 text-ink/70">
              ♻ Responsible visit
            </span>
          )}
          {visit.latitude !== null && visit.longitude !== null && (
            <span className="rounded-full bg-cream px-3 py-0.5 text-ink/55">
              📍 {visit.latitude.toFixed(2)}, {visit.longitude.toFixed(2)}
            </span>
          )}
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button
            disabled={!userId || likeMutation.isPending}
            onClick={() => likeMutation.mutate()}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
              liked ? "bg-brand text-brand-foreground" : "bg-cream text-ink/70 hover:text-brand"
            } disabled:opacity-50`}
          >
            ♥ {visit.likeCount}
          </button>
          <button
            disabled={!userId || saveMutation.isPending}
            onClick={() => saveMutation.mutate()}
            className={`rounded-full px-4 py-2 text-sm font-semibold transition-colors ${
              saved ? "bg-plum text-cream" : "bg-cream text-ink/70 hover:text-plum"
            } disabled:opacity-50`}
          >
            {saved ? "Saved" : "Save"}
          </button>
          <button
            onClick={() => {
              const url = `${window.location.origin}/sites/${visit.site.id}`;
              if (navigator.share) {
                void navigator.share({ title: visit.site.name, text: storyText, url });
              } else {
                void navigator.clipboard.writeText(`${storyText} ${url}`);
              }
            }}
            className="rounded-full bg-cream px-4 py-2 text-sm font-semibold text-ink/70 hover:text-brand"
          >
            Share
          </button>
          <span className="text-sm text-ink/50">
            {visit.comments.length} comment{visit.comments.length === 1 ? "" : "s"}
          </span>
        </div>

        {visit.comments.length > 0 && (
          <ul className="mt-4 space-y-2">
            {visit.comments.map((entry) => (
              <li key={entry.id} className="rounded-2xl bg-cream px-4 py-2.5 text-sm">
                <span className="font-semibold">
                  {entry.profiles?.display_name ?? "Traveller"}
                </span>{" "}
                <span className="text-ink/70">{entry.body}</span>
              </li>
            ))}
          </ul>
        )}

        {userId && (
          <form
            onSubmit={(event) => {
              event.preventDefault();
              if (comment.trim().length > 0) commentMutation.mutate();
            }}
            className="mt-4 flex gap-2"
          >
            <input
              value={comment}
              onChange={(event) => setComment(event.target.value)}
              placeholder="Add a tip or a memory…"
              className="flex-1 rounded-full border-2 border-ink/15 bg-cream px-4 py-2.5 text-sm outline-none focus:border-brand"
            />
            <button
              type="submit"
              disabled={commentMutation.isPending}
              className="rounded-full bg-ink px-5 py-2.5 text-sm font-semibold text-cream disabled:opacity-60"
            >
              Post
            </button>
          </form>
        )}
      </div>
    </article>
  );
}
