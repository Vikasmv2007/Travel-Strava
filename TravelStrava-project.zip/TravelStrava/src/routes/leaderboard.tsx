import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import {
  ACTIVITY_TYPES,
  leaderboardQuery,
  rankBy,
  rankingVisitsQuery,
  stateOf,
  type RankRow,
} from "@/lib/travelstrava";
import { useSession } from "@/lib/session";

export const Route = createFileRoute("/leaderboard")({
  head: () => ({
    meta: [
      { title: "Ranks — TravelStrava" },
      {
        name: "description",
        content:
          "Global, state-wise and heritage-type rankings of travellers earning XP across India.",
      },
      { property: "og:title", content: "Ranks — TravelStrava" },
      {
        property: "og:description",
        content: "Heritage travellers ranked globally, by state and by type of site.",
      },
    ],
  }),
  component: Leaderboard,
});

type Mode = "global" | "state" | "activity";

function Leaderboard() {
  const { data: profiles = [] } = useQuery(leaderboardQuery);
  const { data: rankingVisits = [] } = useQuery(rankingVisitsQuery);
  const { user } = useSession();

  const [mode, setMode] = useState<Mode>("global");
  const states = useMemo(
    () =>
      [
        ...new Set(
          rankingVisits
            .map((visit) => (visit.heritage_sites ? stateOf(visit.heritage_sites.region) : null))
            .filter((value): value is string => !!value),
        ),
      ].sort(),
    [rankingVisits],
  );
  const [state, setState] = useState<string>("");
  const [activity, setActivity] = useState<string>(ACTIVITY_TYPES[0].value);

  const activeState = state || states[0] || "";

  const rows: RankRow[] =
    mode === "global"
      ? profiles.map((profile) => ({
          id: profile.id,
          display_name: profile.display_name,
          avatar_initials: profile.avatar_initials,
          xp: profile.xp,
          checkIns: 0,
        }))
      : mode === "state"
        ? rankBy(
            rankingVisits,
            (visit) => !!visit.heritage_sites && stateOf(visit.heritage_sites.region) === activeState,
          )
        : rankBy(rankingVisits, (visit) => visit.activity_type === activity);

  return (
    <main className="mx-auto max-w-6xl px-5 pb-20 sm:px-8">
      <h1 className="font-display text-[clamp(2rem,5vw,3.5rem)] leading-tight font-bold tracking-tight">
        Who's <span className="text-plum">collecting</span> fastest?
      </h1>
      <p className="mt-3 max-w-md text-lg text-ink/65">
        10 XP per check-in, 25 XP the first time you stamp a site.
      </p>

      <div className="mt-7 flex flex-wrap gap-2">
        {(
          [
            ["global", "Global"],
            ["state", "By state"],
            ["activity", "By heritage type"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            onClick={() => setMode(key)}
            className={`rounded-full px-5 py-2 text-sm font-semibold ${
              mode === key ? "bg-ink text-cream" : "bg-surface text-ink/60"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {mode === "state" && states.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {states.map((item) => (
            <button
              key={item}
              onClick={() => setState(item)}
              className={`rounded-full px-4 py-1.5 text-sm font-semibold ${
                item === activeState ? "bg-accent" : "bg-surface text-ink/60"
              }`}
            >
              {item}
            </button>
          ))}
        </div>
      )}

      {mode === "activity" && (
        <div className="mt-4 flex flex-wrap gap-2">
          {ACTIVITY_TYPES.map((item) => (
            <button
              key={item.value}
              onClick={() => setActivity(item.value)}
              className={`rounded-full px-4 py-1.5 text-sm font-semibold ${
                item.value === activity ? "bg-accent" : "bg-surface text-ink/60"
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}

      <ol className="mt-8 space-y-3">
        {rows.length === 0 && (
          <li className="rounded-[2rem] bg-surface p-10 text-center text-ink/60 outline-1 -outline-offset-1 outline-ink/5">
            No check-ins here yet — take the first spot.
          </li>
        )}
        {rows.map((row, index) => {
          const isYou = row.id === user?.id;
          const profile = profiles.find((item) => item.id === row.id);
          return (
            <li
              key={row.id}
              className={`flex items-center gap-4 rounded-[1.75rem] px-6 py-5 ${
                isYou ? "bg-accent" : "bg-surface outline-1 -outline-offset-1 outline-ink/5"
              }`}
            >
              <span className="font-display text-2xl font-bold text-ink/40">
                {String(index + 1).padStart(2, "0")}
              </span>
              <span className="grid size-11 place-items-center rounded-full bg-brand font-display font-bold text-brand-foreground">
                {row.avatar_initials}
              </span>
              <div className="flex-1">
                <p className="font-semibold">{row.display_name}</p>
                <p className="text-sm text-ink/50">
                  {mode === "global"
                    ? `🔥 ${profile?.current_streak ?? 0}-day streak`
                    : `${row.checkIns} check-in${row.checkIns === 1 ? "" : "s"} here`}
                </p>
              </div>
              <span className="font-display text-xl font-bold">{row.xp} XP</span>
            </li>
          );
        })}
      </ol>
    </main>
  );
}
