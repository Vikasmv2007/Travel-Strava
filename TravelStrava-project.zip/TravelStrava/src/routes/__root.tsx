import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useNavigate,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { SessionProvider, useSession } from "../lib/session";
import { supabase } from "../integrations/supabase/client";
import { SosButton } from "../components/SosButton";
import { OfflineBanner } from "../components/OfflineBanner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "TravelStrava — Collect India's heritage" },
      {
        name: "description",
        content:
          "Check in at Indian heritage sites, collect passport stamps, earn XP and ask a heritage copilot anything.",
      },
      { property: "og:title", content: "TravelStrava" },
      {
        property: "og:description",
        content: "Gamified heritage travel across India — stamps, XP and a copilot.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap",
      },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

const navLinks = [
  { to: "/", label: "Sites" },
  { to: "/plan", label: "Plan a quest" },
  { to: "/discover", label: "Hidden places" },

  { to: "/feed", label: "Feed" },
  { to: "/passport", label: "Passport" },
  { to: "/budget", label: "Budget" },
  { to: "/leaderboard", label: "Ranks" },
  { to: "/copilot", label: "Copilot" },
] as const;

function AccountButton() {
  const { user, loading } = useSession();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  if (loading) return <span className="size-11" />;

  if (!user) {
    return (
      <Link
        to="/auth"
        className="rounded-full bg-ink px-6 py-3 font-semibold text-cream transition-transform hover:-translate-y-0.5"
      >
        Sign in
      </Link>
    );
  }

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="flex items-center gap-3">
      <Link
        to="/passport"
        className="rounded-full bg-ink px-5 py-3 font-semibold text-cream transition-transform hover:-translate-y-0.5"
      >
        My passport
      </Link>
      <button
        onClick={handleSignOut}
        className="text-sm font-semibold text-ink/50 transition-colors hover:text-brand"
      >
        Sign out
      </button>
    </div>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <SessionProvider>
        <div className="min-h-screen bg-cream font-sans text-ink antialiased">
          <OfflineBanner />
          <header className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 py-6 sm:px-8">
            <Link to="/" className="flex items-center gap-2.5">
              <span className="grid size-11 -rotate-6 place-items-center rounded-2xl bg-brand font-display text-xl font-bold text-brand-foreground">
                T
              </span>
              <span className="font-display text-2xl font-bold tracking-tight">
                TravelStrava
              </span>
            </Link>
            <nav className="hidden items-center gap-7 font-medium text-ink/70 lg:flex">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  activeOptions={{ exact: link.to === "/" }}
                  activeProps={{ className: "text-brand" }}
                  className="transition-colors hover:text-brand"
                >
                  {link.label}
                </Link>
              ))}
            </nav>
            <AccountButton />
          </header>

          <nav className="mx-auto flex max-w-6xl gap-5 overflow-x-auto px-5 pb-4 font-medium text-ink/70 sm:px-8 lg:hidden">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                activeOptions={{ exact: link.to === "/" }}
                activeProps={{ className: "text-brand" }}
                className="whitespace-nowrap transition-colors hover:text-brand"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
          <Outlet />
          <SosButton />

          <footer className="mt-16 border-t border-ink/10">
            <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-5 py-8 sm:flex-row sm:px-8">
              <div className="flex items-center gap-2.5">
                <span className="grid size-9 place-items-center rounded-xl bg-brand font-display font-bold text-brand-foreground">
                  T
                </span>
                <span className="font-display text-lg font-bold">TravelStrava</span>
              </div>
              <p className="text-sm text-ink/50">
                Heritage travel, gamified — stamps, XP and stories from across India.
              </p>
              <nav className="flex gap-6 text-sm font-medium text-ink/60">
                <Link to="/leaderboard" className="hover:text-brand">
                  Ranks
                </Link>
                <Link to="/copilot" className="hover:text-brand">
                  Copilot
                </Link>
              </nav>
            </div>
          </footer>
        </div>
      </SessionProvider>
    </QueryClientProvider>
  );
}


