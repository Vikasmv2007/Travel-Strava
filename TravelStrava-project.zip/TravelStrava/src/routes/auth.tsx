import { useState } from "react";
import { createFileRoute, useNavigate, useRouterState } from "@tanstack/react-router";

import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useSession } from "@/lib/session";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — TravelStrava" },
      {
        name: "description",
        content:
          "Create your TravelStrava account to collect heritage stamps, earn XP and track trip budgets.",
      },
      { property: "og:title", content: "Sign in — TravelStrava" },
      {
        property: "og:description",
        content: "Your heritage passport, streaks and trip budgets in one account.",
      },
    ],
  }),
  component: Auth,
});

function Auth() {
  const navigate = useNavigate();
  const { user } = useSession();
  const isNavigating = useRouterState({ select: (s) => s.isLoading });
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (user && !isNavigating) {
    navigate({ to: "/passport", replace: true });
  }

  async function handleGoogle() {
    setError(null);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError("Google sign-in didn't work. Try again or use your email.");
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/passport" });
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);

    try {
      if (mode === "signup") {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { display_name: name || email.split("@")[0] },
          },
        });
        if (signUpError) throw signUpError;
        if (!data.session) {
          setMessage("Check your inbox — confirm your email, then sign in here.");
          setMode("signin");
          return;
        }
        navigate({ to: "/passport" });
        return;
      }

      const { error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      if (signInError) throw signInError;
      navigate({ to: "/passport" });
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "That didn't work.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto max-w-md px-5 pb-20 sm:px-8">
      <h1 className="font-display text-[clamp(2rem,5vw,3rem)] leading-tight font-bold tracking-tight">
        {mode === "signin" ? (
          <>
            Welcome <span className="text-brand">back</span>.
          </>
        ) : (
          <>
            Start your <span className="text-brand">passport</span>.
          </>
        )}
      </h1>
      <p className="mt-3 text-ink/65">
        Your stamps, streaks, badges and trip budgets travel with your account.
      </p>

      <div className="mt-8 rounded-[2rem] bg-surface p-7 outline-1 -outline-offset-1 outline-ink/5">
        <button
          type="button"
          onClick={handleGoogle}
          className="w-full rounded-full border-2 border-ink/15 bg-cream px-6 py-3.5 font-semibold transition-colors hover:border-brand"
        >
          Continue with Google
        </button>

        <div className="my-6 flex items-center gap-4 text-sm text-ink/40">
          <span className="h-px flex-1 bg-ink/10" />
          or with email
          <span className="h-px flex-1 bg-ink/10" />
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "signup" && (
            <div>
              <label htmlFor="name" className="text-sm font-semibold text-ink/70">
                Traveller name
              </label>
              <input
                id="name"
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Ananya"
                className="mt-1.5 w-full rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
              />
            </div>
          )}
          <div>
            <label htmlFor="email" className="text-sm font-semibold text-ink/70">
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              className="mt-1.5 w-full rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
            />
          </div>
          <div>
            <label htmlFor="password" className="text-sm font-semibold text-ink/70">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              minLength={6}
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              className="mt-1.5 w-full rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
            />
          </div>

          {error && <p className="text-sm font-medium text-brand">{error}</p>}
          {message && <p className="text-sm font-medium text-plum">{message}</p>}

          <button
            type="submit"
            disabled={busy}
            className="btn-pop w-full py-3.5 text-lg hover:-translate-y-1 active:translate-y-0 active:btn-pop-active disabled:opacity-60"
          >
            {busy ? "One moment…" : mode === "signin" ? "Sign in" : "Create account"}
          </button>
        </form>

        <button
          type="button"
          onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
          className="mt-5 w-full text-sm font-semibold text-ink/55 hover:text-brand"
        >
          {mode === "signin"
            ? "New here? Create an account"
            : "Already have an account? Sign in"}
        </button>
      </div>
    </main>
  );
}
