import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";

import { planQuest, type QuestPlan } from "@/lib/planner.functions";
import { COVERAGE_TIERS, coverageStatus } from "@/lib/gamify";

export const Route = createFileRoute("/plan")({
  head: () => ({
    meta: [
      { title: "Quest planner — plan a heritage trip in India" },
      {
        name: "description",
        content:
          "Tell us a city, how many days and your budget. Get a day-by-day heritage quest with cheap stays nearby and badges for how much you cover.",
      },
      { property: "og:title", content: "Quest planner — TravelStrava" },
      {
        property: "og:description",
        content:
          "Day-by-day heritage itineraries on a budget, with stay areas next to the sites and trail badges for coverage.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PlanPage,
});

const STYLES = [
  { key: "shoestring", label: "Shoestring", hint: "Hostels, metro, street food" },
  { key: "value", label: "Low budget", hint: "Guesthouses, metro, local eateries" },
  { key: "comfort", label: "Comfort", hint: "Homestays, some cabs" },
] as const;

const QUICK = [
  { city: "Delhi", days: 5, budget: 12000 },
  { city: "Jaipur", days: 3, budget: 8000 },
  { city: "Varanasi", days: 4, budget: 9000 },
  { city: "Hampi", days: 3, budget: 7000 },
];

const rupee = (value: number) => `₹${Math.round(value || 0).toLocaleString("en-IN")}`;

function PlanPage() {
  const run = useServerFn(planQuest);
  const [city, setCity] = useState("Delhi");
  const [days, setDays] = useState(5);
  const [budget, setBudget] = useState(12000);
  const [style, setStyle] = useState<(typeof STYLES)[number]["key"]>("shoestring");
  const [plan, setPlan] = useState<QuestPlan | null>(null);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  async function build(next?: { city: string; days: number; budget: number }) {
    if (pending) return;
    const payload = {
      city: (next?.city ?? city).trim(),
      days: next?.days ?? days,
      budgetInr: next?.budget ?? budget,
      style,
    };
    if (payload.city.length < 2) return;
    if (next) {
      setCity(payload.city);
      setDays(payload.days);
      setBudget(payload.budgetInr);
    }
    setPending(true);
    setError("");
    setChecked({});
    try {
      const result = await run({ data: payload });
      setPlan(result);
      if (!result.itinerary.length)
        setError(result.money_tips[0] ?? "No plan came back — try again.");

    } catch {
      setError("The planner did not respond. Try again in a moment.");
    } finally {
      setPending(false);
    }
  }

  const allStops = plan?.itinerary.flatMap((day) => day.stops) ?? [];
  const totalStops = allStops.length;
  const plannedXp = allStops.reduce((sum, stop) => sum + (stop.xp || 0), 0);
  const tickedKeys = Object.keys(checked).filter((key) => checked[key]);
  const status = coverageStatus(totalStops);
  const doneStatus = coverageStatus(tickedKeys.length);
  const overBudget = (plan?.total_cost_inr ?? 0) > budget;

  return (
    <div className="scene-3d mx-auto w-full max-w-6xl px-6 py-14">
      <header className="surface-3d rounded-[2.5rem] bg-ink px-8 py-12 text-cream md:px-14">
        <p className="font-semibold text-accent">Quest planner</p>
        <h1 className="mt-2 font-display text-[clamp(2rem,5vw,3.5rem)] leading-tight font-bold">
          Tell me a city and a budget. I'll turn it into a quest.
        </h1>
        <p className="mt-4 max-w-2xl text-cream/70">
          Days packed with clustered sites, cheap stays within walking distance of
          them, and a trail badge that levels up with every extra place you cover.
        </p>

        <div className="mt-8 grid gap-4 md:grid-cols-[1.4fr_0.7fr_1fr_auto]">
          <label className="block">
            <span className="text-xs font-semibold text-cream/60">City</span>
            <input
              value={city}
              onChange={(event) => setCity(event.target.value)}
              placeholder="Delhi"
              className="mt-1 w-full rounded-2xl bg-cream/10 px-4 py-3 font-semibold text-cream outline-none placeholder:text-cream/40"
            />
          </label>
          <label className="block">
            <span className="text-xs font-semibold text-cream/60">Days</span>
            <input
              type="number"
              min={1}
              max={14}
              value={days}
              onChange={(event) => setDays(Number(event.target.value) || 1)}
              className="mt-1 w-full rounded-2xl bg-cream/10 px-4 py-3 font-semibold text-cream outline-none"
            />
          </label>
          <label className="block">
            <span className="text-xs font-semibold text-cream/60">Total budget ₹</span>
            <input
              type="number"
              min={500}
              step={500}
              value={budget}
              onChange={(event) => setBudget(Number(event.target.value) || 500)}
              className="mt-1 w-full rounded-2xl bg-cream/10 px-4 py-3 font-semibold text-cream outline-none"
            />
          </label>
          <button
            onClick={() => build()}
            disabled={pending}
            className="mt-6 rounded-2xl bg-accent px-7 py-3 font-display text-lg font-bold text-ink disabled:opacity-60"
          >
            {pending ? "Plotting…" : "Start quest"}
          </button>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          {STYLES.map((option) => (
            <button
              key={option.key}
              onClick={() => setStyle(option.key)}
              className={`rounded-full px-5 py-2 text-sm font-semibold transition ${
                style === option.key
                  ? "bg-accent text-ink"
                  : "bg-cream/10 text-cream/80 hover:bg-cream/20"
              }`}
            >
              {option.label} · {option.hint}
            </button>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          {QUICK.map((preset) => (
            <button
              key={preset.city}
              onClick={() => build(preset)}
              className="rounded-full border border-cream/20 px-4 py-1.5 text-xs font-semibold text-cream/70 hover:border-accent hover:text-accent"
            >
              {preset.city} · {preset.days}d · {rupee(preset.budget)}
            </button>
          ))}
        </div>
      </header>

      <section className="surface-3d mt-8 rounded-[2rem] bg-white p-7">
        <h2 className="font-display text-2xl font-bold">Trail badges for coverage</h2>
        <p className="mt-1 text-sm text-ink/60">
          The more places you actually tick off on this trip, the higher the trail
          badge you unlock.
        </p>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {COVERAGE_TIERS.map((tier) => {
            const unlocked = tickedKeys.length >= tier.stops;
            const planned = totalStops >= tier.stops;
            return (
              <div
                key={tier.name}
                className={`surface-3d rounded-[1.5rem] p-5 ${
                  unlocked
                    ? "bg-accent text-ink"
                    : planned
                      ? "bg-mint/40"
                      : "bg-cream/70 opacity-70"
                }`}
              >
                <p className="text-3xl">{tier.emoji}</p>
                <p className="mt-2 font-display text-lg font-bold">{tier.name}</p>
                <p className="text-sm text-ink/70">{tier.stops}+ places covered</p>
                <p className="mt-2 text-xs font-semibold">{tier.reward}</p>
                <p className="mt-2 text-xs font-semibold text-ink/60">
                  {unlocked
                    ? "Unlocked ✓"
                    : planned
                      ? "In this plan — go tick it off"
                      : "Locked"}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {error ? (
        <p className="mt-6 rounded-2xl bg-white p-5 font-semibold text-brand">{error}</p>
      ) : null}

      {plan && plan.itinerary.length > 0 ? (
        <>
          <section className="mt-8 grid gap-4 md:grid-cols-4">
            <div className="surface-3d rounded-[1.5rem] bg-white p-6">
              <p className="text-xs font-semibold text-ink/50">Places in this quest</p>
              <p className="mt-1 font-display text-3xl font-bold">{totalStops}</p>
              <p className="text-xs text-ink/60">
                {status.next
                  ? `${status.toNext} more for ${status.next.emoji} ${status.next.name}`
                  : "Top trail badge reached"}
              </p>
            </div>
            <div className="surface-3d rounded-[1.5rem] bg-white p-6">
              <p className="text-xs font-semibold text-ink/50">XP on offer</p>
              <p className="mt-1 font-display text-3xl font-bold text-brand">
                {plannedXp}
              </p>
              <p className="text-xs text-ink/60">Earned as you check in</p>
            </div>
            <div className="surface-3d rounded-[1.5rem] bg-white p-6">
              <p className="text-xs font-semibold text-ink/50">Planned cost</p>
              <p
                className={`mt-1 font-display text-3xl font-bold ${overBudget ? "text-brand" : ""}`}
              >
                {rupee(plan.total_cost_inr)}
              </p>
              <p className="text-xs text-ink/60">
                {overBudget
                  ? `Over your ${rupee(budget)} — see money tips`
                  : `Within your ${rupee(budget)}`}
              </p>
            </div>
            <div className="surface-3d rounded-[1.5rem] bg-white p-6">
              <p className="text-xs font-semibold text-ink/50">Ticked off</p>
              <p className="mt-1 font-display text-3xl font-bold">
                {tickedKeys.length}/{totalStops}
              </p>
              <div className="mt-3 h-3 overflow-hidden rounded-full bg-cream">
                <div
                  className="h-full rounded-full bg-accent transition-[width] duration-700"
                  style={{ width: `${Math.max(doneStatus.percent, 3)}%` }}
                />
              </div>
            </div>
          </section>

          {plan.stay.length > 0 ? (
            <section className="mt-8">
              <h2 className="font-display text-2xl font-bold">
                Stay close, walk more, spend less
              </h2>
              <div className="mt-4 grid gap-4 md:grid-cols-3">
                {plan.stay.map((option) => (
                  <div
                    key={option.area}
                    className="surface-3d rounded-[1.5rem] bg-white p-6"
                  >
                    <p className="font-display text-xl font-bold">{option.area}</p>
                    <p className="text-xs font-semibold text-brand">{option.type}</p>
                    <p className="mt-2 text-sm text-ink/70">{option.why}</p>
                    <p className="mt-3 font-semibold">
                      ~{rupee(option.per_night_inr)} / night
                    </p>
                  </div>
                ))}
              </div>
            </section>
          ) : null}

          <section className="mt-10 space-y-5">
            {plan.itinerary.map((day) => (
              <article
                key={day.day}
                className="surface-3d rounded-[2rem] bg-white p-7"
              >
                <div className="flex flex-wrap items-baseline justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold text-brand">Day {day.day}</p>
                    <h3 className="font-display text-2xl font-bold">{day.theme}</h3>
                    <p className="text-sm text-ink/60">Base: {day.base}</p>
                  </div>
                  <span className="rounded-full bg-cream px-4 py-1.5 text-sm font-semibold">
                    {rupee(day.day_cost_inr)} for the day
                  </span>
                </div>

                <ul className="mt-5 space-y-3">
                  {day.stops.map((stop, index) => {
                    const key = `${day.day}-${index}-${stop.name}`;
                    const done = !!checked[key];
                    return (
                      <li key={key}>
                        <button
                          onClick={() =>
                            setChecked((prev) => ({ ...prev, [key]: !prev[key] }))
                          }
                          className={`flex w-full items-start gap-4 rounded-[1.25rem] p-4 text-left transition ${
                            done ? "bg-mint/50" : "bg-cream/70 hover:bg-cream"
                          }`}
                        >
                          <span className="mt-0.5 text-xl">{done ? "✅" : "⬜"}</span>
                          <span className="flex-1">
                            <span className="block font-display text-lg font-bold">
                              {stop.name}
                            </span>
                            <span className="block text-sm text-ink/70">{stop.why}</span>
                            <span className="mt-1 flex flex-wrap gap-2 text-xs font-semibold">
                              <span className="rounded-full bg-white px-3 py-1">
                                {stop.hours}
                              </span>
                              <span className="rounded-full bg-white px-3 py-1">
                                Entry {rupee(stop.entry_inr)}
                              </span>
                              <span className="rounded-full bg-brand px-3 py-1 text-white">
                                +{stop.xp} XP
                              </span>
                            </span>
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>

                <div className="mt-5 grid gap-3 sm:grid-cols-2">
                  <p className="rounded-[1.25rem] bg-cream/70 p-4 text-sm">
                    🍽️ {day.food}
                  </p>
                  <p className="rounded-[1.25rem] bg-cream/70 p-4 text-sm">
                    🚇 {day.transport}
                  </p>
                </div>
              </article>
            ))}
          </section>

          {plan.money_tips.length > 0 ? (
            <section className="surface-3d mt-8 rounded-[2rem] bg-ink p-7 text-cream">
              <h2 className="font-display text-2xl font-bold">Keep it cheap</h2>
              <ul className="mt-4 space-y-2">
                {plan.money_tips.map((tip) => (
                  <li key={tip} className="rounded-2xl bg-cream/10 px-5 py-3">
                    {tip}
                  </li>
                ))}
              </ul>
              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  to="/budget"
                  className="rounded-full bg-accent px-6 py-3 font-semibold text-ink"
                >
                  Track this budget
                </Link>
                <Link
                  to="/copilot"
                  className="rounded-full border border-cream/30 px-6 py-3 font-semibold"
                >
                  Ask the copilot
                </Link>
              </div>
            </section>
          ) : null}
        </>
      ) : null}
    </div>
  );
}
