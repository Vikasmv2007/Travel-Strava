import { useState } from "react";
import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import {
  ACTIVITY_TYPES,
  createVisit,
  formatRupees,
  siteQuery,
  stampTint,
  tripsQuery,
} from "@/lib/travelstrava";
import { useSession } from "@/lib/session";
import { VENDOR_TYPES, vendorsQuery } from "@/lib/discovery";
import { MapView } from "@/components/MapView";
import { sitePhoto } from "@/lib/site-photos";



export const Route = createFileRoute("/sites/$siteId")({
  head: () => ({
    meta: [
      { title: "Heritage site — TravelStrava" },
      {
        name: "description",
        content:
          "History, crowd levels, safety and etiquette for this heritage site — then check in with a photo.",
      },
      { property: "og:title", content: "Heritage site — TravelStrava" },
      {
        property: "og:description",
        content: "History, safety, crowds and photo check-in for an Indian heritage site.",
      },
    ],
  }),
  loader: ({ context, params }) =>
    context.queryClient.ensureQueryData(siteQuery(params.siteId)),
  component: SiteDetail,
});

function SiteDetail() {
  const { siteId } = Route.useParams();
  const { data: site } = useQuery(siteQuery(siteId));
  const { data: vendors = [] } = useQuery(vendorsQuery);
  const { user } = useSession();
  const queryClient = useQueryClient();
  const router = useRouter();

  const [open, setOpen] = useState(false);
  const [caption, setCaption] = useState("");
  const [activity, setActivity] = useState<string>(ACTIVITY_TYPES[0].value);
  const [photo, setPhoto] = useState<File | null>(null);
  const [pledge, setPledge] = useState(true);
  const [tripId, setTripId] = useState("");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [status, setStatus] = useState<"idle" | "saving" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  const { data: trips = [] } = useQuery({
    ...tripsQuery(user?.id ?? ""),
    enabled: !!user,
  });

  if (!site) return null;

  function captureLocation() {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoords({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
        setLocating(false);
      },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 10000 },
    );
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    if (!site || !user) return;
    setStatus("saving");
    try {
      const { xpAwarded } = await createVisit({
        userId: user.id,
        siteId: site.id,
        caption,
        activityType: activity,
        photo,
        latitude: coords?.lat ?? null,
        longitude: coords?.lng ?? null,
        responsiblePledge: pledge,
        tripId: tripId || null,
      });
      await queryClient.invalidateQueries();
      setStatus("done");
      setMessage(`Stamp inked at ${site.name}. +${xpAwarded} XP.`);
      setCaption("");
      setPhoto(null);
      router.invalidate();

    } catch (error) {
      setStatus("error");
      setMessage(
        error instanceof Error ? error.message : "That check-in didn't go through.",
      );
    }
  }

  const safety = site.women_safety_rating ?? 0;
  const safetyBadge =
    safety >= 4.5
      ? { label: "Safe & well-patrolled", tone: "bg-mint" }
      : safety >= 3.5
        ? { label: "Generally safe — stay alert after dark", tone: "bg-accent" }
        : { label: "Take care — go in daylight, ideally with company", tone: "bg-brand text-cream" };
  const crowd = (site.crowd_level ?? "").toLowerCase();
  const needsRecovery = crowd.includes("high") || crowd.includes("very") || safety < 3.5;
  const siteVendors = vendors.filter((vendor) => vendor.site_id === site.id);

  return (
    <main className="mx-auto max-w-6xl px-5 pb-20 sm:px-8">
      <Link to="/" className="text-sm font-semibold text-ink/60 hover:text-brand">
        ← All sites
      </Link>

      {needsRecovery && (
        <div className="mt-5 flex flex-wrap items-center justify-between gap-4 rounded-[1.75rem] bg-plum p-6 text-cream">
          <p className="max-w-xl leading-relaxed">
            Heads up — this site is{" "}
            {crowd.includes("high") || crowd.includes("very")
              ? "crowded right now"
              : "rated lower on safety"}
            . Want a calmer nearby alternative or a replanned day?
          </p>
          <Link
            to="/copilot"
            className="rounded-full bg-cream px-6 py-3 font-semibold text-ink"
          >
            Replan with the copilot
          </Link>
        </div>
      )}

      {sitePhoto(site.name) && (
        <div className="surface-3d mt-5 overflow-hidden rounded-[2rem]">
          <img
            src={sitePhoto(site.name)!}
            alt={`${site.name} in ${site.region}`}
            className="h-[280px] w-full object-cover md:h-[420px]"
          />
        </div>
      )}

      <div className="mt-5 grid gap-5 md:grid-cols-3">
        <div className="rounded-[2rem] bg-mint p-8 md:col-span-2 md:p-10">

          <span
            className={`inline-grid size-14 place-items-center rounded-full border-2 bg-surface font-display text-xl font-bold ${
              stampTint[site.stamp_color] ?? stampTint["brand"]
            }`}
          >
            {site.stamp_code}
          </span>
          <h1 className="mt-5 font-display text-4xl font-bold tracking-tight">
            {site.name}
          </h1>
          <p className="mt-1 font-medium text-ink/60">{site.region}</p>
          <p className="mt-4 max-w-xl leading-relaxed text-ink/75">{site.history_blurb}</p>
          <div className="mt-6 flex flex-wrap gap-2 text-sm font-semibold">
            <span className="rounded-full bg-surface/50 px-4 py-1.5">
              +{site.xp_reward} XP
            </span>
            {site.best_time && (
              <span className="rounded-full bg-surface/50 px-4 py-1.5">
                Best time: {site.best_time}
              </span>
            )}
            {site.crowd_level && (
              <span className="rounded-full bg-surface/50 px-4 py-1.5">
                Crowds: {site.crowd_level}
              </span>
            )}
          </div>
        </div>

        <div className="rounded-[2rem] bg-accent p-8">
          <span className="inline-grid size-12 place-items-center rounded-2xl bg-surface/40 font-display text-xl font-bold">
            !
          </span>
          <h2 className="mt-5 font-display text-2xl font-bold">Safety</h2>
          <span
            className={`mt-3 inline-block rounded-full px-4 py-1.5 text-sm font-bold ${safetyBadge.tone}`}
          >
            {safetyBadge.label}
          </span>
          {safety > 0 && (
            <p className="mt-2 font-semibold">
              Women's safety {"★".repeat(safety)}
              <span className="text-ink/30">{"★".repeat(5 - safety)}</span>
            </p>
          )}
          <p className="mt-3 leading-relaxed text-ink/75">{site.safety_notes}</p>
          {site.emergency_contact && (
            <p className="mt-4 text-sm font-semibold">
              Emergency: {site.emergency_contact}
            </p>
          )}
        </div>

        {(site.entry_fee_inr !== null || site.guide_fee_inr !== null) && (
          <InfoCard title="What it costs">
            <ul className="space-y-1">
              {site.entry_fee_inr !== null && (
                <li>Entry: {formatRupees(site.entry_fee_inr)}</li>
              )}
              {site.guide_fee_inr !== null && (
                <li>Local guide: about {formatRupees(site.guide_fee_inr)}</li>
              )}
              {site.visitors_per_year !== null && (
                <li>{site.visitors_per_year.toLocaleString("en-IN")} visitors a year</li>
              )}
            </ul>
          </InfoCard>
        )}
        {site.etiquette && <InfoCard title="Etiquette">{site.etiquette}</InfoCard>}
        {site.accessibility_notes && (
          <InfoCard title="Accessibility">{site.accessibility_notes}</InfoCard>
        )}
        {site.local_legend && (
          <InfoCard title="Local legend">{site.local_legend}</InfoCard>
        )}
        {site.photo_spot && <InfoCard title="Best photo spot">{site.photo_spot}</InfoCard>}

        <div className="rounded-[2rem] bg-surface p-8 outline-1 -outline-offset-1 outline-ink/5 md:col-span-3">
          {!user ? (
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-display text-2xl font-bold">Been here?</h2>
                <p className="mt-2 text-ink/70">
                  Sign in to ink the stamp, earn XP and keep your streak alive.
                </p>
              </div>
              <Link to="/auth" className="btn-pop px-8 py-4 text-lg hover:-translate-y-1">
                Sign in to check in
              </Link>
            </div>
          ) : !open ? (
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-display text-2xl font-bold">Been here?</h2>
                <p className="mt-2 text-ink/70">
                  Add a photo and a line about your visit to ink the stamp.
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setOpen(true);
                  setStatus("idle");
                }}
                className="btn-pop px-8 py-4 text-lg hover:-translate-y-1 active:translate-y-0 active:btn-pop-active"
              >
                Check in
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="max-w-xl">
              <h2 className="font-display text-2xl font-bold">Check in at {site.name}</h2>

              <label className="mt-5 block text-sm font-semibold" htmlFor="activity">
                Activity
              </label>
              <select
                id="activity"
                value={activity}
                onChange={(event) => setActivity(event.target.value)}
                className="mt-2 w-full rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
              >
                {ACTIVITY_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>

              <label className="mt-5 block text-sm font-semibold" htmlFor="photo">
                Your photo
              </label>
              <input
                id="photo"
                type="file"
                accept="image/*"
                onChange={(event) => setPhoto(event.target.files?.[0] ?? null)}
                className="mt-2 w-full rounded-2xl border-2 border-dashed border-ink/20 bg-cream px-4 py-3 text-sm"
              />

              <div className="mt-5 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={captureLocation}
                  className="rounded-full bg-cream px-5 py-2.5 text-sm font-semibold text-ink/70 hover:text-brand"
                >
                  {locating ? "Locating…" : "Attach my location"}
                </button>
                {coords && (
                  <span className="text-sm font-semibold text-plum">
                    📍 {coords.lat.toFixed(4)}, {coords.lng.toFixed(4)}
                  </span>
                )}
              </div>

              {trips.length > 0 && (
                <>
                  <label className="mt-5 block text-sm font-semibold" htmlFor="trip">
                    Part of a trip?
                  </label>
                  <select
                    id="trip"
                    value={tripId}
                    onChange={(event) => setTripId(event.target.value)}
                    className="mt-2 w-full rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
                  >
                    <option value="">Not part of a trip</option>
                    {trips.map((trip) => (
                      <option key={trip.id} value={trip.id}>
                        {trip.title}
                      </option>
                    ))}
                  </select>
                </>
              )}

              <label className="mt-5 flex items-start gap-3 text-sm text-ink/75">
                <input
                  type="checkbox"
                  checked={pledge}
                  onChange={(event) => setPledge(event.target.checked)}
                  className="mt-1 size-4"
                />
                I left no litter, followed the site's etiquette and photographed
                respectfully.
              </label>


              <label className="mt-5 block text-sm font-semibold" htmlFor="caption">
                Caption
              </label>
              <input
                id="caption"
                value={caption}
                onChange={(event) => setCaption(event.target.value)}
                placeholder="Sunrise, no crowds, perfect light."
                className="mt-2 w-full rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
              />

              <div className="mt-6 flex flex-wrap items-center gap-4">
                <button
                  type="submit"
                  disabled={status === "saving"}
                  className="btn-pop px-8 py-3.5 text-lg hover:-translate-y-1 active:translate-y-0 active:btn-pop-active disabled:opacity-60"
                >
                  {status === "saving" ? "Inking…" : "Ink the stamp"}
                </button>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="font-semibold text-ink/60 hover:text-brand"
                >
                  Cancel
                </button>
              </div>

              {message && (
                <p
                  className={`mt-4 font-semibold ${
                    status === "error" ? "text-destructive" : "text-plum"
                  }`}
                >
                  {message}
                </p>
              )}
              {status === "done" && (
                <Link
                  to="/passport"
                  className="mt-2 inline-block font-semibold text-brand hover:underline"
                >
                  See it in your passport →
                </Link>
              )}
            </form>
          )}
        </div>
      </div>

      <section className="mt-10">
        <h2 className="font-display text-2xl font-bold">Where it is</h2>
        <div className="mt-4">
          <MapView
            className="h-[380px]"
            zoom={13}
            pins={[
              {
                id: site.id,
                name: site.name,
                subtitle: site.region,
                latitude: site.latitude,
                longitude: site.longitude,
              },
            ]}
          />
        </div>
      </section>

      {siteVendors.length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl font-bold">Local people around here</h2>
          <p className="mt-1 text-ink/60">
            Homestays, guides and stalls that usually stay invisible to visitors.
          </p>
          <div className="mt-5 grid gap-4 md:grid-cols-3">
            {siteVendors.map((vendor) => (
              <div key={vendor.id} className="rounded-[1.75rem] bg-surface p-6">
                <p className="text-2xl">
                  {VENDOR_TYPES.find((type) => type.value === vendor.vendor_type)
                    ?.emoji ?? "📍"}
                </p>
                <h3 className="mt-2 font-display text-lg font-bold">{vendor.name}</h3>
                <p className="text-sm text-ink/60">{vendor.description}</p>
                <p className="mt-3 text-sm font-semibold text-brand">
                  {vendor.price_from_inr
                    ? `From ${formatRupees(vendor.price_from_inr)}`
                    : "Ask for rates"}
                  {vendor.contact ? ` · ${vendor.contact}` : ""}
                </p>
              </div>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}

function InfoCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-[2rem] bg-surface p-7 outline-1 -outline-offset-1 outline-ink/5">
      <h2 className="font-display text-lg font-bold">{title}</h2>
      <div className="mt-2 leading-relaxed text-ink/70">{children}</div>
    </div>
  );
}
