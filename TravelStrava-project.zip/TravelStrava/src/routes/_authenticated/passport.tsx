import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import {
  computeBadges,
  myVisitsQuery,
  profileQuery,
  sitesQuery,
  stampTint,
} from "@/lib/travelstrava";
import { useSession } from "@/lib/session";
import { TRAVELER_CLASSES, updatePreferences } from "@/lib/discovery";
import { levelProgress } from "@/lib/gamify";

import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";

export const Route = createFileRoute("/_authenticated/passport")({
  head: () => ({
    meta: [
      { title: "My passport — TravelStrava" },
      {
        name: "description",
        content:
          "Your heritage stamps, XP, badges and check-in streak, collected across India.",
      },
      { property: "og:title", content: "My passport — TravelStrava" },
      {
        property: "og:description",
        content: "Heritage stamps, badges and streaks collected across India.",
      },
    ],
  }),
  component: Passport,
});

function Passport() {
  const { user } = useSession();
  const userId = user?.id ?? "";
  const { data: profile } = useQuery({ ...profileQuery(userId), enabled: !!userId });
  const { data: visits = [] } = useQuery({ ...myVisitsQuery(userId), enabled: !!userId });
  const { data: sites = [] } = useQuery(sitesQuery);

  const stampedIds = new Set(visits.map((visit) => visit.site.id));
  const locked = sites.filter((site) => !stampedIds.has(site.id));
  const badges = computeBadges(visits, profile ?? null);
  const prefs = profile as
    | {
        traveler_class?: string;
        location_consent?: boolean;
        safety_alert_consent?: boolean;
        emergency_contact_phone?: string | null;
        places_added?: number;
        places_verified?: number;
      }
    | null
    | undefined;
  const discovererBadges = [
    {
      name: "Discoverer",
      description: "Added a place that wasn't on any map",
      earned: (prefs?.places_added ?? 0) >= 1,
    },
    {
      name: "Cartographer",
      description: "Added 5 hidden places",
      earned: (prefs?.places_added ?? 0) >= 5,
    },
    {
      name: "Ground Truth",
      description: "GPS-verified 3 community finds",
      earned: (prefs?.places_verified ?? 0) >= 3,
    },
  ];
  const firstVisitPerSite = visits.filter(
    (visit, index) =>
      visits.findIndex((other) => other.site.id === visit.site.id) === index,
  );
  const shareText = `I've explored ${stampedIds.size} heritage site${
    stampedIds.size === 1 ? "" : "s"
  } across India on TravelStrava — ${profile?.xp ?? 0} XP and ${
    badges.filter((badge) => badge.earned).length
  } badges.`;
  const shareUrl = typeof window === "undefined" ? "" : window.location.origin;



  return (
    <main className="mx-auto max-w-6xl px-5 pb-20 sm:px-8">
      <div className="rounded-[2.5rem] bg-ink px-8 py-12 text-cream md:px-14">
        <p className="font-semibold text-cream/60">
          {profile?.display_name ?? "Traveller"}
        </p>
        <h1 className="mt-2 font-display text-[clamp(2rem,5vw,3.5rem)] leading-tight font-bold">
          {stampedIds.size} stamp{stampedIds.size === 1 ? "" : "s"} inked,{" "}
          <span className="text-accent">{profile?.xp ?? 0} XP</span> earned.
        </h1>
        <div className="mt-6 flex flex-wrap gap-3">
          <span className="rounded-full bg-cream/10 px-5 py-2 font-semibold">
            🔥 {profile?.current_streak ?? 0}-day streak
          </span>
          <span className="rounded-full bg-cream/10 px-5 py-2 font-semibold">
            Best: {profile?.longest_streak ?? 0} days
          </span>
          <span className="rounded-full bg-cream/10 px-5 py-2 font-semibold">
            {badges.filter((badge) => badge.earned).length}/{badges.length} badges
          </span>
        </div>

        <div className="mt-8 rounded-[1.75rem] bg-cream/10 p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="font-display text-xl font-bold">
              {levelProgress(profile?.xp ?? 0).level.emoji}{" "}
              {levelProgress(profile?.xp ?? 0).level.name}
            </p>
            <p className="text-sm font-semibold text-cream/70">
              {levelProgress(profile?.xp ?? 0).next
                ? `${levelProgress(profile?.xp ?? 0).xpToNext} XP to ${
                    levelProgress(profile?.xp ?? 0).next!.name
                  }`
                : "Max level"}
            </p>
          </div>
          <div className="mt-3 h-4 overflow-hidden rounded-full bg-cream/15">
            <div
              className="h-full rounded-full bg-accent transition-[width] duration-700"
              style={{
                width: `${Math.max(levelProgress(profile?.xp ?? 0).percent, 4)}%`,
              }}
            />
          </div>
        </div>



        <div className="mt-8 flex flex-wrap gap-2 print:hidden">
          <button
            onClick={() => {
              if (navigator.share) {
                void navigator.share({ title: "My heritage passport", text: shareText, url: shareUrl });
              } else {
                void navigator.clipboard.writeText(`${shareText} ${shareUrl}`);
              }
            }}
            className="rounded-full bg-accent px-5 py-2.5 font-semibold text-ink"
          >
            Share card
          </button>
          <a
            href={`https://wa.me/?text=${encodeURIComponent(`${shareText} ${shareUrl}`)}`}
            target="_blank"
            rel="noreferrer"
            className="rounded-full bg-cream/10 px-5 py-2.5 font-semibold"
          >
            WhatsApp
          </a>
          <a
            href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`}
            target="_blank"
            rel="noreferrer"
            className="rounded-full bg-cream/10 px-5 py-2.5 font-semibold"
          >
            LinkedIn
          </a>
          <a
            href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`}
            target="_blank"
            rel="noreferrer"
            className="rounded-full bg-cream/10 px-5 py-2.5 font-semibold"
          >
            X
          </a>
          <button
            onClick={() => {
              void navigator.clipboard.writeText(`${shareText} ${shareUrl}`);
            }}
            className="rounded-full bg-cream/10 px-5 py-2.5 font-semibold"
          >
            Copy for Instagram
          </button>
          <button
            onClick={() => window.print()}
            className="rounded-full bg-cream/10 px-5 py-2.5 font-semibold"
          >
            Print
          </button>
        </div>
      </div>


      <section className="mt-10">
        <h2 className="font-display text-3xl font-bold tracking-tight">Badges</h2>
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {badges.map((badge) => (
            <div
              key={badge.key}
              className={`rounded-[1.75rem] p-6 ${
                badge.earned
                  ? "bg-accent"
                  : "bg-surface outline-1 -outline-offset-1 outline-ink/5"
              }`}
            >
              <span
                className={`inline-grid size-12 place-items-center rounded-full font-display text-xl font-bold ${
                  badge.earned ? "bg-ink text-cream" : "bg-ink/5 text-ink/30"
                }`}
              >
                {badge.earned ? "★" : "☆"}
              </span>
              <h3 className="mt-4 font-display text-lg font-bold">{badge.name}</h3>
              <p className="text-sm text-ink/60">{badge.description}</p>
              <p className="mt-3 text-sm font-semibold text-ink/75">{badge.progress}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-12">
        <h2 className="font-display text-3xl font-bold tracking-tight">Collected</h2>
        {firstVisitPerSite.length === 0 ? (
          <div className="mt-5 rounded-[2rem] bg-surface p-10 text-center outline-1 -outline-offset-1 outline-ink/5">
            <p className="text-ink/70">No stamps yet. Pick a site and check in with a photo.</p>
            <Link
              to="/"
              className="btn-pop mt-6 inline-block px-8 py-3.5 text-lg hover:-translate-y-1"
            >
              Browse sites
            </Link>
          </div>
        ) : (
          <div className="mt-5 grid gap-5 md:grid-cols-3">
            {firstVisitPerSite.map((visit) => (
              <article
                key={visit.id}
                className="overflow-hidden rounded-[2rem] bg-surface outline-1 -outline-offset-1 outline-ink/5"
              >
                {visit.signedPhoto && (
                  <img
                    src={visit.signedPhoto}
                    alt={`Check-in photo at ${visit.site.name}`}
                    loading="lazy"
                    className="aspect-[4/3] w-full object-cover"
                  />
                )}
                <div className="p-6">
                  <span
                    className={`animate-stamp inline-grid size-14 place-items-center rounded-full border-2 font-display text-lg font-bold ${
                      stampTint[visit.site.stamp_color] ?? stampTint["brand"]
                    }`}
                  >
                    {visit.site.stamp_code}
                  </span>
                  <h3 className="mt-4 font-display text-xl font-bold">{visit.site.name}</h3>
                  <p className="text-sm text-ink/55">{visit.site.region}</p>
                  {visit.caption && (
                    <p className="mt-3 leading-relaxed text-ink/70">"{visit.caption}"</p>
                  )}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {locked.length > 0 && (
        <section className="mt-12">
          <h2 className="font-display text-3xl font-bold tracking-tight">Still locked</h2>
          <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-5">
            {locked.map((site) => (
              <Link
                key={site.id}
                to="/sites/$siteId"
                params={{ siteId: site.id }}
                className="rounded-[1.5rem] border-2 border-dashed border-ink/20 p-5 text-center transition-colors hover:border-brand"
              >
                <span className="inline-grid size-12 place-items-center rounded-full border-2 border-dashed border-ink/25 font-display font-bold text-ink/30">
                  ?
                </span>
                <p className="mt-3 text-sm font-semibold text-ink/60">{site.name}</p>
              </Link>
            ))}
          </div>
        </section>
      )}

      <section className="mt-10 rounded-[2rem] bg-surface p-7 outline-1 -outline-offset-1 outline-ink/5">
        <h2 className="font-display text-2xl font-bold">Discoverer stamps</h2>
        <p className="mt-1 text-ink/60">
          {prefs?.places_added ?? 0} places added · {prefs?.places_verified ?? 0}{" "}
          verified for other travellers. This is what keeps the map fresh.
        </p>
        <div className="mt-5 grid gap-3 sm:grid-cols-3">
          {discovererBadges.map((badge) => (
            <div
              key={badge.name}
              className={`rounded-[1.5rem] p-5 ${
                badge.earned ? "bg-accent" : "bg-cream opacity-60"
              }`}
            >
              <p className="font-display text-lg font-bold">{badge.name}</p>
              <p className="mt-1 text-sm text-ink/65">{badge.description}</p>
            </div>
          ))}
        </div>
      </section>

      <Preferences userId={userId} prefs={prefs ?? null} />
    </main>
  );
}

function Preferences({
  userId,
  prefs,
}: {
  userId: string;
  prefs: {
    traveler_class?: string;
    location_consent?: boolean;
    safety_alert_consent?: boolean;
    emergency_contact_phone?: string | null;
  } | null;
}) {
  const queryClient = useQueryClient();
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    traveler_class: prefs?.traveler_class ?? "explorer",
    location_consent: prefs?.location_consent ?? false,
    safety_alert_consent: prefs?.safety_alert_consent ?? false,
    emergency_contact_phone: prefs?.emergency_contact_phone ?? "",
  });

  async function save(event: React.FormEvent) {
    event.preventDefault();
    await updatePreferences(userId, {
      ...form,
      emergency_contact_phone: form.emergency_contact_phone || null,
    });
    setSaved(true);
    await queryClient.invalidateQueries({ queryKey: ["profile", userId] });
  }

  return (
    <section className="mt-10 rounded-[2rem] bg-mint/40 p-7">
      <h2 className="font-display text-2xl font-bold">Safety & personalisation</h2>
      <p className="mt-1 text-ink/70">
        Nothing is shared unless you switch it on here.
      </p>
      <form onSubmit={save} className="mt-5 grid gap-4">
        <label className="text-sm font-semibold" htmlFor="travelerClass">
          Traveller type — this shapes what gets recommended to you
        </label>
        <select
          id="travelerClass"
          value={form.traveler_class}
          onChange={(event) => setForm({ ...form, traveler_class: event.target.value })}
          className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
        >
          {TRAVELER_CLASSES.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>

        <input
          value={form.emergency_contact_phone}
          onChange={(event) =>
            setForm({ ...form, emergency_contact_phone: event.target.value })
          }
          placeholder="Emergency contact phone"
          className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
        />

        <label className="flex items-start gap-3 text-sm">
          <input
            type="checkbox"
            checked={form.location_consent}
            onChange={(event) =>
              setForm({ ...form, location_consent: event.target.checked })
            }
            className="mt-1 size-4"
          />
          Save my location with check-ins and SOS alerts.
        </label>
        <label className="flex items-start gap-3 text-sm">
          <input
            type="checkbox"
            checked={form.safety_alert_consent}
            onChange={(event) =>
              setForm({ ...form, safety_alert_consent: event.target.checked })
            }
            className="mt-1 size-4"
          />
          Send me safety and crowd alerts for places I'm near.
        </label>

        <div className="flex items-center gap-4">
          <button type="submit" className="btn-pop px-7 py-3 hover:-translate-y-1">
            Save settings
          </button>
          {saved && <span className="font-semibold text-plum">Saved.</span>}
        </div>
      </form>
    </section>
  );
}
