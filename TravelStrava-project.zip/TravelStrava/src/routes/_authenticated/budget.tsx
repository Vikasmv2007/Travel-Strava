import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";

import {
  EXPENSE_CATEGORIES,
  addExpense,
  createTrip,
  deleteExpense,
  expensesQuery,
  formatRupees,
  joinTripByCode,
  tripMembersQuery,
  tripVisitsQuery,
  tripsQuery,
} from "@/lib/travelstrava";
import { suggestBudgetSavings } from "@/lib/copilot.functions";
import { useSession } from "@/lib/session";

export const Route = createFileRoute("/_authenticated/budget")({
  head: () => ({
    meta: [
      { title: "Trips & budget — TravelStrava" },
      {
        name: "description",
        content:
          "Plan multi-day heritage trips, invite friends with a code, track expenses and get saving ideas.",
      },
      { property: "og:title", content: "Trips & budget — TravelStrava" },
      {
        property: "og:description",
        content: "Plan heritage trips with friends and track what they actually cost.",
      },
    ],
  }),
  component: Budget,
});

function Budget() {
  const { user } = useSession();
  const userId = user?.id ?? "";
  const queryClient = useQueryClient();
  const suggest = useServerFn(suggestBudgetSavings);

  const { data: trips = [] } = useQuery({ ...tripsQuery(userId), enabled: !!userId });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const tripId = selectedId ?? trips[0]?.id ?? null;
  const trip = trips.find((item) => item.id === tripId) ?? null;

  const { data: expenses = [] } = useQuery({
    ...expensesQuery(tripId ?? ""),
    enabled: !!tripId,
  });
  const { data: members = [] } = useQuery({
    ...tripMembersQuery(tripId ?? ""),
    enabled: !!tripId,
  });
  const { data: tripVisits = [] } = useQuery({
    ...tripVisitsQuery(tripId ?? ""),
    enabled: !!tripId,
  });

  const [title, setTitle] = useState("");
  const [budget, setBudget] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [code, setCode] = useState("");
  const [joinMessage, setJoinMessage] = useState("");
  const [label, setLabel] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState(EXPENSE_CATEGORIES[0].value as string);
  const [tips, setTips] = useState<string | null>(null);
  const [thinking, setThinking] = useState(false);

  const spent = expenses.reduce((sum, item) => sum + item.amount_inr, 0);
  const remaining = (trip?.budget_inr ?? 0) - spent;
  const contributors = new Set(tripVisits.map((visit) => visit.profile?.id)).size;

  const newTrip = useMutation({
    mutationFn: () =>
      createTrip({
        userId,
        title: title.trim(),
        budget: Number(budget) || 0,
        startDate,
        endDate,
      }),
    onSuccess: (id) => {
      setTitle("");
      setBudget("");
      setStartDate("");
      setEndDate("");
      setSelectedId(id);
      queryClient.invalidateQueries({ queryKey: ["trips", userId] });
    },
  });

  const join = useMutation({
    mutationFn: () => joinTripByCode(code, userId),
    onSuccess: (id) => {
      setCode("");
      setJoinMessage("Joined the trip.");
      setSelectedId(id);
      queryClient.invalidateQueries({ queryKey: ["trips", userId] });
    },
    onError: (error) =>
      setJoinMessage(error instanceof Error ? error.message : "Could not join that trip."),
  });

  const newExpense = useMutation({
    mutationFn: () =>
      addExpense({
        userId,
        tripId: tripId!,
        category,
        label: label.trim(),
        amount: Number(amount) || 0,
      }),
    onSuccess: () => {
      setLabel("");
      setAmount("");
      queryClient.invalidateQueries({ queryKey: ["expenses", tripId] });
    },
  });

  const removeExpense = useMutation({
    mutationFn: (id: string) => deleteExpense(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["expenses", tripId] }),
  });

  async function handleSuggest() {
    if (!trip) return;
    setThinking(true);
    setTips(null);
    try {
      const byCategory = EXPENSE_CATEGORIES.map((item) => ({
        category: item.label,
        amount: expenses
          .filter((expense) => expense.category === item.value)
          .reduce((sum, expense) => sum + expense.amount_inr, 0),
      })).filter((row) => row.amount > 0);

      const result = await suggest({
        data: { title: trip.title, budget: trip.budget_inr, spent, breakdown: byCategory },
      });
      setTips(result.tips);
    } catch {
      setTips("Could not fetch savings ideas right now.");
    } finally {
      setThinking(false);
    }
  }

  return (
    <main className="mx-auto max-w-5xl px-5 pb-20 sm:px-8">
      <h1 className="font-display text-[clamp(2rem,5vw,3.5rem)] leading-tight font-bold tracking-tight">
        Plan the trip. Split the <span className="text-plum">cost</span>.
      </h1>

      <section className="mt-8 rounded-[2rem] bg-surface p-7 outline-1 -outline-offset-1 outline-ink/5">
        <h2 className="font-display text-xl font-bold">Plan a new trip</h2>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            if (title.trim()) newTrip.mutate();
          }}
          className="mt-4 flex flex-wrap gap-3"
        >
          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Hampi & Badami, 4 days"
            className="min-w-[14rem] flex-1 rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
          />
          <input
            value={budget}
            onChange={(event) => setBudget(event.target.value)}
            inputMode="numeric"
            placeholder="Budget ₹"
            className="w-36 rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
          />
          <input
            type="date"
            value={startDate}
            onChange={(event) => setStartDate(event.target.value)}
            className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
          />
          <input
            type="date"
            value={endDate}
            onChange={(event) => setEndDate(event.target.value)}
            className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
          />
          <button type="submit" className="btn-pop px-7 py-3 hover:-translate-y-1">
            Add trip
          </button>
        </form>

        <form
          onSubmit={(event) => {
            event.preventDefault();
            if (code.trim()) join.mutate();
          }}
          className="mt-5 flex flex-wrap items-center gap-3 border-t border-ink/10 pt-5"
        >
          <span className="font-semibold">Joining friends?</span>
          <input
            value={code}
            onChange={(event) => setCode(event.target.value.toUpperCase())}
            placeholder="Invite code"
            className="w-44 rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 tracking-widest outline-none focus:border-brand"
          />
          <button
            type="submit"
            className="rounded-full bg-ink px-6 py-3 font-semibold text-cream"
          >
            Join trip
          </button>
          {joinMessage && <span className="text-sm text-ink/60">{joinMessage}</span>}
        </form>

        {trips.length > 1 && (
          <div className="mt-5 flex flex-wrap gap-2">
            {trips.map((item) => (
              <button
                key={item.id}
                onClick={() => setSelectedId(item.id)}
                className={`rounded-full px-4 py-2 text-sm font-semibold ${
                  item.id === tripId ? "bg-ink text-cream" : "bg-cream text-ink/65"
                }`}
              >
                {item.title}
              </button>
            ))}
          </div>
        )}
      </section>

      {trip && (
        <>
          <section className="mt-6 rounded-[2rem] bg-mint p-7">
            <h2 className="font-display text-2xl font-bold">{trip.title}</h2>
            <p className="mt-1 text-ink/70">
              {trip.start_date && trip.end_date
                ? `${trip.start_date} → ${trip.end_date}`
                : "Dates not set"}{" "}
              · {members.length + 1} traveller{members.length === 0 ? "" : "s"} ·{" "}
              {contributors} posting photos
            </p>
            <div className="mt-4 flex flex-wrap items-center gap-3">
              <span className="rounded-full bg-surface px-5 py-2 font-display text-lg font-bold tracking-widest">
                {trip.invite_code}
              </span>
              <button
                onClick={() => {
                  void navigator.clipboard.writeText(trip.invite_code);
                }}
                className="rounded-full bg-surface/60 px-5 py-2 text-sm font-semibold"
              >
                Copy invite code
              </button>
            </div>
          </section>

          <section className="mt-6 grid gap-4 sm:grid-cols-3">
            <Stat label="Budget" value={formatRupees(trip.budget_inr)} tone="bg-accent" />
            <Stat label="Spent" value={formatRupees(spent)} tone="bg-mint/40" />
            <Stat
              label={remaining >= 0 ? "Left" : "Over budget"}
              value={formatRupees(Math.abs(remaining))}
              tone={remaining >= 0 ? "bg-surface" : "bg-brand/15"}
            />
          </section>

          <section className="mt-6 rounded-[2rem] bg-surface p-7 outline-1 -outline-offset-1 outline-ink/5">
            <h2 className="font-display text-xl font-bold">Log an expense</h2>
            <form
              onSubmit={(event) => {
                event.preventDefault();
                if (label.trim() && Number(amount) > 0) newExpense.mutate();
              }}
              className="mt-4 flex flex-wrap gap-3"
            >
              <select
                value={category}
                onChange={(event) => setCategory(event.target.value)}
                className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
              >
                {EXPENSE_CATEGORIES.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.label}
                  </option>
                ))}
              </select>
              <input
                value={label}
                onChange={(event) => setLabel(event.target.value)}
                placeholder="Virupaksha Temple guide"
                className="min-w-[12rem] flex-1 rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
              />
              <input
                value={amount}
                onChange={(event) => setAmount(event.target.value)}
                inputMode="numeric"
                placeholder="₹"
                className="w-32 rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
              />
              <button type="submit" className="btn-pop px-7 py-3 hover:-translate-y-1">
                Add
              </button>
            </form>

            <ul className="mt-5 space-y-2">
              {expenses.map((expense) => (
                <li
                  key={expense.id}
                  className="flex items-center gap-3 rounded-2xl bg-cream px-4 py-3"
                >
                  <span className="rounded-full bg-ink/5 px-3 py-1 text-xs font-semibold text-ink/60">
                    {EXPENSE_CATEGORIES.find((item) => item.value === expense.category)
                      ?.label ?? expense.category}
                  </span>
                  <span className="flex-1 font-medium">{expense.label}</span>
                  <span className="font-display font-bold">
                    {formatRupees(expense.amount_inr)}
                  </span>
                  <button
                    onClick={() => removeExpense.mutate(expense.id)}
                    className="text-sm text-ink/40 hover:text-brand"
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          </section>

          <section className="mt-6 rounded-[2rem] bg-surface p-7 outline-1 -outline-offset-1 outline-ink/5">
            <h2 className="font-display text-xl font-bold">Trip check-ins</h2>
            {tripVisits.length === 0 ? (
              <p className="mt-2 text-ink/60">
                Nobody has posted a photo for this trip yet — everyone's check-ins show up
                here.
              </p>
            ) : (
              <ul className="mt-4 grid gap-3 sm:grid-cols-2">
                {tripVisits.map((visit) => (
                  <li key={visit.id} className="flex items-center gap-3 rounded-2xl bg-cream p-3">
                    {visit.signedPhoto && (
                      <img
                        src={visit.signedPhoto}
                        alt={`Check-in at ${visit.site.name}`}
                        loading="lazy"
                        className="size-16 rounded-xl object-cover"
                      />
                    )}
                    <div>
                      <p className="font-semibold">{visit.site.name}</p>
                      <p className="text-sm text-ink/55">
                        {visit.profile?.display_name ?? "Traveller"}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="mt-6 rounded-[2rem] bg-ink p-7 text-cream">
            <h2 className="font-display text-xl font-bold">Ways to save</h2>
            <p className="mt-1 text-cream/60">
              Suggestions based on what you've logged for {trip.title}.
            </p>
            <button
              onClick={handleSuggest}
              disabled={thinking}
              className="mt-4 rounded-full bg-accent px-6 py-3 font-semibold text-ink disabled:opacity-60"
            >
              {thinking ? "Thinking…" : "Suggest savings"}
            </button>
            {tips && <p className="mt-5 whitespace-pre-line text-cream/85">{tips}</p>}
          </section>
        </>
      )}
    </main>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className={`rounded-[1.75rem] p-6 ${tone}`}>
      <p className="text-sm font-semibold text-ink/60">{label}</p>
      <p className="mt-1 font-display text-3xl font-bold">{value}</p>
    </div>
  );
}
