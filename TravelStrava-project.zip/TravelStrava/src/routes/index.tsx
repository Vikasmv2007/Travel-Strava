import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";

import heroImage from "@/assets/hero-heritage.jpg";
import {
  sitesQuery,
  leaderboardQuery,
  myVisitsQuery,
  profileQuery,
  stampTint,
  formatRupees,
} from "@/lib/travelstrava";
import {
  placesQuery,
  recommend,
  vendorsQuery,
  VENDOR_TYPES,
  type DiscoveredPlace,
} from "@/lib/discovery";
import { useOfflineCache } from "@/lib/offline";
import { MapView } from "@/components/MapView";
import { LevelBar } from "@/components/LevelBar";
import { QuestBoard } from "@/components/QuestBoard";
import { buildQuests } from "@/lib/gamify";
import { sitePhoto } from "@/lib/site-photos";
import { useSession } from "@/lib/session";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TravelStrava — Heritage sites of India" },
      {
        name: "description",
        content:
          "Browse ten Indian heritage sites, check in with a photo and start collecting passport stamps.",
      },
      { property: "og:title", content: "TravelStrava — Heritage sites of India" },
      {
        property: "og:description",
        content: "Check in at heritage sites, collect stamps and earn XP.",
      },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(sitesQuery),
  component: Index,
});

function Index() {
  const { data: siteData } = useQuery(sitesQuery);
  const sites = useOfflineCache("sites", siteData) ?? [];
  const { data: users = [] } = useQuery(leaderboardQuery);
  const { data: placeData } = useQuery(placesQuery);
  const places = useOfflineCache<DiscoveredPlace[]>("places", placeData) ?? [];
  const { data: vendors = [] } = useQuery(vendorsQuery);
  const { user } = useSession();
  const { data: profile } = useQuery({
    ...profileQuery(user?.id ?? ""),
    enabled: !!user,
  });
  const { data: myVisits = [] } = useQuery({
    ...myVisitsQuery(user?.id ?? ""),
    enabled: !!user,
  });

  const verifiedPlaces = places.filter((place) => place.status === "verified").length;
  const today = new Date().toISOString().slice(0, 10);
  const quests = buildQuests({
    visits: myVisits.length,
    visitsToday: myVisits.filter((visit) => visit.created_at.slice(0, 10) === today)
      .length,
    placesAdded: places.filter((place) => place.created_by === user?.id).length,
    placesVerified: places.filter((place) =>
      place.place_verifications?.some((row) => row.user_id === user?.id),
    ).length,
    photos: myVisits.filter((visit) => visit.hasPhoto).length,
    expenses: 0,
    distinctRegions: new Set(myVisits.map((visit) => visit.site.region)).size,
  });
  const recommendations = recommend({
    sites,
    places,
    visitedSiteIds: new Set(myVisits.map((visit) => visit.site.id)),
    visitedRegions: new Set(myVisits.map((visit) => visit.site.region)),
    profile: profile ?? null,
  });


  return (
    <main>
      <h1 className="sr-only">TravelStrava — collect India's heritage</h1>

      <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 pt-6 pb-16 sm:px-8 lg:grid-cols-12">
        <div className="lg:col-span-7">
          <span className="inline-flex items-center gap-2 rounded-full border border-accent bg-accent/40 px-4 py-1.5 text-sm font-semibold">
            <span className="size-2 rounded-full bg-brand" /> {sites.length} listed sites ·{" "}
            {places.length} traveller-found places
          </span>
          <p className="mt-6 font-display text-[clamp(2.75rem,7vw,5.5rem)] leading-[0.95] font-bold tracking-tight">
            India's heritage is <span className="text-brand">already</span>
            <br />
            <span className="text-plum">there</span>. It's just unseen.
          </p>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-ink/65">
            Stepwells nobody lists, homestays with empty rooms, guides with no bookings,
            food stalls off every itinerary. TravelStrava turns that idle local capacity
            into a living, traveller-verified map — and pays it back to the people who
            live there.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <a
              href="#unused"
              className="btn-pop px-8 py-4 text-lg hover:-translate-y-1 active:translate-y-0 active:btn-pop-active"
            >
              See what's idle
            </a>
            <Link
              to="/copilot"
              className="rounded-full border-2 border-ink px-8 py-4 text-lg font-semibold transition-colors hover:bg-ink hover:text-cream"
            >
              Ask the copilot
            </Link>
          </div>
          <div className="mt-8 flex items-center gap-3">
            <div className="flex -space-x-3">
              {users.slice(0, 4).map((user, i) => (
                <span
                  key={user.id}
                  className={`grid size-9 place-items-center rounded-full font-display text-xs font-bold ring-2 ring-cream ${
                    ["bg-mint", "bg-plum text-cream", "bg-accent", "bg-brand text-cream"][
                      i % 4
                    ]
                  }`}
                >
                  {user.avatar_initials}
                </span>
              ))}
            </div>
            <p className="text-sm font-medium text-ink/60">
              <span className="font-bold text-ink">{users.length}</span> travellers
              collecting stamps
            </p>
          </div>
        </div>

        <div className="lg:col-span-5">
          <div className="relative">
            <div className="absolute -top-6 -right-4 -z-10 size-24 rounded-full bg-accent" />
            <div className="absolute -bottom-8 -left-6 -z-10 size-20 rounded-full bg-mint" />
            <img
              src={heroImage}
              alt="Toy-like models of Indian heritage monuments surrounded by travel stamps"
              width={1024}
              height={1024}
              className="aspect-square w-full rounded-[2rem] object-cover"
            />
            <div className="absolute top-8 -left-5 rotate-[-4deg] rounded-2xl bg-surface px-4 py-3 shadow-lg">
              <p className="text-xs font-semibold text-ink/50">Per check-in</p>
              <p className="font-display font-bold text-ink">+10 XP</p>
            </div>
            <div className="absolute -right-4 bottom-10 rotate-[5deg] rounded-2xl bg-plum px-4 py-3 text-cream shadow-lg">
              <p className="text-xs font-semibold text-cream/70">Stamps</p>
              <p className="font-display font-bold">{sites.length} to collect</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-16 sm:px-8">
        {user ? (
          <div className="grid gap-5 lg:grid-cols-12">
            <div className="lg:col-span-5">
              <LevelBar
                xp={profile?.xp ?? 0}
                streak={profile?.current_streak ?? 0}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-3 lg:col-span-7">
              <Tile
                tone="bg-accent"
                value={`${myVisits.length}`}
                label="Stamps collected"
                note={`${sites.length - new Set(myVisits.map((v) => v.site.id)).size} still locked`}
              />
              <Tile
                tone="bg-mint"
                value={`${profile?.longest_streak ?? 0}`}
                label="Best streak"
                note="Check in on back-to-back days to beat it"
              />
              <Tile
                tone="bg-plum text-cream"
                value={`${quests.filter((q) => q.done >= q.target).length}/${quests.length}`}
                label="Quests cleared"
                note="New quests unlock as you level up"
              />
            </div>
          </div>
        ) : (
          <div className="surface-3d rounded-[2rem] bg-plum p-8 text-cream md:p-10">
            <p className="font-display text-2xl font-bold">
              Level up from Wanderer 🥾 to Heritage Legend 👑
            </p>
            <p className="mt-2 max-w-2xl text-cream/80">
              Check in, discover hidden places, verify others and collect stamps. Every
              action earns XP, keeps your streak alive and clears quests.
            </p>
            <Link
              to="/auth"
              className="mt-6 inline-block rounded-full bg-cream px-7 py-3.5 font-semibold text-ink transition-transform hover:-translate-y-0.5"
            >
              Start your passport
            </Link>
          </div>
        )}

        <div className="mt-10">
          <QuestBoard quests={quests} />
        </div>

        <div className="surface-3d mt-8 flex flex-wrap items-center justify-between gap-4 rounded-[2rem] bg-ink p-7 text-cream">
          <div>
            <h3 className="font-display text-2xl font-bold">
              Planning a city? Turn it into a quest.
            </h3>
            <p className="mt-1 text-cream/70">
              5 days in Delhi on ₹12,000 — clustered sites, cheap stays beside
              them, and trail badges for how many places you cover.
            </p>
          </div>
          <Link
            to="/plan"
            className="rounded-full bg-accent px-7 py-3.5 font-display text-lg font-bold text-ink"
          >
            Plan a quest
          </Link>
        </div>
      </section>





      <section id="unused" className="mx-auto max-w-6xl px-5 pb-16 sm:px-8">
        <h2 className="font-display text-3xl font-bold tracking-tight">
          The resource nobody is using
        </h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Tile
            tone="bg-accent"
            value={`${places.length}`}
            label="Hidden places mapped by travellers"
            note="Added with photo, GPS and the story behind them"
          />
          <Tile
            tone="bg-mint"
            value={`${verifiedPlaces}`}
            label="Confirmed on the ground"
            note="Trusted only after 3 independent GPS visits"
          />
          <Tile
            tone="bg-surface"
            value={`${vendors.length}`}
            label="Homestays, guides and stalls surfaced"
            note="Idle local capacity made bookable"
          />
          <Tile
            tone="bg-plum text-cream"
            value={`${sites.length}`}
            label="Listed monuments as the starting grid"
            note="Every check-in feeds the same data pipeline"
          />
        </div>
        <Link
          to="/discover"
          className="mt-6 inline-block rounded-full bg-ink px-7 py-3.5 font-semibold text-cream transition-transform hover:-translate-y-0.5"
        >
          Add a place nobody has listed
        </Link>
      </section>

      {recommendations.length > 0 && (
        <section className="mx-auto max-w-6xl px-5 pb-16 sm:px-8">
          <h2 className="font-display text-3xl font-bold tracking-tight">
            Picked for you
          </h2>
          <p className="mt-1 text-ink/60">
            {user
              ? "Built from your verified check-ins and your traveller type — set it in your passport."
              : "Sign in and we tune this to your traveller type and where you've already been."}
          </p>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {recommendations.map((item) =>
              item.kind === "site" && item.siteId ? (
                <Link
                  key={item.key}
                  to="/sites/$siteId"
                  params={{ siteId: item.siteId }}
                  className="rounded-[1.75rem] bg-surface p-6 outline-1 -outline-offset-1 outline-ink/5 transition-transform hover:-translate-y-1"
                >
                  <p className="text-xs font-bold text-brand">LISTED SITE</p>
                  <h3 className="mt-2 font-display text-xl font-bold">{item.title}</h3>
                  <p className="text-sm text-ink/55">{item.region}</p>
                  <p className="mt-3 text-sm text-ink/70">Because {item.reason}.</p>
                </Link>
              ) : (
                <Link
                  key={item.key}
                  to="/discover"
                  className="rounded-[1.75rem] bg-accent/40 p-6 transition-transform hover:-translate-y-1"
                >
                  <p className="text-xs font-bold text-plum">COMMUNITY FIND</p>
                  <h3 className="mt-2 font-display text-xl font-bold">{item.title}</h3>
                  <p className="text-sm text-ink/55">{item.region}</p>
                  <p className="mt-3 text-sm text-ink/70">Because {item.reason}.</p>
                </Link>
              ),
            )}
          </div>
        </section>
      )}

      <section className="mx-auto max-w-6xl px-5 pb-16 sm:px-8">
        <h2 className="font-display text-3xl font-bold tracking-tight">
          The map of it all
        </h2>
        <p className="mt-1 text-ink/60">
          Orange pins are listed monuments, purple pins are places travellers found
          themselves. Tap any pin for its name.
        </p>
        <div className="mt-6">
          <MapView
            className="h-[460px]"
            pins={[
              ...sites.map((site) => ({
                id: site.id,
                name: site.name,
                subtitle: site.region,
                latitude: site.latitude,
                longitude: site.longitude,
                tone: "brand" as const,
              })),
              ...places.map((place) => ({
                id: place.id,
                name: place.name,
                subtitle: `${place.region} · community find`,
                latitude: place.latitude,
                longitude: place.longitude,
                tone: "plum" as const,
              })),
            ]}
          />
        </div>
      </section>

      <section id="sites" className="mx-auto max-w-6xl px-5 pb-20 sm:px-8">
        <h2 className="font-display text-3xl font-bold tracking-tight">Heritage sites</h2>
        <div className="mt-6 grid grid-cols-1 gap-5 md:grid-cols-3">
          {sites.map((site) => (
            <Link
              key={site.id}
              to="/sites/$siteId"
              params={{ siteId: site.id }}
              className="surface-3d overflow-hidden rounded-[2rem] bg-surface outline-1 -outline-offset-1 outline-ink/5 transition-transform hover:-translate-y-1"
            >
              {sitePhoto(site.name) && (
                <div className="relative">
                  <img
                    src={sitePhoto(site.name)!}
                    alt={`${site.name} in ${site.region}`}
                    loading="lazy"
                    className="h-48 w-full object-cover"
                  />
                  <span className="absolute top-4 right-4 rounded-full bg-ink/85 px-3 py-1 text-xs font-bold text-cream">
                    +{site.xp_reward} XP
                  </span>
                </div>
              )}
              <div className="p-8">
              <span
                className={`inline-grid size-12 place-items-center rounded-full border-2 font-display text-lg font-bold ${
                  stampTint[site.stamp_color] ?? stampTint["brand"]
                }`}
              >
                {site.stamp_code}
              </span>
              <h3 className="mt-5 font-display text-2xl font-bold">{site.name}</h3>
              <p className="mt-1 text-sm text-ink/55">{site.region}</p>
              <p className="mt-3 line-clamp-3 leading-relaxed text-ink/70">
                {site.history_blurb}
              </p>

              <div className="mt-4 flex flex-wrap gap-2 text-xs font-semibold">
                {site.crowd_level && (
                  <span className="rounded-full bg-cream px-3 py-1 text-ink/65">
                    Crowds: {site.crowd_level}
                  </span>
                )}
                {site.women_safety_rating !== null && (
                  <span className="rounded-full bg-mint/40 px-3 py-1 text-ink/70">
                    Safety {site.women_safety_rating}/5
                  </span>
                )}
              </div>
              <p className="mt-4 text-sm font-semibold text-brand">
                +{site.xp_reward} XP on check-in
              </p>
              </div>
            </Link>

          ))}
        </div>
      </section>


      <section className="mx-auto max-w-6xl px-5 pb-20 sm:px-8">
        <h2 className="font-display text-3xl font-bold tracking-tight">
          The local economy around them
        </h2>
        <p className="mt-1 text-ink/60">
          Every place carries the people who make a visit possible — tagged by
          travellers, contactable directly, no commission in between.
        </p>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {vendors.slice(0, 6).map((vendor) => (
            <div key={vendor.id} className="rounded-[1.75rem] bg-surface p-6">
              <p className="text-2xl">
                {VENDOR_TYPES.find((type) => type.value === vendor.vendor_type)?.emoji ??
                  "📍"}
              </p>
              <h3 className="mt-2 font-display text-lg font-bold">{vendor.name}</h3>
              <p className="text-sm text-ink/60">{vendor.description}</p>
              <p className="mt-3 text-sm font-semibold text-brand">
                {vendor.price_from_inr
                  ? `From ${formatRupees(vendor.price_from_inr)}`
                  : "Ask for rates"}
                {vendor.contact ? ` · ${vendor.contact}` : ""}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-24 sm:px-8">
        <div className="rounded-[2rem] bg-ink p-8 text-cream md:p-12">
          <h2 className="font-display text-2xl font-bold">What comes next</h2>
          <p className="mt-3 leading-relaxed text-cream/75">
            Quest chains built on the badge system → points that unlock offers and
            discounts with local partners once travellers cross a threshold →
            sustainability scoring on alternate destinations → and the rule-based
            recommendation engine upgraded to full machine learning as verified visit
            data accumulates.
          </p>
        </div>
      </section>
    </main>
  );
}

function Tile({
  tone,
  value,
  label,
  note,
}: {
  tone: string;
  value: string;
  label: string;
  note: string;
}) {
  return (
    <div className={`rounded-[1.75rem] p-6 ${tone}`}>
      <p className="font-display text-4xl font-bold">{value}</p>
      <p className="mt-2 font-semibold">{label}</p>
      <p className="mt-1 text-sm opacity-70">{note}</p>
    </div>
  );
}
