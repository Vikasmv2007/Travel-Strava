import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";

import { askCopilot } from "@/lib/copilot.functions";

export const Route = createFileRoute("/copilot")({
  head: () => ({
    meta: [
      { title: "Heritage copilot — TravelStrava" },
      {
        name: "description",
        content:
          "Ask about any Indian heritage site in the app — history, timings, safety and what to see.",
      },
      { property: "og:title", content: "Heritage copilot — TravelStrava" },
      {
        property: "og:description",
        content: "An AI guide that knows every heritage site in TravelStrava.",
      },
    ],
  }),
  component: Copilot,
});

type Message = { role: "user" | "guide"; text: string };

const RECOVERY_PROMPTS = [
  {
    label: "I missed my train",
    text: "I missed my train to the next heritage site today. Rework my plan: what can I still see nearby, and how do I get onward tonight?",
  },
  {
    label: "It's raining",
    text: "Heavy rain has cancelled my outdoor heritage plan for today. Suggest indoor or covered heritage alternatives and how to reshuffle my itinerary.",
  },
  {
    label: "I'm unwell today",
    text: "I'm unwell and can only manage a light day. Suggest a low-effort heritage plan nearby and how to move today's sites to tomorrow.",
  },
  {
    label: "Sites within 50 km",
    text: "Suggest alternate heritage sites within 50 km of where I am, with rough travel time and entry cost.",
  },
  {
    label: "Keep me in budget",
    text: "I'm close to overspending on this trip. Suggest cheaper transport, food and stay options for the rest of my heritage trip.",
  },
  {
    label: "Extend my stay",
    text: "I want to extend my stay by two days. What else is worth seeing around here and how should I sequence it?",
  },
];


function Copilot() {
  const ask = useServerFn(askCopilot);
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "guide",
      text: "Ask me anything about the sites in your passport — history, timings or what to watch out for.",
    },
  ]);
  const [question, setQuestion] = useState("");
  const [pending, setPending] = useState(false);

  async function send(text: string) {
    const trimmed = text.trim();
    if (trimmed.length < 2 || pending) return;

    setMessages((prev) => [...prev, { role: "user", text: trimmed }]);
    setQuestion("");
    setPending(true);
    try {
      const result = await ask({ data: { question: trimmed } });
      setMessages((prev) => [...prev, { role: "guide", text: result.answer }]);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "guide", text: "That didn't go through. Try asking again." },
      ]);
    } finally {
      setPending(false);
    }
  }

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    await send(question);
  }


  return (
    <main className="mx-auto max-w-3xl px-5 pb-20 sm:px-8">
      <h1 className="font-display text-[clamp(2rem,5vw,3.5rem)] leading-tight font-bold tracking-tight">
        Your heritage <span className="text-brand">copilot</span>.
      </h1>
      <p className="mt-3 text-lg text-ink/65">
        Plans fall apart — missed trains, rain, a rough stomach. Tap a card and I'll
        rework the day.
      </p>

      <div className="mt-6 flex flex-wrap gap-2">
        {RECOVERY_PROMPTS.map((prompt) => (
          <button
            key={prompt.label}
            onClick={() => void send(prompt.text)}
            disabled={pending}
            className="rounded-full bg-surface px-4 py-2 text-sm font-semibold text-ink/70 outline-1 -outline-offset-1 outline-ink/10 hover:text-brand disabled:opacity-60"
          >
            {prompt.label}
          </button>
        ))}
      </div>



      <div className="mt-8 rounded-[2rem] bg-surface p-6 outline-1 -outline-offset-1 outline-ink/5">
        <div className="space-y-3">
          {messages.map((message, index) => (
            <p
              key={index}
              className={`max-w-[80%] rounded-2xl px-4 py-3 leading-relaxed ${
                message.role === "user"
                  ? "ml-auto rounded-tr-sm bg-plum text-cream"
                  : "rounded-tl-sm bg-cream text-ink/85"
              }`}
            >
              {message.text}
            </p>
          ))}
          {pending && (
            <p className="max-w-[80%] rounded-2xl rounded-tl-sm bg-cream px-4 py-3 text-ink/50">
              Thinking…
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="mt-5 flex items-center gap-3">
          <input
            value={question}
            onChange={(event) => setQuestion(event.target.value)}
            placeholder="Best time to visit Hampi?"
            className="flex-1 rounded-full border-2 border-ink/15 bg-cream px-5 py-3 outline-none focus:border-brand"
          />
          <button
            type="submit"
            disabled={pending}
            className="btn-pop px-7 py-3 hover:-translate-y-1 active:translate-y-0 active:btn-pop-active disabled:opacity-60"
          >
            Ask
          </button>
        </form>
      </div>
    </main>
  );
}
