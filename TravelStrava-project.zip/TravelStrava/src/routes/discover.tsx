import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import {
  PLACE_CATEGORIES,
  VENDOR_TYPES,
  VERIFICATIONS_NEEDED,
  VERIFY_RADIUS_M,
  addPlace,
  addVendor,
  distanceMetres,
  placesQuery,
  vendorsQuery,
  verifyPlace,
  type DiscoveredPlace,
  type LocalVendor,
} from "@/lib/discovery";
import { formatRupees } from "@/lib/travelstrava";
import { useOfflineCache } from "@/lib/offline";
import { useSession } from "@/lib/session";
import { MapView } from "@/components/MapView";

export const Route = createFileRoute("/discover")({
  head: () => ({
    meta: [
      { title: "Hidden places — TravelStrava" },
      {
        name: "description",
        content:
          "Add unlisted heritage places with a photo, GPS and story, then verify other travellers' finds on the ground.",
      },
      { property: "og:title", content: "Hidden places — TravelStrava" },
      {
        property: "og:description",
        content:
          "India's unlisted heritage, mapped by travellers and verified by GPS check-ins.",
      },
    ],
  }),
  component: Discover,
});

function Discover() {
  const { user } = useSession();
  const queryClient = useQueryClient();
  const { data } = useQuery(placesQuery);
  const places = useOfflineCache<DiscoveredPlace[]>("places", data) ?? [];
  const { data: vendors = [] } = useQuery(vendorsQuery);

  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [form, setForm] = useState({
    name: "",
    region: "",
    category: PLACE_CATEGORIES[0].value as string,
    story: "",
    accessNotes: "",
    bestTime: "",
  });
  const [photo, setPhoto] = useState<File | null>(null);
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState(false);

  function locate(then?: (position: { lat: number; lng: number }) => void) {
    if (!navigator.geolocation) {
      setMessage("This device can't share a location.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const next = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setCoords(next);
        setLocating(false);
        then?.(next);
      },
      () => {
        setLocating(false);
        setMessage("Location permission is needed to pin a place.");
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!user || !coords) {
      setMessage("Sign in and pin your location first.");
      return;
    }
    setSaving(true);
    try {
      await addPlace({
        userId: user.id,
        ...form,
        latitude: coords.lat,
        longitude: coords.lng,
        photo,
      });
      setForm({
        name: "",
        region: "",
        category: PLACE_CATEGORIES[0].value,
        story: "",
        accessNotes: "",
        bestTime: "",
      });
      setPhoto(null);
      setMessage("Place added. +40 XP — now it needs explorers to verify it.");
      await queryClient.invalidateQueries();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Couldn't add that place.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <main className="mx-auto max-w-6xl px-5 pb-24 sm:px-8">
      <h1 className="font-display text-[clamp(2rem,5vw,3.5rem)] leading-tight font-bold tracking-tight">
        The places no map <span className="text-brand">lists</span>.
      </h1>
      <p className="mt-4 max-w-2xl text-lg text-ink/65">
        Every village has a stepwell, a shrine, a craft street sitting idle because
        nobody wrote it down. Add one with a photo, GPS and the story behind it —
        three independent visits on the ground turn it into a trusted place.
      </p>

      <section className="mt-10 rounded-[2rem] bg-surface p-7 outline-1 -outline-offset-1 outline-ink/5">
        <h2 className="font-display text-2xl font-bold">Add a place</h2>
        {!user && (
          <p className="mt-2 font-semibold text-brand">Sign in to add a discovery.</p>
        )}
        <form onSubmit={submit} className="mt-5 grid gap-4 sm:grid-cols-2">
          <input
            value={form.name}
            onChange={(event) => setForm({ ...form, name: event.target.value })}
            placeholder="Name of the place"
            required
            className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
          />
          <input
            value={form.region}
            onChange={(event) => setForm({ ...form, region: event.target.value })}
            placeholder="Village / town, state"
            required
            className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
          />
          <select
            value={form.category}
            onChange={(event) => setForm({ ...form, category: event.target.value })}
            className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
          >
            {PLACE_CATEGORIES.map((category) => (
              <option key={category.value} value={category.value}>
                {category.label}
              </option>
            ))}
          </select>
          <input
            value={form.bestTime}
            onChange={(event) => setForm({ ...form, bestTime: event.target.value })}
            placeholder="Best time to go"
            className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand"
          />
          <textarea
            value={form.story}
            onChange={(event) => setForm({ ...form, story: event.target.value })}
            rows={3}
            required
            placeholder="The story — who built it, what happens there, why it matters"
            className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand sm:col-span-2"
          />
          <input
            value={form.accessNotes}
            onChange={(event) => setForm({ ...form, accessNotes: event.target.value })}
            placeholder="How to reach it, and is it safe after dark?"
            className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-3 outline-none focus:border-brand sm:col-span-2"
          />
          <input
            type="file"
            accept="image/*"
            onChange={(event) => setPhoto(event.target.files?.[0] ?? null)}
            className="rounded-2xl border-2 border-dashed border-ink/20 bg-cream px-4 py-3 text-sm sm:col-span-2"
          />

          <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
            <button
              type="button"
              onClick={() => locate()}
              className="rounded-full bg-cream px-5 py-3 font-semibold text-ink/70 hover:text-brand"
            >
              {locating ? "Locating…" : "Pin my GPS"}
            </button>
            {coords && (
              <span className="font-semibold text-plum">
                📍 {coords.lat.toFixed(4)}, {coords.lng.toFixed(4)}
              </span>
            )}
            <button
              type="submit"
              disabled={!user || saving}
              className="btn-pop px-7 py-3 hover:-translate-y-1 disabled:opacity-60"
            >
              {saving ? "Adding…" : "Add place (+40 XP)"}
            </button>
          </div>
        </form>
        {message && <p className="mt-4 font-semibold text-ink/70">{message}</p>}
      </section>

      <section className="mt-12">
        <h2 className="font-display text-2xl font-bold">
          Community finds ({places.length})
        </h2>
        <p className="mt-1 text-ink/60">
          A place turns trusted only after {VERIFICATIONS_NEEDED} travellers confirm it
          from within {VERIFY_RADIUS_M} m.
        </p>

        {places.length > 0 && (
          <div className="mt-6">
            <MapView
              className="h-[400px]"
              pins={places.map((place) => ({
                id: place.id,
                name: place.name,
                subtitle: `${place.region} · ${place.status}`,
                latitude: place.latitude,
                longitude: place.longitude,
                tone: place.status === "verified" ? ("mint" as const) : ("plum" as const),
              }))}
            />
          </div>
        )}

        <div className="mt-6 grid gap-5 md:grid-cols-2">

          {places.map((place) => (
            <PlaceCard
              key={place.id}
              place={place}
              vendors={vendors.filter((vendor) => vendor.place_id === place.id)}
              onLocate={locate}
            />
          ))}
          {places.length === 0 && (
            <p className="text-ink/60">
              Nothing added yet — be the first discoverer on the map.
            </p>
          )}
        </div>
      </section>
    </main>
  );
}

function PlaceCard({
  place,
  vendors,
  onLocate,
}: {
  place: DiscoveredPlace;
  vendors: LocalVendor[];
  onLocate: (then: (position: { lat: number; lng: number }) => void) => void;
}) {
  const { user } = useSession();
  const queryClient = useQueryClient();
  const [note, setNote] = useState("");
  const [status, setStatus] = useState("");
  const [vendorOpen, setVendorOpen] = useState(false);
  const [vendor, setVendor] = useState({
    name: "",
    vendorType: VENDOR_TYPES[0].value as string,
    contact: "",
    price: "",
    description: "",
  });

  const alreadyVerified = (place.place_verifications ?? []).some(
    (row) => row.user_id === user?.id,
  );
  const verified = place.status === "verified";

  function handleVerify() {
    if (!user) {
      setStatus("Sign in to verify a place.");
      return;
    }
    onLocate(async (position) => {
      const away = distanceMetres(position, {
        lat: place.latitude,
        lng: place.longitude,
      });
      try {
        await verifyPlace({
          placeId: place.id,
          userId: user.id,
          latitude: position.lat,
          longitude: position.lng,
          placeLatitude: place.latitude,
          placeLongitude: place.longitude,
          note,
        });
        setStatus(`Verified from ${away} m away. +15 XP.`);
        await queryClient.invalidateQueries();
      } catch (error) {
        setStatus(
          error instanceof Error ? error.message : "Couldn't record that verification.",
        );
      }
    });
  }

  async function submitVendor(event: React.FormEvent) {
    event.preventDefault();
    if (!user) return;
    await addVendor({
      userId: user.id,
      placeId: place.id,
      name: vendor.name,
      vendorType: vendor.vendorType,
      description: vendor.description,
      contact: vendor.contact,
      priceFrom: vendor.price ? Number(vendor.price) : null,
    });
    setVendor({ name: "", vendorType: VENDOR_TYPES[0].value, contact: "", price: "", description: "" });
    setVendorOpen(false);
    await queryClient.invalidateQueries();
  }

  return (
    <article className="overflow-hidden rounded-[2rem] bg-surface outline-1 -outline-offset-1 outline-ink/5">
      {place.signedPhoto && (
        <img
          src={place.signedPhoto}
          alt={place.name}
          loading="lazy"
          className="h-48 w-full object-cover"
        />
      )}
      <div className="p-6">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={`rounded-full px-3 py-1 text-xs font-bold ${
              verified ? "bg-mint text-ink" : "bg-accent text-ink"
            }`}
          >
            {verified
              ? "Verified place"
              : `${place.verification_count}/${VERIFICATIONS_NEEDED} verifications`}
          </span>
          <span className="rounded-full bg-cream px-3 py-1 text-xs font-semibold text-ink/60">
            {PLACE_CATEGORIES.find((item) => item.value === place.category)?.label ??
              place.category}
          </span>
        </div>

        <h3 className="mt-3 font-display text-xl font-bold">{place.name}</h3>
        <p className="text-sm font-semibold text-ink/50">{place.region}</p>
        <p className="mt-3 leading-relaxed text-ink/75">{place.story}</p>
        {place.access_notes && (
          <p className="mt-2 text-sm text-ink/60">Getting there: {place.access_notes}</p>
        )}
        {place.best_time && (
          <p className="text-sm text-ink/60">Best time: {place.best_time}</p>
        )}
        <p className="mt-3 text-sm text-ink/50">
          Found by {place.profiles?.display_name ?? "a traveller"}
        </p>

        {vendors.length > 0 && (
          <ul className="mt-4 space-y-2">
            {vendors.map((item) => (
              <li key={item.id} className="rounded-2xl bg-cream px-4 py-3 text-sm">
                <span className="font-semibold">
                  {VENDOR_TYPES.find((type) => type.value === item.vendor_type)?.emoji}{" "}
                  {item.name}
                </span>
                {item.price_from_inr ? (
                  <span className="text-ink/60"> · from {formatRupees(item.price_from_inr)}</span>
                ) : null}
                {item.contact ? <span className="text-ink/60"> · {item.contact}</span> : null}
              </li>
            ))}
          </ul>
        )}

        <div className="mt-5 flex flex-wrap gap-2">
          {!alreadyVerified && (
            <button
              onClick={handleVerify}
              className="rounded-full bg-ink px-5 py-2.5 text-sm font-semibold text-cream"
            >
              I'm here — verify (+15 XP)
            </button>
          )}
          {alreadyVerified && (
            <span className="rounded-full bg-mint/40 px-5 py-2.5 text-sm font-semibold">
              You verified this
            </span>
          )}
          <button
            onClick={() => setVendorOpen((value) => !value)}
            className="rounded-full bg-cream px-5 py-2.5 text-sm font-semibold text-ink/70 hover:text-brand"
          >
            Tag a homestay, guide or stall
          </button>
        </div>

        {!alreadyVerified && (
          <input
            value={note}
            onChange={(event) => setNote(event.target.value)}
            placeholder="Optional note for the next traveller"
            className="mt-3 w-full rounded-2xl border-2 border-ink/15 bg-cream px-4 py-2.5 text-sm outline-none focus:border-brand"
          />
        )}

        {vendorOpen && user && (
          <form onSubmit={submitVendor} className="mt-4 grid gap-3">
            <input
              value={vendor.name}
              onChange={(event) => setVendor({ ...vendor, name: event.target.value })}
              required
              placeholder="Name of the homestay / guide / stall"
              className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-2.5 text-sm outline-none focus:border-brand"
            />
            <div className="flex gap-3">
              <select
                value={vendor.vendorType}
                onChange={(event) =>
                  setVendor({ ...vendor, vendorType: event.target.value })
                }
                className="flex-1 rounded-2xl border-2 border-ink/15 bg-cream px-4 py-2.5 text-sm outline-none focus:border-brand"
              >
                {VENDOR_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
              <input
                value={vendor.price}
                onChange={(event) => setVendor({ ...vendor, price: event.target.value })}
                inputMode="numeric"
                placeholder="From ₹"
                className="w-28 rounded-2xl border-2 border-ink/15 bg-cream px-4 py-2.5 text-sm outline-none focus:border-brand"
              />
            </div>
            <input
              value={vendor.contact}
              onChange={(event) => setVendor({ ...vendor, contact: event.target.value })}
              placeholder="Phone or WhatsApp"
              className="rounded-2xl border-2 border-ink/15 bg-cream px-4 py-2.5 text-sm outline-none focus:border-brand"
            />
            <button type="submit" className="btn-pop px-6 py-2.5 text-sm">
              Add to the local economy
            </button>
          </form>
        )}

        {status && <p className="mt-3 text-sm font-semibold text-plum">{status}</p>}
      </div>
    </article>
  );
}
